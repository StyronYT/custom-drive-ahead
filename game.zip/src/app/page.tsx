'use client'

import { useEffect, useRef, useState } from 'react'
import * as pl from 'planck'
import { convexPieces } from '../lib/convexPieces'

/* площадь полигона шнурком (convexPieces гарантирует CCW => площадь > 0) */
function polyArea(pts: Vec[]): number {
  let a = 0
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i]
    const q = pts[(i + 1) % pts.length]
    a += p[0] * q[1] - q[0] * p[1]
  }
  return a / 2
}

/* нижняя точка и след машины по ДАННЫМ префаба (без planck-состояния):
   полигоны корпусов + круги (колёса/голова) относительно корня */
function carFootprint(def: CarDef): { minY: number; minX: number; maxX: number } {
  let minY = Infinity, minX = Infinity, maxX = -Infinity
  const nodes: CarNode[] = [def.tree, ...(def.tree.children || [])]
  for (const n of nodes) {
    const px = (n.pos && n.pos[0]) || 0
    const py = (n.pos && n.pos[1]) || 0
    if (n.poly) {
      for (const path of n.poly.paths) {
        for (const p of path) {
          const y = py + p[1], x = px + p[0]
          if (y < minY) minY = y
          if (x < minX) minX = x
          if (x > maxX) maxX = x
        }
      }
    }
    if (n.circle) {
      const y = py - n.circle.r, xl = px - n.circle.r, xr = px + n.circle.r
      if (y < minY) minY = y
      if (xl < minX) minX = xl
      if (xr > maxX) maxX = xr
    }
  }
  return { minY, minX, maxX }
}

/* ============================================================
   Точные параметры из Unity-проекта (ProjectSettings + префабы)
   ============================================================ */
const GRAVITY_Y = -7 // Physics2DSettings.asset m_Gravity
const FIXED_DT = 0.02 // Unity Fixed Timestep
const VEL_ITER = 10 // Unity/Box2D solver, +2: стабильнее контакт колёс со швами цепей
const POS_ITER = 4
const ORTHO = 2.5714285 // RenderCamera orthographic size (half-height)
const BG_COLOR = '#314d79' // RenderCamera background rgb(0.192,0.302,0.475)
const ROUND_END_SLOWMO = 3 // HandleRoundEnd: WaitForSecondsRealtime(3)
const WIN_SCORE = 5 // GameManager.IsGameOver

/* Спрайты UI (Img (1).png / SpinEffects.png — fileID из сцены) */
const SPR = {
  blueStar: 'Img (1)__Img (1)_8.png',
  redStar: 'Img (1)__Img (1)_9.png',
  emptyStar: 'Img (1)__Img (1)_2.png',
  blueSpin: 'SpinEffects__SpinEffects_0.png',
  redSpin: 'SpinEffects__SpinEffects_1.png',
  people: 'Img (1)__Img (1)_41.png',
  peopleBg: 'Img (1)__Img (1)_49.png',
}
const BLUE_STAR_IMG = '/sprites/Img%20(1)__Img%20(1)_8.png'
const RED_STAR_IMG = '/sprites/Img%20(1)__Img%20(1)_9.png'
const EMPTY_STAR_IMG = '/sprites/Img%20(1)__Img%20(1)_2.png'
const BLUE_SPIN_IMG = '/sprites/SpinEffects__SpinEffects_0.png'
const RED_SPIN_IMG = '/sprites/SpinEffects__SpinEffects_1.png'

/* Цвета из TMP-текстов сцены */
const BLUE_COLOR = '#55b2ff' // rgb(0.335, 0.699, 1)
const RED_COLOR = '#ff4a3d' // rgb(1, 0.2915, 0.2406)

type Vec = [number, number]

interface CarNode {
  name: string
  pos: Vec
  rb?: { mass: number; gravityScale: number; linearDamping: number; angularDamping: number; friction: number }
  circle?: { r: number; off: Vec; friction: number }
  poly?: { paths: Vec[][] }
  sprite?: string | null
  flipX?: boolean
  order?: number
  layer?: number
  rotZ?: number
  scale?: Vec
  collider?: { type: string; offset?: Vec; radius?: number } | null
  hinge?: { anchor: Vec; connectedAnchor: Vec; limits: [number, number] }
  wheelJoints?: { connected: null; anchor: Vec; susp: [number, number] }[]
  children?: CarNode[]
}

interface CarDef {
  carType: string
  color: string
  carData: { speed: number; maxSpeed: number; rotationSpeed: number }
  tree: CarNode
}

interface ArenaDef {
  name: string
  pos: Vec
  rotZ: number
  scale: Vec
  sprite: string
  flipX: boolean
  order: number
  collider: { type: string; paths?: Vec[][] } | null
  spawns: Record<string, Vec>
  children: CarNode[]
}

interface GameData {
  cars: Record<string, CarDef>
  arenas: ArenaDef[]
}

/* ============ утилиты ============ */
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((res, rej) => {
    const img = new Image()
    img.onload = () => res(img)
    img.onerror = rej
    img.src = src
  })
}

function spriteUrl(name: string): string {
  return '/sprites/' + encodeURIComponent(name.replace('/', '__') + '.png')
}

/* ============ физика машины ============ */
class Car {
  body: pl.Body
  wheels: pl.Body[] = []
  head: pl.Body
  def: CarDef
  moveInput = 0
  locked = false
  startPos: Vec
  color: CarType
  hitTime = 0

  constructor(world: pl.World, def: CarDef, spawn: Vec, color: CarType) {
    this.def = def
    this.color = color
    this.startPos = [spawn[0], spawn[1]]
    const t = def.tree
    const rb = t.rb!
    this.body = world.createBody({
      type: 'dynamic',
      position: new pl.Vec2(spawn[0], spawn[1]),
      gravityScale: rb.gravityScale,
      linearDamping: rb.linearDamping,
      angularDamping: rb.angularDamping,
    })
    // корпус: полигон лежит на дочернем узле Body (в Unity PolygonCollider2D на
    // ребёнке без своего Rigidbody2D относится к корневому телу)
    const bodyNode = (t.children || []).find((c) => c.poly) || (t.poly ? t : null)
    if (bodyNode && bodyNode.poly) {
      let totalArea = 0
      const built: { shape: pl.Polygon }[] = []
      for (const path of bodyNode.poly.paths) {
        // узел Body может быть смещён относительно корня — переносим точки;
        // дубли и «щепки» (у Cart следов контура) вырезаем ДО декомпозиции:
        // вырожденный кусок planck молча заменяет юнит-боксом (масса и контакты ломаются)
        const shiftedRaw = path.map((p) => [p[0] + bodyNode.pos[0], p[1] + bodyNode.pos[1]] as Vec)
        const shifted: Vec[] = []
        for (const p of shiftedRaw) {
          const q = shifted[shifted.length - 1]
          if (!q || Math.hypot(p[0] - q[0], p[1] - q[1]) > 1e-4) shifted.push(p)
        }
        while (shifted.length > 2 && Math.hypot(shifted[0][0] - shifted[shifted.length - 1][0], shifted[0][1] - shifted[shifted.length - 1][1]) <= 1e-4) shifted.pop()
        for (const pc of convexPieces(shifted)) {
          try {
            const clean = pc.filter(
              (p, i) =>
                !(i > 0 && Math.hypot(p[0] - pc[i - 1][0], p[1] - pc[i - 1][1]) <= 1e-4) &&
                !(i === pc.length - 1 && Math.hypot(p[0] - pc[0][0], p[1] - pc[0][1]) <= 1e-4)
            )
            const a = polyArea(clean)
            if (!(a > 1e-4) || clean.length < 3) continue // вырожденный кусок — пропускаем
            const shape = pl.Polygon(clean.map((p) => new pl.Vec2(p[0], p[1])))
            const area = a // без computeMass: в разных сборках planck его API различается
            if (!(area > 0) || !isFinite(area)) continue // защита от отрицательной площади/обхода
            built.push({ shape })
            totalArea += area
          } catch (e) {
            console.error('fixture piece failed', e)
          }
        }
      }
      if (built.length && totalArea > 0) {
        for (const b of built) {
          this.body.createFixture({
            shape: b.shape,
            density: rb.mass / totalArea,
            friction: rb.friction,
          })
        }
      }
      // контроль: масса корпуса обязана совпасть с массой из префаба, инерция > 0
      const dm = Math.abs(this.body.getMass() - rb.mass)
      if (dm > 0.02 || !(this.body.getInertia() > 0)) {
        console.error(
          `body mass/inertia broken: mass ${this.body.getMass()} vs ${rb.mass}, inertia ${this.body.getInertia()} (car ${def.carType})`
        )
      }
    }
    // колёса, голова, шарниры
    const wheelJoints = t.wheelJoints || []
    const wheelNodes: CarNode[] = []
    for (const ch of t.children || []) {
      // колёса: circle + rb, без hinge (у головы есть hinge)
      if (ch.circle && ch.rb && !ch.hinge) {
        wheelNodes.push(ch)
      }
    }
    for (const wj of wheelJoints) {
      // колёса ищем по позиции якоря
      const wNode =
        wheelNodes.find(
          (n) => Math.abs(n.pos[0] - wj.anchor[0]) < 0.01 && Math.abs(n.pos[1] - wj.anchor[1]) < 0.01
        ) || wheelNodes[wheelNodes.length]
      if (!wNode) continue
      const wheelPos = new pl.Vec2(spawn[0] + wNode.pos[0], spawn[1] + wNode.pos[1])
      const wb = world.createBody({
        type: 'dynamic',
        position: wheelPos,
        gravityScale: wNode.rb!.gravityScale,
        linearDamping: wNode.rb!.linearDamping,
        angularDamping: wNode.rb!.angularDamping,
      })
      const r = wNode.circle!.r
      const shape = pl.Circle(r)
      wb.createFixture({ shape, density: wNode.rb!.mass / (Math.PI * r * r), friction: wNode.circle!.friction })
      world.createJoint(
        pl.WheelJoint(
          { frequencyHz: wj.susp[1], dampingRatio: wj.susp[0], enableMotor: false },
          this.body,
          wb,
          wheelPos,
          new pl.Vec2(0, 1)
        )
      )
      this.wheels.push(wb)
      ;(wb as any)._spriteNode = wNode
    }
    // голова
    const headNode = (t.children || []).find((c) => c.hinge)
    let head: pl.Body | null = null
    if (headNode) {
      const hp = new pl.Vec2(spawn[0] + headNode.pos[0], spawn[1] + headNode.pos[1])
      head = world.createBody({
        type: 'dynamic',
        position: hp,
        gravityScale: headNode.rb!.gravityScale,
        linearDamping: headNode.rb!.linearDamping,
        angularDamping: headNode.rb!.angularDamping,
      })
      const r = headNode.circle!.r
      head.createFixture({ shape: pl.Circle(r), density: headNode.rb!.mass / (Math.PI * r * r), friction: 0.4 })
      const anchorWorld = new pl.Vec2(hp.x + headNode.hinge!.anchor[0], hp.y + headNode.hinge!.anchor[1])
      world.createJoint(
        pl.RevoluteJoint(
          {
            enableLimit: true,
            lowerAngle: (headNode.hinge!.limits[0] * Math.PI) / 180,
            upperAngle: (headNode.hinge!.limits[1] * Math.PI) / 180,
          },
          head,
          this.body,
          anchorWorld
        )
      )
      ;(head as any)._spriteNode = headNode
    }
    this.head = head as pl.Body
    ;(this.body as any)._spriteNode = (t.children || []).find((c) => c.poly)
  }

  fixedUpdate(dt: number) {
    if (this.locked) {
      this.moveInput = 0
    }
    const speed = this.def.carData.speed
    const rotSpeed = this.def.carData.rotationSpeed
    const wheelTorque = -this.moveInput * speed * dt
    for (const w of this.wheels) w.applyTorque(wheelTorque)
    if (this.wheels.length === 0) {
      // машина без колёс (Cart): катится корпусом, как на салазках.
      // ВНИМАНИЕ: applyForce в этой сборке planck требует point и падает без него,
      // поэтому разгон делаем прямым приращением скорости (setLinearVelocity).
      // Рывок направлен ВДОЛЬ корпуса (не по горизонтали) — иначе на горке
      // нормальная сила склона гасит горизонтальную скорость, и карта не может залезть в гору.
      const top = this.def.carData.maxSpeed / 60 // верхняя скорость, units/s
      const v = this.body.getLinearVelocity()
      const a = this.body.getAngle()
      const ax = Math.cos(a)
      const ay = Math.sin(a)
      const along = v ? v.x * ax + v.y * ay : 0 // скорость вдоль оси корпуса
      const can =
        this.moveInput > 0 ? along < top : this.moveInput < 0 ? along > -top : false
      if (can) {
        // ускорение a = speed*0.05 units/s² → за шаг dt: Δv = a·dt
        const dv = this.moveInput * this.def.carData.speed * 0.05 * dt
        const vx = v ? v.x : 0
        const vy = v ? v.y : 0
        this.body.setLinearVelocity(new pl.Vec2(vx + ax * dv, vy + ay * dv))
      }
    }
    this.body.applyTorque(this.moveInput * rotSpeed * dt)
  }

  /* Physics2DSettings.m_MaxRotationSpeed = 360: Unity жёстко ограничивает угловую
     скорость всех rigidbody. Без предела корпус (особенно Cart без колёс) в воздухе
     раскручивается applyTorque'ом каждый шаг до безумных оборотов.
     Колёса НЕ трогаем — для разгона им нужны высокие ω (поверхностная скорость). */
  clampSpin() {
    const MAX_W = (360 * Math.PI) / 180 // 2π rad/s = 1 об/с
    const w = this.body.getAngularVelocity()
    if (Math.abs(w) > MAX_W) this.body.setAngularVelocity(Math.sign(w) * MAX_W)
    if (this.head) {
      const hw = this.head.getAngularVelocity()
      if (Math.abs(hw) > MAX_W) this.head.setAngularVelocity(Math.sign(hw) * MAX_W)
    }
  }

  lockMovement() {
    this.locked = true
    this.moveInput = 0
  }

  /* CarController.OnReset */
  reset() {
    this.moveInput = 0
    // сбрасываем ВСЕ тела сборки: корпус, колёса, голову. Раньше телепортировался
    // только корпус — колёса оставались на старом месте со старой скоростью,
    // растянутые суставы дёргали машину и она «улетала» к спавну.
    // ВНИМАНИЕ: в этой сборке planck нет статического Vec2.ZERO (undefined) —
    // setLinearVelocity(undefined) падал с "Cannot read properties of undefined (reading 'x')".
    const rest = (b: pl.Body, off: Vec | null) => {
      b.setLinearVelocity(new pl.Vec2(0, 0))
      b.setAngularVelocity(0)
      b.setAngle(0)
      if (off) b.setPosition(new pl.Vec2(this.startPos[0] + off[0], this.startPos[1] + off[1]))
      b.setAwake(true)
    }
    rest(this.body, [0, 0]) // корпус — ровно на startPos
    for (const w of this.wheels) {
      const n = (w as any)._spriteNode as CarNode | undefined
      rest(w, n ? [n.pos[0], n.pos[1]] : null)
    }
    const hn = (this.head as any)?._spriteNode as CarNode | undefined
    if (this.head) rest(this.head, hn ? [hn.pos[0], hn.pos[1]] : null)
  }
}

type CarType = 'blue' | 'red'

/* ============ пиксель-иконки главного меню (# = белый, o = чёрный) ============ */
/* робот: квадратная голова с ушками по бокам, антенна, глаза, решётка рта */
const ROBOT_ICON = [
  '......####......',
  '......####......',
  '.......##.......',
  '..############..',
  '..############..',
  '..############..',
  '.##############.',
  '.###...##...###.',
  '.###...##...###.',
  '.###...##...###.',
  '.##############.',
  '..############..',
  '................',
  '..#.#.#.#.#.#..',
  '..############..',
]
const HUMAN_ICON = [
  '...####...',
  '...####...',
  '...####...',
  '...####...',
  '..........',
  '.########.',
  '.########.',
  '.########.',
  '.########.',
  '.########.',
  '..##..##..',
  '..##..##..',
  '..##..##..',
  '..##..##..',
  '..##..##..',
]

/* машина в профиль: крыша, наклон лобового, окна-вырезы, колёса.
   ТОЛЬКО белые пиксели (#) и прозрачные (.) — вырезы окон/арок показывают
   цвет кнопки, никакого чёрного внутри иконки */
const CARS_ICON = [
  '......####......',
  '.....######.....',
  '....########....',
  '..############..',
  '..##..####..##..',
  '..############..',
  '.##############.',
  '..###......###..',
  '..###......###..',
]

/* кубок (челлендж): только белые пиксели и прозрачные — без чёрного */
const TROPHY_ICON = [
  '##.######.##',
  '#.########.#',
  '#.########.#',
  '#..######..#',
  '....####....',
  '....####....',
  '...######...',
  '..########..',
]

/* ---- режим CHALLENGE ----
   Случайный челлендж (пока один: выживание). Без звёзд и очков.
   Игрок на Monster; каждые CHALLENGE_INTERVAL с в случайной безопасной точке
   играбельной зоны спавнится бот Antique Formula (лимит CHALLENGE_MAX_BOTS
   одновременно — при превышении старейший исчезает с эффектом). Продержаться
   до конца таймера = победа; HP игрока до нуля = поражение. */
const CHALLENGE_DURATION = 40 // секунд выживания
const CHALLENGE_INTERVAL = 0.9 // секунд между спавнами ботов
const CHALLENGE_MAX_BOTS = 12 // максимум ботов одновременно (физика/читаемость)
const CHALLENGE_MIN_PLAYER_DIST = 2.6 // не ближе к игроку при выборе точки
const CHALLENGE_SPAWN_TRIES = 60 // попыток найти свободную клетку за тик

const CHALLENGES = [
  {
    id: 'survive40',
    name: 'SURVIVE',
    duration: CHALLENGE_DURATION,
    botInterval: CHALLENGE_INTERVAL,
    playerCar: 'BlueMonster',
    botCar: 'RedAntiqueFormula',
    maxBots: CHALLENGE_MAX_BOTS,
  },
]

/* пиксельные стрелки витрины (переключение машин): белые, острие наружу */
const ARROW_L_ICON = [
  '.....##..',
  '....##...',
  '...##....',
  '..##.....',
  '.##......',
  '##.......',
  '.##......',
  '..##.....',
  '...##....',
  '....##...',
  '.....##..',
]
const ARROW_R_ICON = [
  '..##.....',
  '...##....',
  '....##...',
  '.....##..',
  '......##.',
  '.......##',
  '......##.',
  '.....##..',
  '....##...',
  '...##....',
  '..##.....',
]

/* Battle: скрещенные мечи (крест-накрест) */
const BATTLE_ICON = [
  '##......##',
  '.##....##.',
  '..##..##..',
  '...####...',
  '....##....',
  '...####...',
  '..##..##..',
  '.##....##.',
  '##......##',
]

/* Редкость машин витрины (ключ — базовое имя без префикса Blue/Red).
   Распределение как в играх: стартовые/простые — Common, забавные и
   утилитарные — Rare, мощные и гоночные — Epic, уникальные — Legendary. */
const CAR_RARITY: Record<string, 'Common' | 'Rare' | 'Epic' | 'Legendary'> = {
  Weevil: 'Common',
  Cart: 'Epic',
  TVCar: 'Rare',
  Limouse: 'Rare',
  'Off-RoadTruck': 'Rare',
  Monster: 'Legendary',
  Dragster: 'Epic',
  AntiqueFormula: 'Common',
  PlanetaryExplorer: 'Rare',
  Banana: 'Rare',
}
/* цвета тиров — общепринятая гамма (серый/синий/фиолетовый/золотой) */
const RARITY_COLOR: Record<string, string> = {
  Common: '#c9c9c9',
  Rare: '#57a8ff',
  Epic: '#c264ff',
  Legendary: '#ffb838',
}
/* «Off-RoadTruck» → «OFF ROAD TRUCK», «TVCar» → «TV CAR»: границы camelCase
   (в т.ч. блок заглавных перед Capitalized-словом) и дефисы → пробелы */
const carDisplayName = (base: string) =>
  base
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2') // TVCar → TV Car
    .replace(/([a-z])([A-Z])/g, '$1 $2') // AntiqueFormula → Antique Formula
    .replace(/-/g, ' ')
    .toUpperCase()

/* ---- режим BATTLE ----
   У каждого 3 звезды-жизни; раунд проигрывает тот, у кого кончилось HP.
   HP машины зависит от редкости: Common 1500 → Legendary 2300.
   Урон — наоборот: чем реже машина, тем МЕНЬШЕ она наносит: 300 → 220
   (урон наносит машина соперника того, кто ударился головой). */
const BATTLE_STARS = 3
const RARITY_HP: Record<string, number> = { Common: 1500, Rare: 1800, Epic: 2050, Legendary: 2300 }
const RARITY_DMG: Record<string, number> = { Common: 300, Rare: 275, Epic: 245, Legendary: 220 }
const carRarity = (carType: string) => CAR_RARITY[carType.replace(/^(Blue|Red)/, '')] ?? 'Common'
/* Planetary Explorer усилен отдельно (запрос «мощнее, maxSpeed не трогать»):
   HP — на уровне Epic+, урон — выше всех; ключ — carType без префикса Blue/Red */
const CAR_HP_OVERRIDE: Record<string, number> = { PlanetaryExplorer: 2200 }
const CAR_DMG_OVERRIDE: Record<string, number> = { PlanetaryExplorer: 320 }
const carMaxHp = (carType: string) => CAR_HP_OVERRIDE[carType.replace(/^(Blue|Red)/, '')] ?? RARITY_HP[carRarity(carType)] ?? 1500
const carDamage = (carType: string) => CAR_DMG_OVERRIDE[carType.replace(/^(Blue|Red)/, '')] ?? RARITY_DMG[carRarity(carType)] ?? 300
/* награда болтами: в среднем 4–35 за матч (3-0 → 35, 3-1 → 20, 3-2 → 5) */
const battleBolts = (loserRounds: number) => 35 - loserRounds * 15

/* Пиксельные затемнения/блики для кнопок меню: только жёсткие ступени, без сглаживания */
const MENU_SHADE = [
  // шахматный дизеринг 4px
  'repeating-conic-gradient(rgba(0,0,0,0.05) 0% 25%, rgba(0,0,0,0) 0% 50%)',
  // ступенчатое затемнение к низу
  'linear-gradient(180deg, rgba(0,0,0,0) 0 55%, rgba(0,0,0,0.10) 55% 70%, rgba(0,0,0,0.20) 70% 85%, rgba(0,0,0,0.32) 85% 100%)',
  // блик сверху
  'linear-gradient(180deg, rgba(255,255,255,0.16) 0 5%, rgba(255,255,255,0) 5%)',
  // боковые фаски: слева свет, справа тень
  'linear-gradient(90deg, rgba(255,255,255,0.12) 0 0.9vh, rgba(255,255,255,0) 0.9vh calc(100% - 0.9vh), rgba(0,0,0,0.20) calc(100% - 0.9vh))',
].join(', ')

function PixelIcon({ map, height }: { map: string[]; height: string }) {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const cv = ref.current
    if (!cv) return
    const rows = map.length
    const cols = Math.max(...map.map((r) => r.length))
    cv.width = cols
    cv.height = rows
    const c = cv.getContext('2d')!
    c.clearRect(0, 0, cols, rows)
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < map[y].length; x++) {
        const ch = map[y][x]
        if (ch === '#') {
          c.fillStyle = '#ffffff'
          c.fillRect(x, y, 1, 1)
        }
      }
    }
  }, [map])
  return <canvas ref={ref} style={{ height, width: 'auto', imageRendering: 'pixelated' }} />
}

/* Пиксельные стрелки тач-кнопок: рисуются по пиксельной карте (PixelIcon),
   а не шрифтовым глифом ◀/▶ — у глифа сглаженные края, карта всегда блоковая */
const ARROW_R = [
  '##......',
  '####....',
  '######..',
  '########',
  '########',
  '######..',
  '####....',
  '##......',
]
const ARROW_L = ARROW_R.map((r) => r.split('').reverse().join(''))

/* Пиксельные затемнения/блики тач-кнопок: только жёсткие ступени, без сглаживания */
const BTN_SHADE = [
  // шахматный дизеринг 4px
  'repeating-conic-gradient(rgba(0,0,0,0.06) 0% 25%, rgba(0,0,0,0) 0% 50%)',
  // блик сверху + ступенчатое затемнение к низу
  'linear-gradient(180deg, rgba(255,255,255,0.18) 0 6%, rgba(255,255,255,0) 6% 58%, rgba(0,0,0,0.12) 58% 74%, rgba(0,0,0,0.24) 74% 88%, rgba(0,0,0,0.34) 88% 100%)',
  // боковые фаски 6px: слева свет, справа тень
  'linear-gradient(90deg, rgba(255,255,255,0.14) 0 6px, rgba(255,255,255,0) 6px calc(100% - 6px), rgba(0,0,0,0.20) calc(100% - 6px))',
].join(', ')

/* Тач-кнопка удержания (мобильное управление). Pointer-события вешаем прямо на
   элемент через React: старый вариант с getElementById в общем маунте не работал —
   в главном меню кнопок ещё нет в DOM, слушатели не навешивались, и после входа
   в матч кнопки были «мёртвые». setPointerCapture: палец соскользнул с кнопки —
   отпускание всё равно придёт, клавиша не залипает. */
function HoldBtn({ color, arrow, onDown, onUp }: { color: 'blue' | 'red'; arrow: 'left' | 'right'; onDown: () => void; onUp: () => void }) {
  const heldRef = useRef(false)
  const [held, setHeld] = useState(false)
  const down = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.preventDefault()
    try {
      e.currentTarget.setPointerCapture(e.pointerId)
    } catch {
      /* старые браузеры без setPointerCapture — просто нажимаем */
    }
    if (!heldRef.current) {
      heldRef.current = true
      setHeld(true)
      onDown()
    }
  }
  const up = () => {
    if (!heldRef.current) return
    heldRef.current = false
    setHeld(false)
    onUp()
  }
  return (
    <button
      onPointerDown={down}
      onPointerUp={up}
      onPointerCancel={up}
      onLostPointerCapture={up}
      onContextMenu={(e) => e.preventDefault()}
      className="px-btn pointer-events-auto select-none text-white"
      style={{
        width: 'clamp(58px, 9.5vh, 96px)',
        height: 'clamp(58px, 9.5vh, 96px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 0,
        backgroundColor: held ? (color === 'blue' ? '#274a80' : '#7e2419') : color === 'blue' ? '#3e72c5' : '#c23a2c',
        backgroundImage: BTN_SHADE,
        backgroundSize: '4px 4px, auto, auto, auto',
        backgroundRepeat: 'repeat, no-repeat, no-repeat, no-repeat',
        border: '3px solid #101010',
        touchAction: 'none',
        WebkitTapHighlightColor: 'transparent',
        transform: held ? 'translateY(2px)' : 'none',
        cursor: 'pointer',
      }}
    >
      <PixelIcon map={arrow === 'left' ? ARROW_L : ARROW_R} height="clamp(22px, 3.8vh, 38px)" />
    </button>
  )
}

/* ============ частицы попадания ============ */
interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  size: number
}

/* ============ компонент игры ============ */
export default function DriveAheadGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [score, setScore] = useState({ blue: 0, red: 0 })
  const [winner, setWinner] = useState<CarType | null>(null)
  const [boltsEarned, setBoltsEarned] = useState<number | null>(null) // награда за матч Battle
  const [spinStar, setSpinStar] = useState<{ color: CarType; index: number } | null>(null)
  const [scoresLabel, setScoresLabel] = useState<CarType | null>(null)
  const [winClosing, setWinClosing] = useState(false)
  const [paused, setPaused] = useState(false)
  const stateRef = useRef<any>(null)
  /* нажатые клавиши/кнопки: живёт на уровне компонента, чтобы тач-кнопки
     (HoldBtn в JSX) и клавиатура внутри useEffect писали в один объект */
  const keysRef = useRef<Record<string, boolean>>({})
  const [ready, setReady] = useState(false)
  const [mode, setMode] = useState<'menu' | 'bot' | 'friend' | 'battle' | 'challenge'>('menu')
  const [challengeResult, setChallengeResult] = useState<'win' | 'lose' | null>(null) // итог челленджа
  /* таймер челленджа (сверху справа, с сотыми): игровой цикл пишет текст напрямую
     в DOM через refs на 60 Гц — без ре-рендера всего HUD каждый кадр */
  const challengeTimerRef = useRef<HTMLDivElement>(null)
  const challengeSecRef = useRef<HTMLSpanElement>(null)
  const challengeFracRef = useRef<HTMLSpanElement>(null)
  const [carsOpen, setCarsOpen] = useState(false)
  const [carsModel, setCarsModel] = useState<string | null>(null) // базовое имя машины в витрине
  const [bolts, setBolts] = useState(0) // валюта «болты» (localStorage: bolts)
  useEffect(() => {
    setBolts(Math.max(0, Math.floor(Number(localStorage.getItem('bolts')) || 0)))
  }, [])

  useEffect(() => {
    let disposed = false

    async function boot() {
      const data: GameData = await fetch('/game_data.json?t=' + Date.now(), { cache: 'no-store' }).then((r) => r.json())
      // ВРЕМЕННО исключили круговую арену (Arenas3_1): контур коллайдера не совпадает
      // с овальным артом (скошенный эллипс) — вернуть после переделки коллайдера.
      data.arenas = data.arenas.filter((a) => a.name !== 'Arenas3_1')
      if (disposed) return

      const canvas = canvasRef.current!
      const ctx = canvas.getContext('2d')!

      /* ---- загрузка всех нужных спрайтов ---- */
      const needSprites = new Set<string>([
        SPR.people,
        SPR.peopleBg,
        'CarParts__CarParts_304.png',
        'CarParts__CarParts_302.png',
        'SpinEffects__SpinEffects_0.png', // витрина CARS: белый вращающийся эффект за машиной
      ])
      for (const a of data.arenas) {
        needSprites.add(a.sprite!.replace('/', '__') + '.png')
        for (const ch of a.children) {
          if (ch.sprite) needSprites.add(ch.sprite.replace('/', '__') + '.png')
          for (const k of ch.children || []) if (k.sprite) needSprites.add(k.sprite.replace('/', '__') + '.png')
        }
      }
      for (const cd of Object.values(data.cars)) {
        const walk = (n: CarNode) => {
          if (n.sprite) needSprites.add(n.sprite.replace('/', '__') + '.png')
          for (const k of n.children || []) walk(k)
        }
        walk(cd.tree)
      }
      const images: Record<string, HTMLImageElement> = {}
      await Promise.all([...needSprites].map(async (s) => { images[s] = await loadImage('/sprites/' + encodeURIComponent(s)) }))
      if (disposed) return

      /* ---- размеры спрайтов (px, ppu, pivot) ---- */
      const manifest = await fetch('/sprite_manifest.json').then((r) => r.json()).catch(() => null)
      const spriteMeta: Record<string, { px: number[]; ppu: number; pivot: number[] }> = {}
      for (const s of Object.keys(images)) {
        const img = images[s]
        const key = s.replace('.png', '').replace('__', '/')
        const m = manifest?.[key]
        spriteMeta[s] = m ? { px: m.px, ppu: m.ppu, pivot: m.pivot } : { px: [img.width, img.height], ppu: 48, pivot: [0.5, 0.5] }
      }

      /* ---- состояние игры (аналог GameManager) ---- */
      const S = {
        world: null as pl.World | null,
        blue: null as Car | null,
        red: null as Car | null,
        ballBodies: [] as pl.Body[],
        arenaDrawables: [] as any[],
        peopleDrawables: [] as any[],
        borderDone: false,
        score: { blue: 0, red: 0 },
        roundOver: false,
        gameOver: false,
        paused: false,
        timeScale: 1,
        slowmoTimer: 0,
        roundEndStarted: false,
        particles: [] as Particle[],
        arena: null as ArenaDef | null,
        spawnCallbacks: {} as any,
        mode: 'menu' as 'menu' | 'bot' | 'friend' | 'battle' | 'cars' | 'challenge',
        hp: { blue: 0, red: 0 }, // Battle: текущее HP машин (инициализируется в buildRound)
        headFlash: { blue: 0, red: 0 }, // Battle: секунды до конца неуязвимости/моргания головы
        sawHit: { blue: false, red: false }, // Battle: было касание пилы — ждёт телепорта на спавн
        sawTimer: { blue: 0, red: 0 }, // Battle: секунды с момента удара о пилу
        challenge: null as null | {
          bots: Car[] // заспавненные боты
          dead: Car[] // очередь на уничтожение (внутри step-колбэков мир менять нельзя)
          cells: [number, number][] // безопасные клетки играбельной зоны
          spawnT: number // секунд до следующего спавна
          timeLeft: number // секунд до конца челленджа
          over: boolean // челлендж завершён
        },
      }
      // отладочный доступ (для тестов в браузере)
      if (typeof window !== 'undefined') (window as any).__game = S
      stateRef.current = S

      /* ---- постройка мира (аналог BattleSetupManager.Start) ---- */
      function buildRound() {
        const world = new pl.World({ gravity: new pl.Vec2(0, GRAVITY_Y) })
        S.world = world
        S.ballBodies = []
        S.arenaDrawables = []
        S.particles = []

        /* случайная арена + случайные машины (Addressables labels blueCar/redCar).
           S.forceArena — отладочный хук: имя арены для принудительного выбора. */
        /* режим 'cars': витрина — светло-синий фон, невидимая коробка, жук-Weevil */
        const isCars = S.mode === 'cars'
        const forceName = (S as any).forceArena as string | undefined
        const pool = forceName ? data.arenas.filter((a) => a.name === forceName) : data.arenas
        const arena = isCars
          ? ({ name: 'CarsShowcase', pos: [0, 0], rotZ: 0, children: [], collider: { paths: [] }, spawns: { BlueSpawn: [0, 0.28], RedSpawn: [0, 0.28] }, scale: [1, 1], order: 0, flipX: false, sprite: '' } as any)
          : pool[Math.floor(Math.random() * pool.length)]
        S.arena = arena
        const blueNames = Object.keys(data.cars).filter((n) => data.cars[n].color === 'blue')
        const redNames = Object.keys(data.cars).filter((n) => data.cars[n].color === 'red')
        const force = (S as any).forceCars as { blue?: string; red?: string } | null
        const blueName = force?.blue || blueNames[Math.floor(Math.random() * blueNames.length)]
        const redName = force?.red || redNames[Math.floor(Math.random() * redNames.length)]

        /* арена: статическое тело + chain-колайдеры (внешний контур + полости) */
        const arenaAngle = Math.acos(Math.max(-1, Math.min(1, 0))) // placeholder
        const rotW = (arena as any).rotW ?? null
        const angle = Math.atan2((arena as any).rotZ * 2, 1) // z=sin(θ/2) → θ=z*2 for small; exact: θ=2*atan2(z,w)
        const aAngle = rotW !== null ? 2 * Math.atan2(arena.rotZ, rotW) : 2 * Math.asin(Math.min(1, arena.rotZ))
        const arenaBody = world.createBody({
          type: 'static',
          position: new pl.Vec2(arena.pos[0], arena.pos[1]),
          angle: aAngle,
        })
        if (isCars) {
          /* невидимая коробка-витрина: 4 стенки (fixtures без спрайтов — ничего не рисуется).
             Машина садится на пол с центром на +0.18 выше пола → пол на -0.18,
             чтобы ЦЕНТР КОРПУСА стоящей машины был ровно на середине экрана (y=0). */
          const wall = (x: number, y: number, hw: number, hh: number) =>
            arenaBody.createFixture({ shape: pl.Box(hw, hh, new pl.Vec2(x, y), 0), friction: 0.4 })
          wall(-1.7, 1.02, 0.05, 1.25) // левая
          wall(1.7, 1.02, 0.05, 1.25) // правая
          wall(0, -0.23, 1.75, 0.05) // пол: верх пола на -0.18 → корпус машины на y=0
          wall(0, 2.27, 1.75, 0.05) // крышка
        } else if (arena.collider?.paths) {
          // collider.open — индексы путей-ОТКРЫТЫХ ломаных (например стена Arenas2_2):
          // их нельзя замыкать петлёй, иначе поперёк карты встаёт фантомная хорда
          // (последняя точка → первая). Остальные контуры — замкнутые петли.
          const openPaths: number[] = (arena.collider as { open?: number[] }).open ?? []
          arena.collider.paths.forEach((path, pathIdx) => {
            const verts = path.map((p) => new pl.Vec2(p[0], p[1]))
            arenaBody.createFixture({ shape: pl.Chain(verts, !openPaths.includes(pathIdx)), friction: 0.4 })
          })
        }
        /* X-границы арены (для ИИ: не отступать за край) + Y-низ (для анти-вылета) */
        {
          let mnx = Infinity
          let mxx = -Infinity
          let mny = Infinity
          let mxy = -Infinity
          for (const path of arena.collider?.paths ?? []) {
            for (const p of path) {
              if (p[0] < mnx) mnx = p[0]
              if (p[0] > mxx) mxx = p[0]
              if (p[1] < mny) mny = p[1]
              if (p[1] > mxy) mxy = p[1]
            }
          }
          if (Number.isFinite(mnx) && Number.isFinite(mxx)) (arena as any)._bx = [mnx, mxx]
          if (Number.isFinite(mny)) (arena as any)._by = mny
          if (Number.isFinite(mxy)) (arena as any)._ty = mxy // верх арены (потолок/верх стен)
        }
        // визуал арены
        const rot = (p: Vec, ang: number): Vec => [p[0] * Math.cos(ang) - p[1] * Math.sin(ang), p[0] * Math.sin(ang) + p[1] * Math.cos(ang)]
        if (!isCars) S.arenaDrawables.push({ sprite: arena.sprite!.replace('/', '__') + '.png', pos: arena.pos, angle: aAngle, scale: arena.scale, order: arena.order, flip: arena.flipX })
        for (const ch of arena.children) {
          const w = rot(ch.pos, aAngle)
          const wp: Vec = [arena.pos[0] + w[0] * (arena.scale?.[0] || 1), arena.pos[1] + w[1] * (arena.scale?.[1] || 1)]
          // пила (Img (1)_0): CircleCollider2D r=0.65, HingeJoint2D зажата в собственном
          // центре + мотор 300 deg/s (m_MotorSpeed 300, m_MaximumMotorForce 10000) —
          // крутится на месте, как циркулярная пила. ВАЖНО: у арены фигура в ch.collider,
          // поля circle (как у машин) здесь нет.
          const isSaw = ch.collider?.type === 'circle' && ch.name.includes('Img (1)_0')
          if (ch.sprite && !isSaw) {
            // пила не рисуется здесь — она в ballBodies и вращается физикой
            S.arenaDrawables.push({
              sprite: ch.sprite.replace('/', '__') + '.png',
              pos: wp,
              angle: aAngle + (ch.rotZ ? 2 * Math.asin(Math.min(1, ch.rotZ)) : 0),
              scale: [(ch.scale?.[0] ?? 1) * (arena.scale?.[0] || 1), (ch.scale?.[1] ?? 1) * (arena.scale?.[1] || 1)],
              order: ch.order,
              flip: ch.flipX,
            })
          }
          if (isSaw) {
            const r = (ch.collider as any).radius ?? 0.65
            const bb = world.createBody({ type: 'dynamic', position: new pl.Vec2(wp[0], wp[1]), angularDamping: 0.05 })
            // пила без физической коллизии (sensor): машины и мяч проезжают сквозь,
            // но begin-contact всё равно срабатывает — касание головы = удар головой
            bb.createFixture({ shape: pl.Circle(r), density: 1 / (Math.PI * r * r), friction: 0.4, isSensor: true })
            world.createJoint(
              pl.RevoluteJoint(
                { enableMotor: true, motorSpeed: (300 * Math.PI) / 180, maxMotorTorque: 10000 },
                arenaBody,
                bb, // мотор в Box2D крутит bodyB относительно bodyA — тело пилы вторым
                new pl.Vec2(wp[0], wp[1])
              )
            )
            S.ballBodies.push(bb)
            ;(bb as any)._spriteNode = ch
            ;(bb as any)._isSaw = true
          }
        }

        /* грани мира (Border) */
        const border = world.createBody({ type: 'static' })
        const boxes: [Vec, Vec][] = [
          [[0.10406065, -4.6364994], [12.770463, 1.2543716]],
          [[6.289913, -1.2748871], [0.44500732, 7.9897137]],
          [[-6.037818, -1.2335329], [0.48061752, 8.054941]],
        ]
        for (const [off, size] of boxes) {
          border.createFixture({
            shape: pl.Box(size[0] / 2, size[1] / 2, new pl.Vec2(off[0], off[1]), 0),
            friction: 0.4,
          })
        }

        /* машины. В главном меню: сначала 1 бот, второй подезжает через 3 c */
        /* машины. В главном меню: сначала 1 бот, второй подезжает через 3 c.
           Витрина 'cars': все синие модели, выбор — S.carsIndex (стрелки ‹ › в UI). */
        /* витрина: синие модели по возрастанию редкости (Common → Legendary),
           внутри тира — исходный порядок из game_data.json; выбор — S.carsIndex */
        const rarityRank: Record<string, number> = { Common: 0, Rare: 1, Epic: 2, Legendary: 3 }
        const showcaseList = isCars
          ? Object.keys(data.cars)
              .filter((n) => n.startsWith('Blue'))
              .sort(
                (a, b) =>
                  rarityRank[CAR_RARITY[a.replace(/^Blue/, '')] ?? 'Common'] -
                  rarityRank[CAR_RARITY[b.replace(/^Blue/, '')] ?? 'Common'],
              )
          : []
        if (isCars && (S as any).carsIndex === undefined) (S as any).carsIndex = showcaseList.indexOf('BlueWeevil')
        const showName = isCars ? showcaseList[(S as any).carsIndex ?? 0] : S.mode === 'challenge' ? 'BlueMonster' : blueName
        if (isCars) setCarsModel(showName.replace(/^Blue/, '')) // бейдж редкости над машиной
        S.blue = new Car(world, data.cars[showName], arena.spawns.BlueSpawn, 'blue')
        if (isCars) {
          // витрина: только жук-Weevil, без соперника и без управления
          S.red = null
          ;(S as any).pendingRed = null
        } else if (S.mode === 'menu') {
          // старый красный бот (в т.ч. проигравший) не должен оставаться «статуей»
          // из прошлого мира — сбрасываем, второй бот заспавнится через 3 c
          S.red = null
          ;(S as any).pendingRed = { def: data.cars[redName], spawn: arena.spawns.RedSpawn }
          ;(S as any).menuRedTimer = 3 // секунды до спавна второго бота
        } else if (S.mode === 'challenge') {
          // челлендж: игрок один (Monster), боты Antique Formula спавнятся в процессе
          S.red = null
          ;(S as any).pendingRed = null
        } else {
          S.red = new Car(world, data.cars[redName], arena.spawns.RedSpawn, 'red')
        }
        // Battle: HP каждой машины по редкости её модели — доступно с самого начала раунда
        if (S.mode === 'battle' && S.blue && S.red) {
          S.hp = { blue: carMaxHp(S.blue.def.carType), red: carMaxHp(S.red.def.carType) }
        }
        // Challenge: HP игрока (Monster — Legendary 2300), у ботов HP не считается
        if (S.mode === 'challenge' && S.blue) {
          S.hp = { blue: carMaxHp(S.blue.def.carType), red: 0 }
        }
        S.headFlash = { blue: 0, red: 0 } // новый раунд — без неуязвимости
        S.sawHit = { blue: false, red: false } // новый раунд — таймеры пилы сброшены
        S.sawTimer = { blue: 0, red: 0 }
        S.challenge = null // боты прошлого челленджа принадлежали прошлому миру
        /* Спавн поверх рельефа: у машин с низко висящими колёсами (например Monster
           на Arenas1_0) точка спавна из префаба лежит ниже пола арены — колёса
           оказываются в камне и машина заклинивает (wheels ω=0). Поднимаем сборку
           на верхнюю опорную поверхность под машиной; поднятую позицию запоминаем
           в startPos, чтобы reset() возвращал машину туда же. */
        const liftToGround = (car: Car | null) => {
          if (!car) return
          const fp = carFootprint(car.def)
          if (!isFinite(fp.minY)) return
          const sx = car.startPos[0]
          const sy = car.startPos[1]
          const ca = Math.cos(aAngle), sa = Math.sin(aAngle)
          const aPos = arenaBody.getPosition()
          const xLo = sx + fp.minX, xHi = sx + fp.maxX
          let top = -Infinity
          for (const path of arena.collider?.paths ?? []) {
            for (let i = 0; i < path.length; i++) {
              const p1 = path[i]
              const p2 = path[(i + 1) % path.length]
              const w1x = aPos.x + p1[0] * ca - p1[1] * sa
              const w1y = aPos.y + p1[0] * sa + p1[1] * ca
              const w2x = aPos.x + p2[0] * ca - p2[1] * sa
              const w2y = aPos.y + p2[0] * sa + p2[1] * ca
              const lo = Math.max(Math.min(w1x, w2x), xLo)
              const hi = Math.min(Math.max(w1x, w2x), xHi)
              if (hi <= lo) continue
              const xm = (lo + hi) / 2
              const t = w2x === w1x ? 0 : (xm - w1x) / (w2x - w1x)
              const y = w1y + t * (w2y - w1y)
              // опора — верх сегмента ниже центра спавна (стенки сбоку не считаем)
              if (y < sy + 0.2 && y > top) top = y
            }
          }
          if (!isFinite(top)) return
          const lift = top + 0.04 - (sy + fp.minY)
          if (lift <= 0.001) return
          const shift = (b: pl.Body) => {
            const p = b.getPosition()
            b.setPosition(new pl.Vec2(p.x, p.y + lift))
          }
          shift(car.body)
          for (const w of car.wheels) shift(w)
          if (car.head) shift(car.head)
          car.startPos = [car.startPos[0], car.startPos[1] + lift]
        }
        liftToGround(S.blue)
        liftToGround(S.red)
        ;(S as any).liftToGround = liftToGround
        ;(S as any).spawnFx = spawnParticles // для телепортов вне buildRound (анти-застревание)
        ;(S as any).endRound = endRound // финал раунда при вылете за карту с HP = 0

        /* HeadCollision: любое касание головы → ReportHeadHit */
        world.on('begin-contact', (contact) => {
          const fa = contact.getFixtureA()
          const fb = contact.getFixtureB()
          const ba = fa.getBody()
          const bb = fb.getBody()
          const blueHit = S.blue && (ba === S.blue.head || bb === S.blue.head)
          const redHit = S.red && (ba === S.red.head || bb === S.red.head)
          // Battle: касание пилы любой частью машины (корпус/колесо/голова) —
          // через 2 c машина телепортируется на спавн (не висит в пиле до конца раунда)
          const sawB = (ba as any)._isSaw ? ba : (bb as any)._isSaw ? bb : null
          if (sawB && S.mode === 'battle' && !S.roundOver) {
            const other = sawB === ba ? bb : ba
            const key: CarType | null =
              S.blue && (other === S.blue.body || other === S.blue.head || S.blue.wheels.includes(other))
                ? 'blue'
                : S.red && (other === S.red.body || other === S.red.head || S.red.wheels.includes(other))
                  ? 'red'
                  : null
            if (key) {
              S.sawHit[key] = true
              S.sawTimer[key] = 0 // отсчёт заново от свежего удара о пилу
            }
          }
          /* CHALLENGE: голова ИГРОКА при касании чего угодно получает урон
             (reportHeadHit). Голова бита, коснувшаяся чего угодно (машина игрока,
             арена, пила, другой бот), убивает бита с ОДНОГО удара — тела ставятся
             в очередь ch.dead и уничтожаются ПОСЛЕ шага физики: внутри step-колбэков
             мир менять (destroyBody) нельзя. Никаких телепортов/респавна. */
          if (S.mode === 'challenge') {
            const ch = S.challenge
            const playerHead = !!S.blue && (ba === S.blue.head || bb === S.blue.head)
            if (playerHead && !S.roundOver) reportHeadHit('blue')
            if (ch && !ch.over) {
              const blueParts: pl.Body[] = S.blue ? [S.blue.body, ...S.blue.wheels, S.blue.head] : []
              for (const b of ch.bots) {
                if (ba !== b.head && bb !== b.head) continue
                /* бит умирает с ОДНОГО УДАРА машиной (игрока или другого бита).
                   Касание головой статичного рельефа/пилы — НЕ смерть: иначе биты
                   гибли сами при посадке после спавна и езде по рельефу */
                const other = ba === b.head ? bb : ba
                const hitsCar =
                  blueParts.includes(other) || ch.bots.some((o) => o !== b && [o.body, ...o.wheels, o.head].includes(other))
                if (hitsCar && !ch.dead.includes(b)) ch.dead.push(b)
              }
            }
            contact.setFriction(Math.max(fa.getFriction(), fb.getFriction()))
            return
          }
          if (!S.roundOver && S.mode !== 'cars' && (blueHit || redHit)) {
            const loser: CarType = blueHit ? 'blue' : 'red'
            const car = loser === 'blue' ? S.blue : S.red
            // эффект ломания головы спавним в reportHeadHit — только когда удар
            // оказался финальным (в battle нефатальные удары дают лишь моргание)
            if (S.mode !== 'battle') car!.lockMovement()
            reportHeadHit(loser)
          } else {
            // режим комбинирования трения у материалов машин — Maximum (PhysicsMaterial2D)
            contact.setFriction(Math.max(fa.getFriction(), fb.getFriction()))
          }
        })

        function spawnParticles(x: number, y: number) {
          for (let i = 0; i < 14; i++) {
            const a = Math.random() * Math.PI * 2
            const v = 1.5 + Math.random() * 3
            S.particles.push({
              x,
              y,
              vx: Math.cos(a) * v,
              vy: Math.sin(a) * v,
              life: 0.4 + Math.random() * 0.3,
              size: 0.04 + Math.random() * 0.08,
            })
          }
        }
        function endRound(loser: CarType) {
          // финал раунда: эффект ломания головы + очко победителю + slow-mo.
          // Вызывается из reportHeadHit (фатальный удар) и из анти-застревания
          // (вылет за карту, когда после штрафа 400 HP = 0 в battle).
          if (S.roundOver) return
          const winner: CarType = loser === 'blue' ? 'red' : 'blue'
          // эффект ломания головы — только на финале (в battle HP = 0,
          // в остальных режимах любой удар головы фатален)
          const lcar = (loser === 'blue' ? S.blue : S.red)!
          const lhpPos = lcar.head.getPosition()
          spawnParticles(lhpPos.x, lhpPos.y)
          if (S.mode === 'menu') {
            // демо-бой в меню: без очков и панелей — slow-mo и пересборка раунда
            S.roundOver = true
            S.blue?.lockMovement()
            S.red?.lockMovement()
            S.timeScale = 0.5
            S.slowmoTimer = ROUND_END_SLOWMO
            S.roundEndStarted = true
            return
          }
          S.roundOver = true
          if (winner === 'blue') S.score.blue++
          else S.score.red++
          S.spawnCallbacks.onScore(winner)
          // HandleRoundEnd
          S.blue!.lockMovement()
          S.red!.lockMovement()
          S.timeScale = 0.5
          S.slowmoTimer = ROUND_END_SLOWMO
          S.roundEndStarted = true
        }
        function reportHeadHit(loser: CarType) {
          if (S.roundOver) return
          const winner: CarType = loser === 'blue' ? 'red' : 'blue'
          if (S.mode === 'challenge') {
            // Challenge: бьётся только голова ИГРОКА (о что угодно — боты, арена,
            // пила); бот Antique Formula — Common, т.е. 300 за удар, 3 c неуязвимость
            if (S.headFlash.blue > 0) return // урон в неуязвимость не проходит
            S.hp.blue = Math.max(0, S.hp.blue - RARITY_DMG.Common)
            S.headFlash.blue = 3 // секунды моргания + неуязвимость
            if (S.hp.blue > 0) return // выжил — игра продолжается
            challengeEnd(false) // HP кончилось → поражение
            return
          }
          if (S.mode === 'battle') {
            // Battle: удар головой НЕ завершает раунд — тот, кто ударился,
            // теряет HP, равное урону машины соперника (редкость → урон наоборот).
            // 3 c после получения урона голова моргает белым и неуязвима.
            if (S.headFlash[loser] > 0) return // урон в неуязвимость не проходит
            const wcar = (winner === 'blue' ? S.blue : S.red)!
            S.hp[loser] = Math.max(0, S.hp[loser] - carDamage(wcar.def.carType))
            S.headFlash[loser] = 3 // секунды моргания + неуязвимость
            if (S.hp[loser] > 0) return // раунд продолжается — без эффекта ломания
            // HP кончилось → обычное завершение раунда
          }
          endRound(loser)
        }

        /* Играбельная зона карты: сетка 0.5 c BFS-заливкой от спавнов по статике
           арены (машины — динамика, не учитываются). Клетка достижима, если машина
           может проехать туда от спавна, не пересекая стены. Всё вне достижимости
           (крыша закрытых карт, карманы, полости в стенах) запрещено для телепортов
           и включается «спасательным» watchdog'ом — оттуда гарантируется возврат. */
        {
          const world = S.world
          const abx = (arena as any)._bx as [number, number] | undefined
          const aby = (arena as any)._by as number | undefined
          const aty = (arena as any)._ty as number | undefined
          if (world && abx && aby !== undefined && aty !== undefined) {
            const cs = 0.5
            const x0 = abx[0] - 1.0
            const y0 = aby - 1.0
            const w = Math.max(1, Math.ceil((abx[1] + 1.0 - x0) / cs))
            const h = Math.max(1, Math.ceil((aty + 1.0 - y0) / cs))
            // собираем статическую геометрию один раз: точные отрезки цепей
            // (chain — ОДИН fixture на весь контур арены, его AABB накрывает всю
            // карту, поэтому тестируются сами сегменты) и AABB остальных форм
            const segs: number[][] = []
            const boxes: number[][] = []
            // AABB формы для Box/Polygon/Circle (точный, не fat broadphase)
            const shapeBox = (f: pl.Fixture): [number, number, number, number] | null => {
              const s = f.getShape() as any
              const xf = f.getBody().getTransform()
              const ang = xf.q.getAngle()
              const c = Math.cos(ang)
              const sn = Math.sin(ang)
              const px = xf.p.x
              const py = xf.p.y
              let mnx = Infinity
              let mny = Infinity
              let mxx = -Infinity
              let mxy = -Infinity
              if (Array.isArray(s.m_vertices) && s.m_vertices.length) {
                for (const v of s.m_vertices) {
                  const wx = px + c * v.x - sn * v.y
                  const wy = py + sn * v.x + c * v.y
                  if (wx < mnx) mnx = wx
                  if (wx > mxx) mxx = wx
                  if (wy < mny) mny = wy
                  if (wy > mxy) mxy = wy
                }
              } else if (s.m_p && typeof s.m_radius === 'number') {
                const wx = px + c * s.m_p.x - sn * s.m_p.y
                const wy = py + sn * s.m_p.x + c * s.m_p.y
                mnx = wx - s.m_radius
                mxx = wx + s.m_radius
                mny = wy - s.m_radius
                mxy = wy + s.m_radius
              } else {
                return null
              }
              return [mnx, mny, mxx, mxy]
            }
            const gridBox = new pl.AABB(new pl.Vec2(x0 - 1, y0 - 1), new pl.Vec2(x0 + w * cs + 1, y0 + h * cs + 1))
            world.queryAABB(gridBox, (f) => {
              if (f.getBody().isDynamic()) return true
              const type = f.getType()
              const xf = f.getBody().getTransform()
              const ang = xf.q.getAngle()
              const c = Math.cos(ang)
              const sn = Math.sin(ang)
              const px = xf.p.x
              const py = xf.p.y
              const tp = (v: pl.Vec2Value): [number, number] => [px + c * v.x - sn * v.y, py + sn * v.x + c * v.y]
              if (type === 'chain' || type === 'edge') {
                const s = f.getShape() as any
                const vs: pl.Vec2Value[] = type === 'edge' ? [s.m_vertex1, s.m_vertex2] : s.m_vertices
                for (let k = 0; k < vs.length - 1; k++) {
                  const a = tp(vs[k])
                  const d = tp(vs[k + 1])
                  segs.push([a[0], a[1], d[0], d[1]])
                }
                if (type === 'chain' && s.m_isLoop && vs.length > 2) {
                  // замыкающий сегмент петли — тоже стена
                  const a = tp(vs[vs.length - 1])
                  const d = tp(vs[0])
                  segs.push([a[0], a[1], d[0], d[1]])
                }
              } else {
                // Box / Polygon / Circle: их AABB точен (углы у Box арены = 0)
                const sb = shapeBox(f)
                if (sb) boxes.push(sb)
              }
              return true
            })
            /* Классификация клеток по статической геометрии. Центр корпуса едет на
               0.3-0.4 ВЫШЕ поверхности под колёсами и остаётся в той же клетке, что
               и линия поверхности, поэтому пологие линии не блокируют свою клетку:
               - wallB — крутые сегменты (стены) и боксы: блокируют всё;
               - ceilB — пологие сегменты в ВЕРХНЕЙ части клетки (потолки/крыши):
                 блокируют reach и падение вниз (сквозь крышу не провалиться);
               - пол-подобные линии (пологие у дна клетки) — не блокируют вовсе.
               Итог: земля/наклоны проходимы, крыша закрытой карты — непроницаема. */
            const wallB = new Uint8Array(w * h)
            const ceilB = new Uint8Array(w * h)
            for (let j = 0; j < h; j++) {
              for (let i = 0; i < w; i++) {
                const lx = x0 + i * cs
                const ly = y0 + j * cs
                const rx = lx + cs
                const ry = ly + cs
                const midY = ly + 0.35 * cs // граница «пол-подобно» / «потолочно»
                let wall = false
                let ceil = false
                for (const s of segs) {
                  const sx0 = Math.min(s[0], s[2])
                  const sx1 = Math.max(s[0], s[2])
                  if (sx1 <= lx || sx0 >= rx) continue // не пересекает клетку по x
                  let ya: number
                  let yb: number
                  if (sx1 - sx0 < 1e-9) {
                    ya = Math.min(s[1], s[3])
                    yb = Math.max(s[1], s[3])
                  } else {
                    // y-диапазон сегмента внутри x-окна клетки
                    const t0 = (Math.max(lx, sx0) - sx0) / (sx1 - sx0)
                    const t1 = (Math.min(rx, sx1) - sx0) / (sx1 - sx0)
                    const y0c = s[1] + (s[3] - s[1]) * t0
                    const y1c = s[1] + (s[3] - s[1]) * t1
                    ya = Math.min(y0c, y1c)
                    yb = Math.max(y0c, y1c)
                  }
                  if (yb <= ly || ya >= ry) continue // вне клетки по y
                  if (Math.abs(s[2] - s[0]) < 0.5 * Math.abs(s[3] - s[1])) {
                    wall = true // круче ~63° — стена
                    break
                  }
                  if (ya >= midY) ceil = true // целиком в верхней части — потолок/крыша
                  // иначе — пол-подобная поверхность: центр корпуса едет выше неё
                  // в этой же клетке — не блокирует
                }
                if (!wall && !ceil) {
                  for (const s of boxes) {
                    if (s[2] <= lx || s[0] >= rx) continue
                    if (s[3] <= midY) continue // верх бокса у дна клетки — пол-подобно
                    if (s[3] > ly && s[1] < ry) {
                      wall = true
                      break
                    }
                  }
                }
                const idx = j * w + i
                if (wall) wallB[idx] = 1
                else if (ceil) ceilB[idx] = 1
              }
            }
            /* Потолочная огибающая по колонкам: для каждой колонки — самая верхняя
               статическая геометрия в ней. Если огибающая НЕПРЕРЫВНА над серединой
               арены (закрытая карта: купол/крыша), всё небо над ней объявляется вне
               карты — независимо от того, в какую часть клетки попала линия крыши.
               У открытых карт огибающая над серединой отсутствует — небо не трогаем,
               прыжки над стенами остаются легальными. */
            const env = new Float64Array(w).fill(-Infinity)
            for (const s of segs) {
              const sx0 = Math.min(s[0], s[2])
              const sx1 = Math.max(s[0], s[2])
              const i0 = Math.max(0, Math.floor((sx0 - x0) / cs))
              const i1 = Math.min(w - 1, Math.floor((sx1 - x0) / cs))
              const top = Math.max(s[1], s[3])
              for (let i = i0; i <= i1; i++) if (top > env[i]) env[i] = top
            }
            for (const s of boxes) {
              const i0 = Math.max(0, Math.floor((s[0] - x0) / cs))
              const i1 = Math.min(w - 1, Math.floor((s[2] - x0) / cs))
              for (let i = i0; i <= i1; i++) if (s[3] > env[i]) env[i] = s[3]
            }
            let maxSpawnY = -Infinity
            for (const c of [S.blue, S.red]) if (c && c.startPos[1] > maxSpawnY) maxSpawnY = c.startPos[1]
            const iFrom = Math.floor(w * 0.2)
            const iTo = Math.ceil(w * 0.8)
            let sealed = true
            for (let i = iFrom; i < iTo; i++) {
              if (env[i] === -Infinity || env[i] < maxSpawnY + 2.0) {
                sealed = false
                break
              }
            }
            if (sealed) {
              for (let i = 0; i < w; i++) {
                if (env[i] === -Infinity) continue
                const j0 = Math.max(0, Math.ceil((env[i] - 0.1 - y0) / cs))
                for (let j = j0; j < h; j++) wallB[j * w + i] = 1
              }
            }
            const reach = new Uint8Array(w * h)
            const queue: number[] = []
            for (const c of [S.blue, S.red]) {
              if (!c) continue
              let ci = Math.floor((c.startPos[0] - x0) / cs)
              let cj = Math.floor((c.startPos[1] - y0) / cs)
              if (ci < 0 || cj < 0 || ci >= w || cj >= h || wallB[cj * w + ci] || ceilB[cj * w + ci]) {
                // спавн в заблокированной клетке — ближайшая свободная в радиусе 1.5
                let found = false
                for (let r = 1; r <= 3 && !found; r++) {
                  for (let dj = -r; dj <= r && !found; dj++) {
                    for (let di = -r; di <= r && !found; di++) {
                      const i2 = ci + di
                      const j2 = cj + dj
                      if (i2 < 0 || j2 < 0 || i2 >= w || j2 >= h) continue
                      if (!wallB[j2 * w + i2] && !ceilB[j2 * w + i2]) {
                        ci = i2
                        cj = j2
                        found = true
                      }
                    }
                  }
                }
              }
              if (ci >= 0 && cj >= 0 && ci < w && cj < h) {
                const idx = cj * w + ci
                if (!wallB[idx] && !ceilB[idx] && !reach[idx]) {
                  reach[idx] = 1
                  queue.push(idx)
                }
              }
            }
            while (queue.length) {
              const idx = queue.pop()!
              const i = idx % w
              const j = (idx - i) / w
              const nb = [
                [i + 1, j],
                [i - 1, j],
                [i, j + 1],
                [i, j - 1],
              ]
              for (const [ni, nj] of nb) {
                if (ni < 0 || nj < 0 || ni >= w || nj >= h) continue
                const nidx = nj * w + ni
                if (!wallB[nidx] && !ceilB[nidx] && !reach[nidx]) {
                  reach[nidx] = 1
                  queue.push(nidx)
                }
              }
            }
            const cellRect = (i: number, j: number): [number, number] => [x0 + i * cs, y0 + j * cs]
            const cellDist = (x: number, y: number, rx: number, ry: number) => Math.hypot(Math.max(rx - x, 0, x - (rx + cs)), Math.max(ry - y, 0, y - (ry + cs)))
            const playableAt = (x: number, y: number) => {
              const i = Math.floor((x - x0) / cs)
              const j = Math.floor((y - y0) / cs)
              return i >= 0 && j >= 0 && i < w && j < h && reach[j * w + i] === 1
            }
            const distToPlayable = (x: number, y: number) => {
              const ci = Math.floor((x - x0) / cs)
              const cj = Math.floor((y - y0) / cs)
              let best = Infinity
              const rMax = 7 // ~3.5 юнита; дальше — «совсем снаружи», тоже потерян
              for (let dj = -rMax; dj <= rMax; dj++) {
                for (let di = -rMax; di <= rMax; di++) {
                  const i = ci + di
                  const j = cj + dj
                  if (i < 0 || j < 0 || i >= w || j >= h) continue
                  if (!reach[j * w + i]) continue
                  const [rx, ry] = cellRect(i, j)
                  const d = cellDist(x, y, rx, ry)
                  if (d < best) best = d
                }
              }
              return best
            }
            const nearestPlayable = (x: number, y: number): [number, number] => {
              let bi = -1
              let bj = -1
              let best = Infinity
              for (let j = 0; j < h; j++) {
                for (let i = 0; i < w; i++) {
                  if (!reach[j * w + i]) continue
                  const [rx, ry] = cellRect(i, j)
                  const d = cellDist(x, y, rx, ry)
                  if (d < best) {
                    best = d
                    bi = i
                    bj = j
                  }
                }
              }
              if (bi >= 0) return [x0 + (bi + 0.5) * cs, y0 + (bj + 0.5) * cs]
              // дегенерат: ни одной достижимой клетки — грубый кламп в габариты
              return [Math.min(Math.max(x, abx[0] + 1.3), abx[1] - 1.3), Math.min(y, aty - 0.8)]
            }
            let closed = true
            for (let i = 0; i < w; i++)
              if (reach[(h - 1) * w + i]) {
                closed = false
                break
              }
            const canReturn = (x: number, y: number): boolean => {
              // может ли машина из точки (x, y) вернуться в играбельную зону,
              // двигаясь только «вбок» (езда) и «вниз» (падение) — вверх она
              // подняться не может. Вбок блокируют только стены; вниз — стены И
              // потолки (сквозь крышу закрытой карты не провалиться). Реверс-BFS
              // от клетки машины до любой клетки, достижимой из спавнов. Крыша,
              // карманы в стенах, внешние площадки за стенами и полости дают
              // false → потеряна. Наклоны и земля — пол-подобные клетки, проходятся.
              const ci0 = Math.floor((x - x0) / cs)
              const cj0 = Math.floor((y - y0) / cs)
              if (ci0 < 0 || cj0 < 0 || ci0 >= w || cj0 >= h) return false // за сеткой
              if (reach[cj0 * w + ci0]) return true // уже в играбельной зоне
              const seen = new Uint8Array(w * h)
              const q: number[] = [cj0 * w + ci0]
              seen[cj0 * w + ci0] = 1
              while (q.length) {
                const idx = q.pop()!
                const i = idx % w
                const j = (idx - i) / w
                const tryCell = (ni: number, nj: number, down: boolean) => {
                  if (ni < 0 || nj < 0 || ni >= w || nj >= h) return
                  const nidx = nj * w + ni
                  if (seen[nidx] || wallB[nidx] || (down && ceilB[nidx])) return
                  seen[nidx] = 1
                  if (reach[nidx]) {
                    found = true
                    return
                  }
                  q.push(nidx)
                }
                let found = false
                tryCell(i + 1, j, false)
                tryCell(i - 1, j, false)
                tryCell(i, j - 1, true)
                if (found) return true
              }
              return false
            }
            let nWall = 0
            let nCeil = 0
            for (let k = 0; k < wallB.length; k++) {
              if (wallB[k]) nWall++
              else if (ceilB[k]) nCeil++
            }
            ;(S as any)._playGrid = { x0, y0, cs, w, h, reach, wallB, ceilB, closed, playableAt, canReturn, distToPlayable, nearestPlayable, sealed, nWall, nCeil }
          }
        }
        /* CHALLENGE: точки спавна ботов и спавнер. Клетки — из BFS-играбельной
           сетки + жёсткая валидация «клетка НАД ЗЕМЛЁЙ»: рейкаст вниз обязан
           найти статичную несенсорную опору в пределах 1.1 юнита. Дело в том,
           что BFS открытых сверху арен (чаши, лабиринты с невысокими стенами)
           затекает в воздушные клетки над стенами и в пустоту за коллизией —
           боты там появлялись «из ниоткуда» и падали за карту. Конкретная
           точка дополнительно проверяется botFree (AABB сборки бота свободен
           от арены, пил, игрока и уже заспавненных ботов) + дистанция до игрока. */
        if (S.mode === 'challenge') {
          const g = (S as any)._playGrid as PlayGrid | null
          const cells: [number, number][] = []
          if (g && S.world) {
            const groundedCells = (maxDrop: number): [number, number][] => {
              const out: [number, number][] = []
              for (let gy = 0; gy < g.h; gy++) {
                for (let gx = 0; gx < g.w; gx++) {
                  if (!g.reach[gy * g.w + gx]) continue
                  const x = g.x0 + (gx + 0.5) * g.cs
                  const y = g.y0 + (gy + 0.5) * g.cs
                  let ground = false
                  S.world!.rayCast(new pl.Vec2(x, y), new pl.Vec2(x, y - maxDrop), (f) => {
                    if (f.isSensor()) return -1 // пила — не земля
                    if (!f.getBody().isStatic()) return -1 // движущиеся тела — не земля
                    ground = true
                    return 0
                  })
                  if (ground) out.push([x, y])
                }
              }
              return out
            }
            let grounded = groundedCells(1.1)
            if (grounded.length < 8) {
              // страховка: на арене с высоким полом/платформами ослабляем предел,
              // но требуем строго больше клеток, чем дал строгий проход
              const wide = groundedCells(2.2)
              if (wide.length > grounded.length) grounded = wide
            }
            cells.push(...grounded)
          }
          const cfg = CHALLENGES[Math.floor(Math.random() * CHALLENGES.length)]
          S.challenge = { bots: [], dead: [], cells, spawnT: 0, timeLeft: cfg.duration, over: false }
          const def = data.cars[cfg.botCar]
          /* точный AABB сборки бота (корпус+колёса+голова) вместо жёсткого ±1.8 из
             spotFree: на тесных картах у играбельных клеток нет 3.6 юнитов ширины,
             и бот вообще никогда не находит места. m — запас, чтобы не впритык. */
          const botBox = (() => {
            let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity
            const nodes: CarNode[] = [def.tree, ...(def.tree.children || [])]
            for (const n of nodes) {
              const px = (n.pos && n.pos[0]) || 0
              const py = (n.pos && n.pos[1]) || 0
              if (n.poly) {
                for (const path of n.poly.paths) {
                  for (const p of path) {
                    const x = px + p[0], y = py + p[1]
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                  }
                }
              }
              if (n.circle) {
                const r = n.circle.r
                if (px - r < minX) minX = px - r
                if (px + r > maxX) maxX = px + r
                if (py - r < minY) minY = py - r
                if (py + r > maxY) maxY = py + r
              }
            }
            if (!isFinite(minX)) {
              minX = -0.95
              maxX = 0.95
              minY = -0.65
              maxY = 0.65
            }
            return { minX, maxX, minY, maxY }
          })()
          const botFree = (x: number, y: number): boolean => {
            if (!S.world) return false
            const m = 0.12
            const box = new pl.AABB(new pl.Vec2(x + botBox.minX - m, y + botBox.minY - m), new pl.Vec2(x + botBox.maxX + m, y + botBox.maxY + m))
            let free = true
            S.world.queryAABB(box, () => {
              free = false // любое тело (арена, пила, игрок, боты) — место занято
              return false
            })
            return free
          }
          const despawnFx = (x: number, y: number) => {
            const fx = (S as any).spawnFx as ((x: number, y: number) => void) | undefined
            if (fx) fx(x, y)
          }
          ;(S as any).spawnChallengeBot = () => {
            const ch = S.challenge
            if (!S.world || !ch || ch.over || S.mode !== 'challenge') return
            if (ch.bots.length >= cfg.maxBots) {
              // лимит одновременных ботов: старейший исчезает с эффектом
              const old = ch.bots.shift()!
              const op = old.body.getPosition()
              despawnFx(op.x, op.y)
              for (const b of [old.body, ...old.wheels, old.head]) if (b) S.world!.destroyBody(b)
            }
            if (!def || ch.cells.length === 0) return
            const pp = S.blue?.body.getPosition()
            for (let t = 0; t < CHALLENGE_SPAWN_TRIES; t++) {
              const c = ch.cells[Math.floor(Math.random() * ch.cells.length)]
              if (pp && Math.hypot(pp.x - c[0], pp.y - c[1]) < CHALLENGE_MIN_PLAYER_DIST) continue // не на игроке
              if (!botFree(c[0], c[1] + 0.1)) continue // не в аренах/пилах/ботах/игроке
              const car = new Car(S.world, def, [c[0], c[1] + 0.1], 'red')
              despawnFx(c[0], c[1] + 0.1) // эффект появления
              ch.bots.push(car)
              return
            }
            // свободных точек не нашлось — тик пропускается: спавн только в безопасное место
          }
        }
        S.spawnCallbacks.onBuilt?.()
      }

      /* отладочный хук: window.__game.forceCars = {blue:'BlueCart', red:'RedCart'} */
      ;(S as any).buildRound = buildRound
      ;(S as any).data = data

      S.spawnCallbacks.onBuilt = () => {
        setReady(true)
        setSpinStar(null)
      }
      S.spawnCallbacks.onMode = (m: 'menu' | 'bot' | 'friend' | 'battle' | 'challenge') => setMode(m)

      /* ---- рендер ---- */
      function drawSprite(img: HTMLImageElement, meta: { px: number[]; ppu: number; pivot: number[] }, pos: Vec, angle: number, scale: Vec, flip: boolean) {
        const s = view.scale
        const wUnits = (meta.px[0] / meta.ppu) * (scale?.[0] || 1)
        const hUnits = (meta.px[1] / meta.ppu) * (scale?.[1] || 1)
        const w = wUnits * s
        const h = hUnits * s
        const [sx, sy] = worldToScreen(pos[0], pos[1])
        ctx.save()
        ctx.translate(sx, sy)
        ctx.rotate(-angle)
        if (flip) ctx.scale(-1, 1)
        ctx.imageSmoothingEnabled = false
        ctx.drawImage(img, -w / 2, -h / 2, w, h)
        ctx.restore()
      }

      const view = { scale: 1, cx: 0, cy: 0 }
      function worldToScreen(x: number, y: number): [number, number] {
        return [view.cx + x * view.scale, view.cy - y * view.scale]
      }

      /* пиксельный белый кружок: сетка квадратиков 2-6 px вместо гладкого arc */
      function drawPixelCircle(sx: number, sy: number, rPx: number, alpha: number) {
        if (rPx < 1 || alpha <= 0) return
        let cell = Math.round(rPx / 3)
        if (cell < 2) cell = 2
        if (cell > 6) cell = 6
        if (cell % 2) cell -= 1 // чётный блок — пиксели ровно ложатся на сетку
        const rn = rPx / cell
        const n = Math.ceil(rn)
        const x0 = Math.round(sx)
        const y0 = Math.round(sy)
        ctx.globalAlpha = alpha
        ctx.fillStyle = '#fff'
        for (let gy = -n; gy <= n; gy++) {
          for (let gx = -n; gx <= n; gx++) {
            if (gx * gx + gy * gy <= rn * rn) {
              ctx.fillRect(x0 + gx * cell - cell / 2, y0 + gy * cell - cell / 2, cell, cell)
            }
          }
        }
        ctx.globalAlpha = 1
      }

      function render() {
        const cw = canvas.width
        const chh = canvas.height
        ctx.imageSmoothingEnabled = false
        ctx.fillStyle = BG_COLOR
        ctx.fillRect(0, 0, cw, chh)
        // витрина машин: зум мира — машина и эффект крупнее; фону (трибуны)
        // компенсируем обратным масштабом и сдвигом, чтобы стадион выглядел
        // ровно как в битве (та же экранная позиция и размер)
        const zoom = S.mode === 'cars' ? 1.7 : 1
        view.scale = (chh / (2 * ORTHO)) * zoom
        view.cx = cw / 2
        view.cy = chh / 2

        // фон: люди (order 0/1) — общий фон битвы и витрины машин
        const s = view.scale
        const drawList: { order: number; fn: () => void }[] = []
        const peopleBg = images[SPR.peopleBg]
        const people = images[SPR.people]
        const pbMeta = { px: [peopleBg.width, peopleBg.height], ppu: 48, pivot: [0.5, 0.5] }
        const pMeta = { px: [people.width, people.height], ppu: 48, pivot: [0.5, 0.5] }
        drawList.push({ order: 0, fn: () => drawSprite(peopleBg, pbMeta, [0, -0.6 / zoom], 0, [1 / zoom, 1 / zoom], false) })
        drawList.push({ order: 1, fn: () => drawSprite(people, pMeta, [0, -0.59 / zoom], 0, [1 / zoom, 1 / zoom], false) })
        // витрина машин: белый вращающийся эффект (SpinEffects из выигрыша раунда)
        // рисуется В КАНВАСЕ с order 2 — позади машины (машина идёт с order 1000+)
        if (S.mode === 'cars') {
          const spinImg = images['SpinEffects__SpinEffects_0.png']
          const spinMeta = spriteMeta['SpinEffects__SpinEffects_0.png']
          if (spinImg && spinMeta) {
            const sc = (2.2 * spinMeta.ppu) / spinMeta.px[0] // ~2.2 юнита (с зумом ~73% высоты экрана)
            const ang = -(performance.now() / 1000) * ((Math.PI * 2) / 9) // оборот за 9 c
            drawList.push({
              order: 2,
              fn: () => {
                ctx.save()
                ctx.filter = 'brightness(0) invert(1)' // реально белый
                drawSprite(spinImg, spinMeta, [0, 0], ang, [sc, sc], false)
                ctx.restore()
              },
            })
          }
        }
        for (const d of S.arenaDrawables) {
          const meta = spriteMeta[d.sprite]
          drawList.push({ order: d.order, fn: () => drawSprite(images[d.sprite], meta, d.pos, d.angle, d.scale, d.flip) })
        }
        // машины (sorting layer 1 → порядок 1000+)
        const drawCar = (car: Car | null) => {
          if (!car) return
          const items: { order: number; fn: () => void }[] = []
          const addBody = (b: pl.Body) => {
            const node = (b as any)._spriteNode
            if (!node?.sprite) return
            const img = images[node.sprite.replace('/', '__') + '.png']
            if (!img) return
            const meta = spriteMeta[node.sprite.replace('/', '__') + '.png']
            const p = b.getPosition()
            items.push({ order: node.order ?? 2, fn: () => drawSprite(img, meta, [p.x, p.y], b.getAngle(), node.scale || [1, 1], node.flipX) })
          }
          addBody(car.body)
          for (const w of car.wheels) addBody(w)
          addBody(car.head)
          for (const it of items) drawList.push({ order: 1000 + it.order, fn: it.fn })
          // Battle/Challenge: голова, получившая урон, плавно моргает белым, пока действует неуязвимость
          const headNode = (car.head as any)?._spriteNode
          if ((S.mode === 'battle' || S.mode === 'challenge') && headNode?.sprite && S.headFlash[car.color] > 0) {
            const img = images[headNode.sprite.replace('/', '__') + '.png']
            const meta = spriteMeta[headNode.sprite.replace('/', '__') + '.png']
            if (img && meta) {
              drawList.push({
                order: 1000 + (headNode.order ?? 2) + 0.5, // поверх самой головы
                fn: () => {
                  const hpPos = car.head.getPosition()
                  const t = performance.now() / 1000
                  // плавное синусоидальное моргание ~1.7 Гц
                  const alpha = 0.65 * (0.5 - 0.5 * Math.cos(t * Math.PI * 2 * 1.7))
                  ctx.save()
                  ctx.globalAlpha = alpha
                  ctx.filter = 'brightness(0) invert(1)' // белая версия спрайта головы
                  drawSprite(img, meta, [hpPos.x, hpPos.y], car.head.getAngle(), headNode.scale || [1, 1], headNode.flipX)
                  ctx.restore()
                },
              })
            }
          }
        }
        drawCar(S.blue)
        drawCar(S.red)
        // Challenge: боты рисуются тем же путём, что и машины раунда
        for (const b of S.challenge?.bots ?? []) drawCar(b)
        // шар-маятник
        for (const bb of S.ballBodies) {
          const node = (bb as any)._spriteNode
          if (node?.sprite) {
            const img = images[node.sprite.replace('/', '__') + '.png']
            const meta = spriteMeta[node.sprite.replace('/', '__') + '.png']
            const p = bb.getPosition()
            const sc = node.scale || [1, 1]
            drawList.push({ order: 1000 + (node.order ?? 3), fn: () => drawSprite(img, meta, [p.x, p.y], bb.getAngle(), sc, false) })
          }
        }
        // Battle/Challenge: полоски HP над машинами — видны с самого начала раунда
        if ((S.mode === 'battle' || S.mode === 'challenge') && (S.blue || S.red)) {
          /* пиксельно скруглённый прямоугольник: 2 ступени по inset px на углах */
          const pxRoundRect = (x: number, y: number, w: number, h: number) => {
            const st = Math.max(1, Math.round(0.02 * s))
            for (let i = 0; i < 2; i++) {
              const ins = (2 - i) * st
              ctx.fillRect(x + ins, y + i * st, w - 2 * ins, st)
              ctx.fillRect(x + ins, y + h - (i + 1) * st, w - 2 * ins, st)
            }
            ctx.fillRect(x, y + 2 * st, w, h - 4 * st)
          }
          const drawHpBar = (car: Car | null, fill: string) => {
            if (!car) return
            const maxHp = carMaxHp(car.def.carType)
            const cur = Math.max(0, Math.min(maxHp, S.hp[car.color] || 0))
            const p = car.body.getPosition()
            const [cx, cy] = worldToScreen(p.x, p.y + 0.62)
            const w = 0.82 * s
            const h = 0.14 * s
            ctx.save()
            // рамка — тёмная, пиксельно скруглённая
            ctx.fillStyle = 'rgba(13,13,13,0.85)'
            pxRoundRect(cx - w / 2, cy - h / 2, w, h)
            // заливка HP — тоже пиксельно скруглённая, внутри рамки (иначе
            // прямоугольная заливка вылезает в срезанные углы рамки)
            const fw = Math.max(0, (w - 4) * (cur / maxHp))
            ctx.fillStyle = fill
            if (fw >= 12) pxRoundRect(cx - w / 2 + 2, cy - h / 2 + 2, fw, h - 4)
            else if (fw > 0) ctx.fillRect(cx - w / 2 + 2, cy - h / 2 + 2, fw, h - 4)
            // число HP — прямо внутри рамки, по центру
            ctx.font = `${Math.round(0.115 * s)}px "Barcade Brawl", monospace`
            ctx.textAlign = 'center'
            ctx.textBaseline = 'middle'
            ctx.lineWidth = 3
            ctx.strokeStyle = 'rgba(13,13,13,0.9)'
            ctx.strokeText(String(Math.round(cur)), cx, cy + 1)
            ctx.fillStyle = '#fff'
            ctx.fillText(String(Math.round(cur)), cx, cy + 1)
            ctx.restore()
          }
          drawList.push({ order: 1500, fn: () => drawHpBar(S.blue, '#4fa4ff') })
          if (S.mode === 'battle') drawList.push({ order: 1500, fn: () => drawHpBar(S.red, '#ff5a5a') })
        }
        // частицы попадания в голову — пиксельные белые кружки
        for (const pt of S.particles) {
          drawList.push({
            order: 2000,
            fn: () => {
              const [sx, sy] = worldToScreen(pt.x, pt.y)
              drawPixelCircle(sx, sy, pt.size * s, Math.max(0, Math.min(1, pt.life * 2.5)))
            },
          })
        }
        drawList.sort((a, b) => a.order - b.order)
        for (const d of drawList) d.fn()
      }

      /* ---- ввод ---- */
      const keys = keysRef.current
      const onKeyDown = (e: KeyboardEvent) => {
        if (['a', 'd', 'arrowleft', 'arrowright', 'r', '/', ' '].includes(e.key.toLowerCase()) || e.key === 'Slash') e.preventDefault()
        keys[e.key.toLowerCase()] = true
        keys[e.code] = true
        // BlueReset: R / RedReset: / / выход в меню: Space
        if (e.code === 'KeyR' && S.blue && S.mode !== 'battle' && S.mode !== 'challenge') safeReset(S.blue) // в Battle/Challenge reset недоступен (в Challenge это побег от роя)
        if (e.code === 'Slash' && S.red && S.mode !== 'battle') safeReset(S.red) // в Battle красная — бот, reset недоступен
        if (e.code === 'Space' && S.gameOver) backToMenu()
        if (e.code === 'Escape' && S.mode === 'cars') closeCars()
      }
      const onKeyUp = (e: KeyboardEvent) => {
        keys[e.key.toLowerCase()] = false
        keys[e.code] = false
      }
      window.addEventListener('keydown', onKeyDown)
      window.addEventListener('keyup', onKeyUp)

      /* Анти-застревание: застрявший/перевёрнутый исчезает с эффектом и появляется
         выше (той же анимацией); вылетевший за карту — ДАЛЬНО и не мгновенно —
         на свой спавн. Любое перемещение — только в свободное место: телепорт
         прямо в стену, пилу или другую машину запрещён (иначе машины застревают
         друг в друге, а солвер выталкивает их сквозь стены). */
      function spotFree(x: number, y: number, car: Car): boolean {
        if (!S.world) return true // мир ещё не собран — некого проверять
        // AABB вокруг места появления (корпус+голова+запас): пересечение с чужим
        // телом (арена, пила, вторая машина) делает место занятым
        const box = new pl.AABB(new pl.Vec2(x - 1.8, y - 0.7), new pl.Vec2(x + 1.8, y + 1.3))
        let free = true
        S.world.queryAABB(box, (f) => {
          const b = f.getBody()
          if (car.body === b || car.wheels.includes(b) || car.head === b) return true // своё тело — не помеха
          free = false
          return false
        })
        return free
      }
      type PlayGrid = {
        x0: number
        y0: number
        cs: number
        w: number
        h: number
        reach: Uint8Array
        wallB: Uint8Array
        ceilB: Uint8Array
        closed: boolean
        playableAt: (x: number, y: number) => boolean
        canReturn: (x: number, y: number) => boolean
        distToPlayable: (x: number, y: number) => number
        nearestPlayable: (x: number, y: number) => [number, number]
      }
      function inMap(x: number, y: number): boolean {
        // точка телепорта обязана быть в ИГРАБЕЛЬНОЙ зоне карты — клетке,
        // достижимой из спавнов (BFS по статике арены): это сильнее AABB-габаритов —
        // крыша закрытых карт, карманы между стенами и полости исключены, и от
        // любой разрешённой точки машина всегда может «доехать» обратно
        const g = (S as any)._playGrid as PlayGrid | null
        if (g) return g.playableAt(x, y)
        // фолбэк без сетки: грубые габариты арены
        const bx = (S.arena as any)._bx as [number, number] | undefined
        const by = (S.arena as any)._by as number | undefined
        const ty = (S.arena as any)._ty as number | undefined
        if (bx && (x < bx[0] + 1.2 || x > bx[1] - 1.2)) return false
        if (by !== undefined && y < by + 0.6) return false
        if (ty !== undefined && y > ty - 0.6) return false
        return true
      }
      function clampInMap(x: number, y: number): [number, number] {
        // крайний случай: ближайшая играбельная клетка (гарантированно достижима
        // из спавнов); без сетки — грубый кламп в габариты арены
        const g = (S as any)._playGrid as PlayGrid | null
        if (g) return g.nearestPlayable(x, y)
        const bx = (S.arena as any)._bx as [number, number] | undefined
        const ty = (S.arena as any)._ty as number | undefined
        return [bx ? Math.min(Math.max(x, bx[0] + 1.3), bx[1] - 1.3) : x, ty !== undefined ? Math.min(y, ty - 0.8) : y]
      }
      function findFreeSpot(car: Car, x0: number, y0: number, includeBase = false): [number, number] | null {
        // порядок: чуть выше исходной точки (сохраняет «появляется выше»), потом
        // выше и в стороны — низкие потолки закрытых карт обходятся боковыми
        // вариантами; каждая точка обязана быть внутри карты И свободной
        const cands: [number, number][] = []
        if (includeBase) cands.push([x0, y0])
        cands.push(
          [x0, y0 + 2.2],
          [x0, y0 + 3.4],
          [x0 + 2.6, y0 + 2.2],
          [x0 - 2.6, y0 + 2.2],
          [x0 + 2.6, y0 + 0.8],
          [x0 - 2.6, y0 + 0.8],
          [x0, y0 + 4.6],
          [x0 + 4.2, y0 + 2.2],
          [x0 - 4.2, y0 + 2.2],
          [x0, y0 + 6.0],
        )
        for (const c of cands) if (inMap(c[0], c[1]) && spotFree(c[0], c[1], car)) return c
        return null // внутри карты свободных точек не нашлось
      }
      function placeRest(car: Car, base: [number, number]) {
        // ставим сборку (корпус, колёса, голову) в базу: вертикально, без скоростей —
        // как reset(), но в произвольную точку
        const rest = (b: pl.Body, off: Vec | null) => {
          b.setLinearVelocity(new pl.Vec2(0, 0))
          b.setAngularVelocity(0)
          b.setAngle(0)
          if (off) b.setPosition(new pl.Vec2(base[0] + off[0], base[1] + off[1]))
          b.setAwake(true)
        }
        rest(car.body, [0, 0])
        for (const w of car.wheels) {
          const n = (w as any)._spriteNode as CarNode | undefined
          rest(w, n ? [n.pos[0], n.pos[1]] : null)
        }
        const hn = (car.head as any)?._spriteNode as CarNode | undefined
        if (car.head) rest(car.head, hn ? [hn.pos[0], hn.pos[1]] : null)
      }
      function unstickUp(car: Car) {
        const fx = (S as any).spawnFx as ((x: number, y: number) => void) | undefined
        const p = car.body.getPosition()
        if (fx) fx(p.x, p.y) // эффект исчезновения на месте
        // в первую очередь — выше места застревания; если внутри карты всё занято —
        // точки вокруг спавна; крайний случай — сам спавн (он всегда внутри карты)
        const spot = findFreeSpot(car, p.x, p.y) ?? findFreeSpot(car, car.startPos[0], car.startPos[1]) ?? clampInMap(car.startPos[0], car.startPos[1])
        placeRest(car, spot)
        if (fx) fx(spot[0], spot[1]) // эффект появления — та же анимация
      }
      function safeReset(car: Car) {
        // телепорт на спавн, но не внутрь занятого места: спавн свободен — точно
        // на спавн; занят (машина/стена) — точка поднимается/сдвигается, оставаясь
        // внутри карты
        const fx = (S as any).spawnFx as ((x: number, y: number) => void) | undefined
        const p = car.body.getPosition()
        if (fx) fx(p.x, p.y)
        const spot = findFreeSpot(car, car.startPos[0], car.startPos[1], true) ?? clampInMap(car.startPos[0], car.startPos[1])
        placeRest(car, spot)
        if (fx) fx(spot[0], spot[1])
      }
      function rescueCar(car: Car, key: CarType) {
        // принудительное возвращение в играбельную зону (спавн или ближайшая
        // достижимая точка) + РОВНО 400 урона в battle за выход за карту;
        // если после штрафа HP = 0 — финал раунда с очком сопернику
        safeReset(car)
        ;((S as any)._unstickT ||= {})[key] = 0
        if (S.mode === 'battle') {
          S.hp[key] = Math.max(0, S.hp[key] - 400)
          if (S.hp[key] <= 0) (S as any).endRound?.(key)
        }
      }
      /* есть ли у машины опора (несенсорный контакт корпуса или колёс): арена,
         другая машина. Голова не считается — баланс на голове это «в воздухе». */
      function carGrounded(car: Car): boolean {
        if (!S.world) return true
        for (let ce = S.world.getContactList(); ce; ce = ce.getNext()) {
          if (!ce.isTouching()) continue
          const fa = ce.getFixtureA()
          const fb = ce.getFixtureB()
          if (fa.isSensor() || fb.isSensor()) continue
          const ba = fa.getBody()
          const bb = fb.getBody()
          if (ba === car.body || bb === car.body || car.wheels.includes(ba) || car.wheels.includes(bb)) return true
        }
        return false
      }
      function unstickMonitor(car: Car | null, key: CarType, dt: number) {
        if (!car || car.locked) return
        const p = car.body.getPosition()
        const t = ((S as any)._unstickT ||= {})
        // вылет за карту: ДАЛЬНО за границами (не разовый прокол стены солвером)
        // и продержались снаружи 0.6 c подряд — только тогда телепорт на спавн
        const bx = (S.arena as any)._bx as [number, number] | undefined
        const by = (S.arena as any)._by as number | undefined
        const oob = p.y < (by !== undefined ? by - 3.0 : -4.5) || (bx && (p.x < bx[0] - 2.0 || p.x > bx[1] + 2.0))
        // В ВОЗДУХЕ застревать нельзя: сальто с трамплина и прыжок — не застревание.
        // Раньше таймеры копились и в полёте — игра телепортировала машину прямо
        // в воздухе («перевёрнут» в сальто → unstickUp; «потерян» над пропастью →
        // rescueCar на спавн), хотя она не была застряла.
        const airborne = !carGrounded(car)
        // «потерян» (максимальная защита, ТОЛЬКО с опорой): из текущего места
        // машина НЕ может вернуться в играбельную зону ездой (вбок) и падением
        // (вниз) — крыша закрытой карты, карман в стене, полость. Удержание 1.2 c
        // отсекает пролёты; машина на платформе не ложный — съехав, возвращается.
        const g = (S as any)._playGrid as PlayGrid | null
        const lost = !airborne && !!g && !g.canReturn(p.x, p.y)
        if (oob || lost) {
          t[key] = (t[key] ?? 0) + dt
          if (t[key] > (oob ? 0.6 : 1.2)) {
            rescueCar(car, key)
          }
          return
        }
        const na = Math.atan2(Math.sin(car.body.getAngle()), Math.cos(car.body.getAngle()))
        const flipped = !airborne && Math.abs(na) > 1.1 // на боку/крыше, с опорой
        const v = car.body.getLinearVelocity()
        // «застрял» = жмёт вперёд и НЕ движется ВООБЩЕ (модуль скорости): у медленного
        // подъёма в горку vx мал, а общий — нет, это не застревание
        const jammed = !flipped && car.moveInput !== 0 && Math.hypot(v.x, v.y) < 0.15
        if (flipped || jammed) {
          // копится при ЛЮБОМ движении в перевороте (раскачка не сбрасывает таймер,
          // иначе застрявший навсегда качается и никогда не спасётся)
          t[key] = (t[key] ?? 0) + dt
          if (t[key] > (flipped ? 2.5 : 1.5)) {
            unstickUp(car)
            t[key] = 0
          }
        } else if (!airborne && Math.abs(na) < 0.9) {
          t[key] = 0 // встал на колёса — сброс (зона 0.9–1.1 — гистерезис)
        }
      }

      /* финал челленджа: пережил таймер — победа; HP игрока до нуля — поражение.
         Панель результата + выход по SPACE/MENU (S.gameOver открывает backToMenu) */
      function challengeEnd(win: boolean) {
        if (S.roundOver) return
        S.roundOver = true
        S.gameOver = true
        if (S.challenge) S.challenge.over = true
        const p = S.blue?.head.getPosition()
        if (p && !win) {
          const fx = (S as any).spawnFx as ((x: number, y: number) => void) | undefined
          if (fx) fx(p.x, p.y) // эффект гибели игрока
        }
        S.blue?.lockMovement()
        if (S.challenge) for (const b of S.challenge.bots) b.lockMovement()
        // награда за выживание: +30 болтов (та же схема, что за победу в Battle)
        if (win) {
          const earned = 30
          setBoltsEarned(earned)
          setBolts((b) => {
            const nb = b + earned
            try {
              localStorage.setItem('bolts', String(nb))
            } catch {}
            return nb
          })
        }
        setChallengeResult(win ? 'win' : 'lose')
      }

      /* ---- главный цикл ---- */
      let last = performance.now()
      let acc = 0
      let raf = 0
      function frame(now: number) {
        raf = requestAnimationFrame(frame)
        const dtReal = Math.min(0.1, (now - last) / 1000)
        last = now
        // пауза: физика и таймеры стоят, сцена рисуется замороженной
        if (S.paused) {
          render()
          return
        }
        // ввод → moveInput (1DAxis); в меню и VS BOT часть машин под управлением ИИ
        if (S.mode === 'friend') {
          if (S.blue && !S.blue.locked) S.blue.moveInput = (keys['d'] ? 1 : 0) - (keys['a'] ? 1 : 0)
          if (S.red && !S.red.locked) S.red.moveInput = (keys['arrowright'] ? 1 : 0) - (keys['arrowleft'] ? 1 : 0)
        } else if (S.mode === 'bot' || S.mode === 'battle') {
          // Battle: всегда против бота — синяя под управлением игрока, красная — ИИ
          if (S.blue && !S.blue.locked) S.blue.moveInput = (keys['d'] ? 1 : 0) - (keys['a'] ? 1 : 0)
          botThink(S.red, S.blue, dtReal)
        } else if (S.mode === 'challenge') {
          if (S.blue && !S.blue.locked) S.blue.moveInput = (keys['d'] ? 1 : 0) - (keys['a'] ? 1 : 0)
          // боты челленджа охотятся за игроком (тот же ИИ, что в VS BOT)
          if (S.challenge && !S.challenge.over) for (const b of S.challenge.bots) botThink(b, S.blue, dtReal)
        } else if (S.mode === 'menu') {
          // главное меню: демо-бой ботов
          botThink(S.blue, S.red, dtReal)
          botThink(S.red, S.blue, dtReal)
          // второй бот спавнится через 3 c после первого
          const pr = (S as any).pendingRed
          if (!S.red && pr && S.world) {
            ;(S as any).menuRedTimer -= dtReal
            if ((S as any).menuRedTimer <= 0) {
              S.red = new Car(S.world, pr.def, pr.spawn, 'red')
              ;(S as any).liftToGround?.(S.red)
              ;(S as any).pendingRed = null
            }
          }
        }
        // slow-mo (Time.timeScale)
        if (S.roundEndStarted) {
          S.slowmoTimer -= dtReal
          if (S.slowmoTimer <= 0) {
            S.timeScale = 1
            S.roundEndStarted = false
            if (!S.gameOver) {
              S.roundOver = false
              buildRound()
            }
          }
        }
        // Battle: таймер неуязвимости/моргания головы тикает в реальном времени
        S.headFlash.blue = Math.max(0, S.headFlash.blue - dtReal)
        S.headFlash.red = Math.max(0, S.headFlash.red - dtReal)
        // Battle: удар о пилу → через 2 c телепорт на спавн (тоже в реальном
        // времени — slow-mo финала раунда не растягивает отсчёт)
        if (S.mode === 'battle' && !S.roundOver) {
          for (const key of ['blue', 'red'] as CarType[]) {
            if (!S.sawHit[key]) continue
            const car = key === 'blue' ? S.blue : S.red
            if (!car || car.locked) {
              S.sawHit[key] = false
              S.sawTimer[key] = 0
              continue
            }
            S.sawTimer[key] += dtReal
            if (S.sawTimer[key] >= 2) {
              S.sawHit[key] = false
              S.sawTimer[key] = 0
              safeReset(car) // на спавн; если спавн занят — свободная точка рядом
            }
          }
        }
        // анти-застревание/вылет за карту — тоже в реальном времени.
        // Боты челленджа НЕ телепортируются и НЕ респавнятся: для них анти-застревание
        // отключено (застрявший остаётся застрявшим, выпавший — уничтожается ниже)
        if (S.mode === 'bot' || S.mode === 'friend' || S.mode === 'battle' || S.mode === 'challenge') {
          unstickMonitor(S.blue, 'blue', dtReal)
          unstickMonitor(S.red, 'red', dtReal)
        }
        // CHALLENGE: таймер выживания (сверху справа, с сотыми) и спавн ботов
        if (S.mode === 'challenge' && S.challenge && !S.challenge.over) {
          const ch = S.challenge
          ch.timeLeft -= dtReal
          // таймер пишем напрямую в DOM: секунды крупно, сотые — мельче
          if (challengeTimerRef.current && challengeSecRef.current && challengeFracRef.current) {
            const t = Math.max(0, ch.timeLeft)
            const s = Math.floor(t)
            challengeSecRef.current.textContent = String(s)
            challengeFracRef.current.textContent = '.' + String(Math.floor((t - s) * 100)).padStart(2, '0')
            challengeTimerRef.current.style.color = s <= 10 ? '#ff5a5a' : '#fff'
          }
          if (ch.timeLeft <= 0) {
            challengeEnd(true) // продержался до конца таймера — победа
          } else {
            // выпавших за карту/в бездну ботов уничтожаем (без телепорта на спавн)
            const g = (S as any)._playGrid as PlayGrid | null
            if (g) {
              for (const b of ch.bots) {
                const p = b.body.getPosition()
                if ((p.y < g.y0 - 2 || p.x < g.x0 - 2 || p.x > g.x0 + g.w * g.cs + 2) && !ch.dead.includes(b)) ch.dead.push(b)
              }
            }
            ch.spawnT -= dtReal
            if (ch.spawnT <= 0) {
              ch.spawnT = CHALLENGE_INTERVAL // новый бот каждые 0.9 c
              ;(S as any).spawnChallengeBot?.()
            }
          }
        }
        acc += dtReal * S.timeScale
        let steps = 0
        while (acc >= FIXED_DT && steps < 8) {
          S.blue?.fixedUpdate(FIXED_DT)
          S.red?.fixedUpdate(FIXED_DT)
          for (const b of S.challenge?.bots ?? []) b.fixedUpdate(FIXED_DT)
          S.world?.step(FIXED_DT, VEL_ITER, POS_ITER)
          S.blue?.clampSpin()
          S.red?.clampSpin()
          for (const b of S.challenge?.bots ?? []) b.clampSpin()
          acc -= FIXED_DT
          steps++
        }
        // CHALLENGE: уничтожение битов из очереди смертей — ТОЛЬКО после шага
        // физики (в step-колбэках destroyBody запрещён). Один удар = один труп:
        // эффект ломания головы в точке головы + тела убираются из мира.
        if (S.mode === 'challenge' && S.challenge && S.challenge.dead.length) {
          const ch = S.challenge
          for (const b of ch.dead) {
            const idx = ch.bots.indexOf(b)
            if (idx === -1) continue
            ch.bots.splice(idx, 1)
            const hp = b.head.getPosition()
            const fx = (S as any).spawnFx as ((x: number, y: number) => void) | undefined
            if (fx) fx(hp.x, hp.y) // эффект ломания головы
            for (const bd of [b.body, ...b.wheels, b.head]) if (bd && S.world) S.world.destroyBody(bd)
          }
          ch.dead.length = 0
        }
        // частицы (в масштабе времени)
        for (const pt of S.particles) {
          pt.life -= dtReal * S.timeScale
          pt.x += pt.vx * dtReal * S.timeScale
          pt.y += pt.vy * dtReal * S.timeScale
          pt.vy -= 4 * dtReal * S.timeScale
        }
        S.particles = S.particles.filter((p) => p.life > 0)
        render()
      }

      /* ---- колбэки UI ---- */
      S.spawnCallbacks.onScore = (roundWinner: CarType) => {
        setScore({ blue: S.score.blue, red: S.score.red })
        // Battle: матч до 3 звёзд (звезда = жизнь проигравшего раунд); иначе до 5
        const winLimit = S.mode === 'battle' ? BATTLE_STARS : WIN_SCORE
        const isOver = S.score.blue >= winLimit || S.score.red >= winLimit
        if (isOver) {
          S.gameOver = true
          // GameManager.WhoWin(): победитель матча по очкам (не по раунду)
          const matchWinner: CarType = S.score.blue >= winLimit ? 'blue' : 'red'
          setWinner(matchWinner)
          if (S.mode === 'battle') {
            // награда болтами только за победу ИГРОКА (синие) по раундам:
            // 3-0 → 35, 3-1 → 20, 3-2 → 5; победа бота болтов не даёт
            const loserSide: CarType = matchWinner === 'blue' ? 'red' : 'blue'
            const earned = matchWinner === 'blue' ? battleBolts(S.score[loserSide]) : 0
            setBoltsEarned(earned > 0 ? earned : null)
            setBolts((b) => {
              const nb = b + earned
              try {
                localStorage.setItem('bolts', String(nb))
              } catch {}
              return nb
            })
          }
        } else {
          const stars = S.score[roundWinner]
          // спин летит к ПОБЕДИТЕЛЮ, на слот, который только что заполнился
          setSpinStar({ color: roundWinner, index: stars - 1 })
          setScoresLabel(roundWinner)
          setTimeout(() => setScoresLabel(null), 2600)
        }
      }
      S.spawnCallbacks.onScoreReset = () => {
        setScore({ blue: 0, red: 0 })
        setWinner(null)
        setSpinStar(null)
        setScoresLabel(null)
        setBoltsEarned(null)
        setChallengeResult(null)
      }

      /* ИИ бота v2: тактика вместо тарана. Отступает от рывков врага (приманивает),
         накапливает удар с разгона, наказывает опрокинутого/застрявшего, объезжает
         пилы, раскачивается при перевороте и не отступает за край арены. */
      function botThink(me: Car | null, foe: Car | null, dt: number) {
        if (!me || !foe || me.locked) {
          if (me && me.locked) me.moveInput = 0
          return
        }
        const anyMe = me as any
        const ai = (anyMe._ai = anyMe._ai || { state: 'attack', wig: 0, dir: 1 })
        ai.wig -= dt

        const mp = me.body.getPosition()
        const fp = foe.body.getPosition()
        const fv = foe.body.getLinearVelocity()
        const dx = fp.x - mp.x
        const sgn = dx > 0 ? 1 : -1
        const dist = Math.hypot(dx, fp.y - mp.y)
        const vTowardMe = -fv.x * sgn // >0 — враг несётся в мою сторону
        const na = Math.atan2(Math.sin(me.body.getAngle()), Math.cos(me.body.getAngle()))
        const nfa = Math.atan2(Math.sin(foe.body.getAngle()), Math.cos(foe.body.getAngle()))
        const meDown = Math.abs(na) > 1.1 // я на боку/на крыше
        const foeDown = Math.abs(nfa) > 1.1 // враг опрокинут — момент бить
        const foeSlow = Math.abs(fv.x) < 0.25

        /* 0) в воздухе: бот доворачивается колёсами вверх — тем же управлением
           корпусом, что у игрока (moveInput → крутящий момент), поэтому это не чит.
           Но реакция живая, не идеальная: запаздывание 0.3 c, только при заметном
           наклоне (>40°), и направление держится минимум 0.25 c даже если промах —
           как человек, перелетевший через голову; быстрое сальто спасти успевает
           не всегда. На земле ветка отключена. */
        if (!carGrounded(me)) {
          ai.airT = (ai.airT ?? 0) + dt
          if (ai.fixDir) {
            ai.fixT = (ai.fixT ?? 0) + dt
            if (ai.fixT < 0.25) {
              me.moveInput = ai.fixDir
              return
            }
            ai.fixDir = 0 // обязательство кончилось — смотрим на наклон заново
          }
          if (ai.airT > 0.3 && Math.abs(na) > 0.7) {
            ai.fixDir = na > 0 ? -1 : 1
            ai.fixT = 0
            me.moveInput = ai.fixDir
            return
          }
        } else {
          ai.airT = 0
          ai.fixDir = 0
        }

        const bx = (S.arena as any)._bx as [number, number] | undefined
        // есть ли пила на расстоянии r в направлении dir (в моей полосе по высоте)
        const sawAt = (fromX: number, dir: number, r: number) =>
          S.ballBodies.some((s) => {
            const sp = s.getPosition()
            return Math.abs(sp.y - mp.y) < 1.15 && (sp.x - fromX) * dir > 0 && Math.abs(sp.x - fromX) < r
          })

        /* 1) на боку/крыше: раскачка влево-вправо; если 2.5 c не встанет —
           общая анти-застревание в frame() поднимет с эффектом (не на спавн) */
        if (meDown) {
          if (ai.wig <= 0) {
            ai.wig = 0.35
            ai.dir = -ai.dir
          }
          me.moveInput = ai.dir
          return
        }

        /* 2) пила совсем рядом — отползаем от лезвия */
        if (sawAt(mp.x, 1, 0.95) || sawAt(mp.x, -1, 0.95)) {
          const away = sawAt(mp.x, 1, 0.95) ? -1 : 1
          me.moveInput = away
          return
        }

        /* 3) враг опрокинут или обездвижен вблизи — идём добивать */
        if ((foeDown || foeSlow) && dist < 2.6) {
          me.moveInput = sgn
          return
        }

        /* 4) враг несётся на меня на скорости — отступаем-приманиваем,
           но не в пилу и не за край арены (там встречаем контратакой) */
        if (dist < 2.6 && vTowardMe > 1.6) {
          const away = -sgn
          const trapped =
            (bx && ((away < 0 && mp.x < bx[0] + 1.0) || (away > 0 && mp.x > bx[1] - 1.0))) ||
            sawAt(mp.x, away, 1.3)
          me.moveInput = trapped ? sgn : away
          return
        }

        /* 5) пила между мной и близким врагом — не лезем под лезвие, ждём */
        if (dist < 3.5) {
          for (const saw of S.ballBodies) {
            const sp = saw.getPosition()
            if (Math.abs(sp.y - mp.y) < 1.15 && (sp.x - mp.x) * (fp.x - sp.x) > 0 && Math.abs(sp.x - mp.x) < 2.2) {
              me.moveInput = 0
              return
            }
          }
        }

        /* 6) обычное сближение: разгоняемся для удара (застрял — общая
           анти-застревание в frame() поднимет с эффектом) */
        me.moveInput = Math.abs(dx) < 0.12 ? 0 : sgn
      }

      /* выбор режима из меню: VS BOT (синяя) / VS FRIEND (оранжевая) / BATTLE (фиолетовая) /
         CHALLENGE (бирюзовая) — случайный челлендж без звёзд, на выживание */
      function startGame(m: 'bot' | 'friend' | 'battle' | 'challenge') {
        S.mode = m
        S.score.blue = 0
        S.score.red = 0
        S.gameOver = false
        S.roundOver = false
        S.roundEndStarted = false
        S.slowmoTimer = 0
        S.timeScale = 1
        ;(S as any).pendingRed = null
        S.spawnCallbacks.onScoreReset?.()
        S.spawnCallbacks.onMode?.(m)
        buildRound()
      }
      S.spawnCallbacks.startGame = startGame

      /* выход в главное меню: панель уходит, затем демо-бой ботов */
      let menuPending = false
      function backToMenu() {
        if (!S.gameOver || menuPending) return
        menuPending = true
        setWinClosing(true)
        window.setTimeout(() => {
          if (disposed) return
          S.mode = 'menu'
          S.score.blue = 0
          S.score.red = 0
          S.gameOver = false
          S.roundOver = false
          S.roundEndStarted = false
          S.slowmoTimer = 0
          S.timeScale = 1
          ;(S as any).pendingRed = null
          S.spawnCallbacks.onScoreReset()
          S.spawnCallbacks.onMode?.('menu')
          buildRound()
          setWinClosing(false)
          menuPending = false
        }, 300)
      }
      S.spawnCallbacks.backToMenu = backToMenu

      /* ---- витрина машин (меню CARS): жук в невидимой коробке ---- */
      function openCars() {
        if (S.mode !== 'menu') return
        S.mode = 'cars'
        setCarsOpen(true)
        buildRound()
      }
      function closeCars() {
        if (S.mode !== 'cars') return
        S.mode = 'menu'
        setCarsOpen(false)
        buildRound() // обратно в демо-бой главного меню
      }
      S.spawnCallbacks.openCars = openCars
      S.spawnCallbacks.closeCars = closeCars
      /* стрелки ‹ › в витрине: предыдущая/следующая синяя модель */
      function cycleCar(dir: number) {
        if (S.mode !== 'cars') return
        const list = Object.keys((S as any).data.cars).filter((n: string) => n.startsWith('Blue'))
        const cur = (S as any).carsIndex ?? list.indexOf('BlueWeevil')
        ;(S as any).carsIndex = (cur + dir + list.length) % list.length
        buildRound() // пересобираем мир: новая машина падает в ту же коробку
      }
      S.spawnCallbacks.cycleCar = cycleCar

      /* ---- пауза в матче (кнопка сверху по центру) ---- */
      function pauseGame() {
        if (S.mode === 'menu' || S.gameOver || S.paused) return
        S.paused = true
        setPaused(true)
      }
      function resumeGame() {
        if (!S.paused) return
        S.paused = false
        setPaused(false)
      }
      /* перезапуск матча из паузы: очки в ноль, новый раунд */
      function restartMatch() {
        S.paused = false
        S.score.blue = 0
        S.score.red = 0
        S.gameOver = false
        S.roundOver = false
        S.roundEndStarted = false
        S.slowmoTimer = 0
        S.timeScale = 1
        ;(S as any).pendingRed = null
        S.spawnCallbacks.onScoreReset?.()
        buildRound()
        setPaused(false)
      }
      /* выход в главное меню из паузы */
      function exitToMenu() {
        S.paused = false
        S.mode = 'menu'
        S.score.blue = 0
        S.score.red = 0
        S.gameOver = false
        S.roundOver = false
        S.roundEndStarted = false
        S.slowmoTimer = 0
        S.timeScale = 1
        ;(S as any).pendingRed = null
        S.spawnCallbacks.onScoreReset?.()
        S.spawnCallbacks.onMode?.('menu')
        buildRound()
        setPaused(false)
      }
      S.spawnCallbacks.pauseGame = pauseGame
      S.spawnCallbacks.resumeGame = resumeGame
      S.spawnCallbacks.restartMatch = restartMatch
      S.spawnCallbacks.exitToMenu = exitToMenu

      buildRound()
      raf = requestAnimationFrame(frame)

      /* ---- ресайз ---- */
      const resize = () => {
        const dpr = Math.min(2, window.devicePixelRatio || 1)
        canvas.width = Math.floor(canvas.clientWidth * dpr)
        canvas.height = Math.floor(canvas.clientHeight * dpr)
      }
      resize()
      window.addEventListener('resize', resize)

      /* ---- тач-кнопки ---- */
      /* тач-кнопки теперь держат обработчики сами (HoldBtn, pointer-события):
         getElementById-подход навешивал слушатели до появления кнопок в DOM */

      return () => {
        disposed = true
        cancelAnimationFrame(raf)
        window.removeEventListener('keydown', onKeyDown)
        window.removeEventListener('keyup', onKeyUp)
        window.removeEventListener('resize', resize)
      }
    }

    const cleanup = boot()
    return () => {
      cleanup.then?.((fn: any) => fn?.())
      disposed = true
    }
  }, [])

  const starImgs = (color: 'blue' | 'red') => {
    // звёзды копятся победами: старт — все серые, каждый выигранный раунд
    // закрашивает одну звезду победителя (Battle: 3 слота, обычные: до 5)
    const slots = mode === 'battle' ? BATTLE_STARS : 5
    const sc = color === 'blue' ? score.blue : score.red
    return Array.from({ length: slots }, (_, i) => ({
      filled: i < sc,
      img: color === 'blue' ? BLUE_STAR_IMG : RED_STAR_IMG,
    }))
  }

  return (
    <div className="relative h-screen w-screen overflow-hidden" style={{ background: BG_COLOR }}>
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" style={{ imageRendering: 'pixelated' }} />

      {/* Звёзды счёта (StarsViewer: BlueStars top-left, RedStars top-right, canvas 1920×1080) */}
      <div className="pointer-events-none absolute inset-0 select-none" style={{ fontFamily: "'Barcade Brawl', monospace" }}>
        {mode !== 'menu' && mode !== 'challenge' && (
          <div className="absolute flex" style={{ top: '1.85%', left: '1.04%', width: '26.04%', height: '9.26%' }}>
            {starImgs('blue').map((s, i) => (
              <div key={i} className="relative flex-1">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={s.filled ? s.img : EMPTY_STAR_IMG} className="h-full w-full object-contain" style={{ imageRendering: 'pixelated' }} alt="" />
              </div>
            ))}
          </div>
        )}
        {mode !== 'menu' && mode !== 'challenge' && (
          <div className="absolute flex flex-row-reverse" style={{ top: '1.85%', right: '1.04%', width: '26.04%', height: '9.26%' }}>
            {starImgs('red').map((s, i) => (
              <div key={i} className="relative flex-1">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={s.filled ? s.img : EMPTY_STAR_IMG} className="h-full w-full object-contain" style={{ imageRendering: 'pixelated' }} alt="" />
              </div>
            ))}
          </div>
        )}

        {/* эффект вращения вокруг новой звезды (StarsViewer.SpinCoroutine) */}
        {spinStar && (
          <div
            className="pointer-events-none absolute"
            style={{
              top: spinStar.color === 'blue' ? '1.85%' : '1.85%',
              left: spinStar.color === 'blue' ? '1.04%' : undefined,
              right: spinStar.color === 'blue' ? undefined : '1.04%',
              width: '26.04%',
              height: '9.26%',
            }}
          >
            <div
              className="absolute"
              style={{
              left: spinStar.color === 'blue' ? `${(spinStar.index + 0.5) * (mode === 'battle' ? 100 / 3 : 20)}%` : undefined,
              right: spinStar.color === 'blue' ? undefined : `${(spinStar.index + 0.5) * (mode === 'battle' ? 100 / 3 : 20)}%`,
                top: '50%',
                width: '40.6%', // 780/1920
                height: '71.5%', // 772/1080
                transform: 'translate(-50%, -50%)',
                animation: 'spin-cw 1s linear infinite',
              }}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={spinStar.color === 'blue' ? BLUE_SPIN_IMG : RED_SPIN_IMG} className="h-full w-full object-cover" style={{ imageRendering: 'pixelated' }} alt="" />
            </div>
          </div>
        )}

        {/* "BLUE SCORES" / "RED SCORES" (winText в StarsViewer) */}
        {scoresLabel && (
          <div
            className="absolute left-1/2 -translate-x-1/2 text-center leading-tight"
            style={{ top: '11.8%', fontSize: '5.9vh', color: scoresLabel === 'blue' ? BLUE_COLOR : RED_COLOR, textShadow: '0 3px 0 rgba(0,0,0,.35)' }}
          >
            <div style={{ animation: 'score-pop 2.6s step-end both' }}>
              {scoresLabel === 'blue' ? 'BLUE' : 'RED'}
              <br />
              SCORES
            </div>
          </div>
        )}

        {/* Панель победы (UIManager: blueWinPanel/redWinPanel) / итог челленджа */}
        {(winner || challengeResult) && (
          <div
            className="absolute inset-0 flex flex-col items-center justify-center"
            style={{
              background: 'rgba(0,0,0,0.616)',
              animation: winClosing ? 'panel-out 0.3s ease both' : 'panel-in 0.45s ease-out both',
            }}
          >
            <div style={{ animation: 'wins-pop 0.5s step-end both' }}>
              {challengeResult ? (
                <div className="text-center leading-none" style={{ fontSize: '8.6vh', color: challengeResult === 'win' ? '#ffd83d' : '#ff5a5a' }}>
                  {challengeResult === 'win' ? 'YOU SURVIVED!' : 'YOU DIED'}
                </div>
              ) : (
                <div className="text-center leading-none" style={{ fontSize: '11.85vh', color: winner === 'blue' ? BLUE_COLOR : RED_COLOR }}>
                  {winner === 'blue' ? 'BLUE' : 'RED'}
                  <br />
                  WINS
                </div>
              )}
            </div>
            <div className="mt-8 text-center" style={{ fontSize: '5.9vh', color: '#fff', animation: 'late-in 0.4s ease 0.45s both' }}>
              Press SPACE for menu
            </div>
            {/* Battle: заработанные болты за матч */}
            {boltsEarned !== null && (
              <div
                className="flex items-center"
                style={{ gap: '1.6vh', marginTop: '1vh', animation: 'late-in 0.4s ease 0.55s both', fontFamily: "'Barcade Brawl', monospace" }}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src="/Bolt.png" style={{ height: '5.2vh', width: '5.2vh', objectFit: 'contain' }} alt="" />
                <span style={{ fontSize: '5vh', color: '#ffb838', lineHeight: 1 }}>+{boltsEarned}</span>
              </div>
            )}
            <button
              id="btn-menu"
              onClick={() => stateRef.current?.spawnCallbacks?.backToMenu?.()}
              className="pointer-events-auto mt-6 rounded-lg border border-white/40 px-6 py-3 text-lg text-white/90"
              style={{ fontSize: '3.2vh', animation: 'late-in 0.4s ease 0.6s both' }}
            >
              MENU
            </button>
          </div>
        )}

        {/* Кнопка паузы сверху по центру (только в матче) */}
        {mode !== 'menu' && !winner && !challengeResult && (
          <button
            id="btn-pause"
            onClick={() => stateRef.current?.spawnCallbacks?.pauseGame?.()}
            className="pointer-events-auto absolute"
            style={{ top: '1.5%', left: '50%', transform: 'translateX(-50%)', width: '6.2vh', height: '6.2vh', cursor: 'pointer' }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/pause.png" className="h-full w-full object-contain" style={{ imageRendering: 'pixelated' }} alt="PAUSE" />
          </button>
        )}

        {/* Challenge: таймер выживания сверху справа — секунды крупно, сотые мельче */}
        {mode === 'challenge' && !challengeResult && (
          <div
            ref={challengeTimerRef}
            className="absolute select-none text-right"
            style={{ top: '1.2vh', right: '2.2vh', fontSize: '7.2vh', color: '#fff', lineHeight: 1, textShadow: '0 3px 0 rgba(0,0,0,.55)' }}
          >
            <span ref={challengeSecRef}>{CHALLENGE_DURATION}</span>
            <span ref={challengeFracRef} style={{ fontSize: '0.45em' }}>
              .00
            </span>
          </div>
        )}

        {/* Подсказка управления (в Battle красная — бот, reset-клавиши недоступны) */}
        {!winner && mode !== 'menu' && (
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 whitespace-nowrap text-center text-white/60" style={{ fontSize: '2.4vh' }}>
            {mode === 'battle'
              ? 'BLUE: A/D\u00A0\u00A0•\u00A0\u00A0WIN: STARS & BOLTS'
              : mode === 'challenge'
                ? 'SURVIVE UNTIL THE TIMER RUNS OUT'
                : 'BLUE: A/D + R\u00A0\u00A0•\u00A0\u00A0RED: ←/→ + /\u00A0\u00A0•\u00A0\u00A0MOBILE: BUTTONS BELOW'}
          </div>
        )}

        {/* Тач-кнопки: против бота (VS BOT / BATTLE / CHALLENGE) — только синие:
            ВЛЕВО в левом углу, ВПРАВО у правого края; красные — только VS FRIEND */}
        {mode !== 'menu' && (
          <div className="pointer-events-none absolute bottom-0 left-0 right-0 flex select-none items-end justify-between p-2">
            {mode === 'bot' || mode === 'battle' || mode === 'challenge' ? (
              <>
                <HoldBtn color="blue" arrow="left" onDown={() => { keysRef.current['a'] = true }} onUp={() => { keysRef.current['a'] = false }} />
                <HoldBtn color="blue" arrow="right" onDown={() => { keysRef.current['d'] = true }} onUp={() => { keysRef.current['d'] = false }} />
              </>
            ) : (
              <>
                <div className="flex items-end" style={{ gap: '10px' }}>
                  <HoldBtn color="blue" arrow="left" onDown={() => { keysRef.current['a'] = true }} onUp={() => { keysRef.current['a'] = false }} />
                  <HoldBtn color="blue" arrow="right" onDown={() => { keysRef.current['d'] = true }} onUp={() => { keysRef.current['d'] = false }} />
                </div>
                <div className="flex items-end" style={{ gap: '10px' }}>
                  <HoldBtn color="red" arrow="left" onDown={() => { keysRef.current['arrowleft'] = true }} onUp={() => { keysRef.current['arrowleft'] = false }} />
                  <HoldBtn color="red" arrow="right" onDown={() => { keysRef.current['arrowright'] = true }} onUp={() => { keysRef.current['arrowright'] = false }} />
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* Валюта «болты»: сверху справа во всех меню (в битве и её оверлеях скрыта), без подложки */}
      {mode === 'menu' && (
        <div className="pointer-events-none absolute flex select-none items-center" style={{ right: '2vh', top: '2vh', gap: '1.3vh' }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/Bolt.png" style={{ height: '4.4vh', width: '4.4vh', objectFit: 'contain' }} alt="" />
          <span
            style={{ fontSize: '3.4vh', color: '#fff', lineHeight: 1, fontFamily: "'Barcade Brawl', monospace", textShadow: '0 3px 0 rgba(0,0,0,.55)' }}
          >
            {bolts}
          </span>
        </div>
      )}

      {/* Главное меню: компактные горизонтальные кнопки (иконка слева, текст справа),
          синяя влетает снизу, оранжевая — сверху (как на референсе) */}
      {mode === 'menu' && !carsOpen && (
        <div className="absolute inset-0 z-20 flex select-none flex-wrap items-center justify-center" style={{ gap: '1.2vh', fontFamily: "'Barcade Brawl', monospace" }}>
          <div
            className="px-round"
            style={{ background: '#0d0d0d', padding: '0.9vh', cursor: 'pointer', animation: 'menu-from-bottom 0.55s cubic-bezier(0.2, 0.9, 0.3, 1) both' }}
          >
            <button
              onClick={() => stateRef.current?.spawnCallbacks?.startGame?.('bot')}
              className="px-round px-round-inner pointer-events-auto flex cursor-pointer flex-row items-center"
              style={{ backgroundColor: '#3e72c5', backgroundImage: MENU_SHADE, backgroundSize: '4px 4px, auto, auto, auto', backgroundRepeat: 'repeat, no-repeat, no-repeat, no-repeat', padding: '1.8vh 2.8vh', gap: '2vh' }}
            >
              <PixelIcon map={ROBOT_ICON} height="6vh" />
              <div className="text-left" style={{ fontSize: '3vh', color: '#fff', lineHeight: 1.1 }}>
                PLAY
                <br />
                VS BOT
              </div>
            </button>
          </div>
          <div
            className="px-round"
            style={{ background: '#0d0d0d', padding: '0.9vh', cursor: 'pointer', animation: 'menu-from-top 0.55s cubic-bezier(0.2, 0.9, 0.3, 1) both' }}
          >
            <button
              onClick={() => stateRef.current?.spawnCallbacks?.startGame?.('friend')}
              className="px-round px-round-inner pointer-events-auto flex cursor-pointer flex-row items-center"
              style={{ backgroundColor: '#c2570d', backgroundImage: MENU_SHADE, backgroundSize: '4px 4px, auto, auto, auto', backgroundRepeat: 'repeat, no-repeat, no-repeat, no-repeat', padding: '1.8vh 2.8vh', gap: '2vh' }}
            >
              <PixelIcon map={HUMAN_ICON} height="6vh" />
              <div className="text-left" style={{ fontSize: '3vh', color: '#fff', lineHeight: 1.1 }}>
                PLAY
                <br />
                VS FRIEND
              </div>
            </button>
          </div>
          <div
            className="px-round"
            style={{ background: '#0d0d0d', padding: '0.9vh', cursor: 'pointer', animation: 'menu-from-top 0.55s cubic-bezier(0.2, 0.9, 0.3, 1) 0.08s both' }}
          >
            <button
              onClick={() => stateRef.current?.spawnCallbacks?.openCars?.()}
              className="px-round px-round-inner pointer-events-auto flex cursor-pointer flex-row items-center"
              style={{ backgroundColor: '#2e7d32', backgroundImage: MENU_SHADE, backgroundSize: '4px 4px, auto, auto, auto', backgroundRepeat: 'repeat, no-repeat, no-repeat, no-repeat', padding: '1.8vh 2.8vh', gap: '2vh' }}
            >
              <PixelIcon map={CARS_ICON} height="6vh" />
              <div className="text-left" style={{ fontSize: '3vh', color: '#fff', lineHeight: 1.1 }}>
                CARS
                <br />
                GARAGE
              </div>
            </button>
          </div>
          {/* BATTLE: 3 звезды-жизни у каждого, HP по редкости, победа — болты */}
          <div
            className="px-round"
            style={{ background: '#0d0d0d', padding: '0.9vh', cursor: 'pointer', animation: 'menu-from-bottom 0.55s cubic-bezier(0.2, 0.9, 0.3, 1) 0.16s both' }}
          >
            <button
              onClick={() => stateRef.current?.spawnCallbacks?.startGame?.('battle')}
              className="px-round px-round-inner pointer-events-auto flex cursor-pointer flex-row items-center"
              style={{ backgroundColor: '#8e44ad', backgroundImage: MENU_SHADE, backgroundSize: '4px 4px, auto, auto, auto', backgroundRepeat: 'repeat, no-repeat, no-repeat, no-repeat', padding: '1.8vh 2.8vh', gap: '2vh' }}
            >
              <PixelIcon map={BATTLE_ICON} height="6vh" />
              <div className="text-left" style={{ fontSize: '3vh', color: '#fff', lineHeight: 1.1 }}>
                PLAY
                <br />
                VS BATTLE
              </div>
            </button>
          </div>
          {/* CHALLENGE: случайный челлендж (пока один — выживание 40 c против роя ботов) */}
          <div
            className="px-round"
            style={{ background: '#0d0d0d', padding: '0.9vh', cursor: 'pointer', animation: 'menu-from-top 0.55s cubic-bezier(0.2, 0.9, 0.3, 1) 0.24s both' }}
          >
            <button
              onClick={() => stateRef.current?.spawnCallbacks?.startGame?.('challenge')}
              className="px-round px-round-inner pointer-events-auto flex cursor-pointer flex-row items-center"
              style={{ backgroundColor: '#0f7f8b', backgroundImage: MENU_SHADE, backgroundSize: '4px 4px, auto, auto, auto', backgroundRepeat: 'repeat, no-repeat, no-repeat, no-repeat', padding: '1.8vh 2.8vh', gap: '2vh' }}
            >
              <PixelIcon map={TROPHY_ICON} height="6vh" />
              <div className="text-left" style={{ fontSize: '3vh', color: '#fff', lineHeight: 1.1 }}>
                PLAY
                <br />
                CHALLENGE
              </div>
            </button>
          </div>
        </div>
      )}

      {/* витрина машин: фон битвы и белый вращающийся эффект ЗА машиной рисует канвас,
          оверлей — только заголовок и выход назад */}
      {carsOpen && (
        <div className="pointer-events-none absolute inset-0 z-20 select-none" style={{ fontFamily: "'Barcade Brawl', monospace" }}>
          <button
            onClick={() => stateRef.current?.spawnCallbacks?.closeCars?.()}
            className="px-round pointer-events-auto cursor-pointer"
            style={{ position: 'absolute', left: '2vh', top: '2vh', fontSize: '3vh', color: '#fff', background: '#0d0d0d', padding: '1.4vh 2.4vh' }}
          >
            &lt; BACK
          </button>
          <div style={{ position: 'absolute', top: '2vh', left: 0, right: 0, textAlign: 'center', fontSize: '4.6vh', color: '#fff', lineHeight: 1 }}>
            CARS
          </div>
          {/* бейдж над машиной: имя машины (белым) и под ним редкость в цвете тира
              (Common серый / Rare синий / Epic фиолетовый / Legendary золотой) */}
          {carsModel && (
            <div
              className="px-round"
              style={{
                position: 'absolute',
                left: '50%',
                top: '14%',
                transform: 'translateX(-50%)',
                background: '#0d0d0d',
                padding: '1.2vh 2.8vh 1.4vh',
                textAlign: 'center',
                whiteSpace: 'nowrap',
              }}
            >
              <div style={{ fontSize: '3vh', color: '#fff', lineHeight: 1.15 }}>{carDisplayName(carsModel)}</div>
              <div style={{ fontSize: '2.4vh', color: RARITY_COLOR[CAR_RARITY[carsModel] ?? 'Common'], lineHeight: 1.15 }}>
                {(CAR_RARITY[carsModel] ?? 'Common').toUpperCase()}
              </div>
            </div>
          )}
          {/* пиксельные стрелки переключения машин: слева и справа, вертикально по центру */}
          <button
            onClick={() => stateRef.current?.spawnCallbacks?.cycleCar?.(-1)}
            aria-label="previous car"
            className="pointer-events-auto cursor-pointer border-0 bg-transparent"
            style={{ position: 'absolute', left: '2vh', top: '50%', transform: 'translateY(-50%)', padding: 0 }}
          >
            <PixelIcon map={ARROW_L_ICON} height="13vh" />
          </button>
          <button
            onClick={() => stateRef.current?.spawnCallbacks?.cycleCar?.(1)}
            aria-label="next car"
            className="pointer-events-auto cursor-pointer border-0 bg-transparent"
            style={{ position: 'absolute', right: '2vh', top: '50%', transform: 'translateY(-50%)', padding: 0 }}
          >
            <PixelIcon map={ARROW_R_ICON} height="13vh" />
          </button>
        </div>
      )}

      {/* Пауза: затемнение + Exit / Resume / Restart (Exit и Restart выезжают слева, Resume — справа) */}
      {paused && (
        <div
          className="absolute inset-0 z-30 flex select-none flex-col items-center justify-center"
          style={{ background: 'rgba(0,0,0,0.75)', fontFamily: "'Barcade Brawl', monospace", gap: '5vh' }}
        >
          <button
            onClick={() => stateRef.current?.spawnCallbacks?.exitToMenu?.()}
            className="pause-item pointer-events-auto cursor-pointer"
            style={{ fontSize: '7vh', color: '#fff', lineHeight: 1, animation: 'pause-from-left 0.45s ease-out both' }}
          >
            EXIT
          </button>
          <button
            onClick={() => stateRef.current?.spawnCallbacks?.resumeGame?.()}
            className="pause-item pointer-events-auto cursor-pointer"
            style={{ fontSize: '7vh', color: '#fff', lineHeight: 1, animation: 'pause-from-right 0.45s ease-out 0.12s both' }}
          >
            RESUME
          </button>
          {/* RESTART в Battle скрыт: матч против бота нельзя перезапустить */}
          {mode !== 'battle' && (
            <button
              onClick={() => stateRef.current?.spawnCallbacks?.restartMatch?.()}
              className="pause-item pointer-events-auto cursor-pointer"
              style={{ fontSize: '7vh', color: '#fff', lineHeight: 1, animation: 'pause-from-left 0.45s ease-out 0.24s both' }}
            >
              RESTART
            </button>
          )}
        </div>
      )}

      <style jsx global>{`
        @font-face {
          font-family: 'Barcade Brawl';
          src: url('/fonts/barcade.ttf') format('truetype');
          font-display: swap;
        }
        @keyframes spin-cw {
          from {
            transform: translate(-50%, -50%) rotate(0deg);
          }
          to {
            transform: translate(-50%, -50%) rotate(360deg);
          }
        }
        /* "SCORES": ступенчатое появление + аркадное мигание перед исчезанием (2.6 с) */
        @keyframes score-pop {
          0% { opacity: 0; transform: scale(0.4); }
          5% { opacity: 1; transform: scale(0.6); }
          9% { opacity: 1; transform: scale(0.8); }
          13% { opacity: 1; transform: scale(1); }
          86% { opacity: 1; transform: scale(1); }
          88% { opacity: 0; transform: scale(1.05); }
          90% { opacity: 1; transform: scale(1.05); }
          92% { opacity: 0; transform: scale(1.12); }
          94% { opacity: 1; transform: scale(1.12); }
          96%, 100% { opacity: 0; transform: scale(1.12); }
        }
        /* панель победы: затемнение фона при появлении и при закрытии */
        @keyframes panel-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes panel-out {
          from { opacity: 1; }
          to { opacity: 0; }
        }
        /* "WINS": ступенчатое увеличение (пиксель-стиль) */
        @keyframes wins-pop {
          0% { opacity: 0; transform: scale(0.4); }
          30% { opacity: 1; transform: scale(0.7); }
          60% { opacity: 1; transform: scale(0.9); }
          100% { opacity: 1; transform: scale(1); }
        }
        @keyframes late-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        /* главное меню: синяя панель прилетает снизу, оранжевая — сверху */
        @keyframes menu-from-bottom {
          from { transform: translateY(135vh); }
          to { transform: translateY(0); }
        }
        @keyframes menu-from-top {
          from { transform: translateY(-135vh); }
          to { transform: translateY(0); }
        }
        @keyframes pause-from-left {
          from { transform: translateX(-100vw); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        @keyframes pause-from-right {
          from { transform: translateX(100vw); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        .pause-item:hover {
          text-decoration: underline;
        }
        /* пиксельные (ступенчатые, без сглаживания) скругления углов */
        .px-round {
          --pxr: 2.7vh;
          clip-path: polygon(
            0 var(--pxr), calc(var(--pxr) / 2) var(--pxr), calc(var(--pxr) / 2) calc(var(--pxr) / 2), var(--pxr) calc(var(--pxr) / 2), var(--pxr) 0,
            calc(100% - var(--pxr)) 0, calc(100% - var(--pxr)) calc(var(--pxr) / 2), calc(100% - var(--pxr) / 2) calc(var(--pxr) / 2), calc(100% - var(--pxr) / 2) var(--pxr), 100% var(--pxr),
            100% calc(100% - var(--pxr)), calc(100% - var(--pxr) / 2) calc(100% - var(--pxr)), calc(100% - var(--pxr) / 2) calc(100% - var(--pxr) / 2), calc(100% - var(--pxr)) calc(100% - var(--pxr) / 2), calc(100% - var(--pxr)) 100%,
            var(--pxr) 100%, var(--pxr) calc(100% - var(--pxr) / 2), calc(var(--pxr) / 2) calc(100% - var(--pxr) / 2), calc(var(--pxr) / 2) calc(100% - var(--pxr)), 0 calc(100% - var(--pxr))
          );
        }
        .px-round-inner {
          --pxr: 1.8vh;
        }
        /* пиксельные ступенчатые углы тач-кнопок (px вместо vh) */
        .px-btn {
          --pxr: 12px;
          clip-path: polygon(
            0 var(--pxr), calc(var(--pxr) / 2) var(--pxr), calc(var(--pxr) / 2) calc(var(--pxr) / 2), var(--pxr) calc(var(--pxr) / 2), var(--pxr) 0,
            calc(100% - var(--pxr)) 0, calc(100% - var(--pxr)) calc(var(--pxr) / 2), calc(100% - var(--pxr) / 2) calc(var(--pxr) / 2), calc(100% - var(--pxr) / 2) var(--pxr), 100% var(--pxr),
            100% calc(100% - var(--pxr)), calc(100% - var(--pxr) / 2) calc(100% - var(--pxr)), calc(100% - var(--pxr) / 2) calc(100% - var(--pxr) / 2), calc(100% - var(--pxr)) calc(100% - var(--pxr) / 2), calc(100% - var(--pxr)) 100%,
            var(--pxr) 100%, var(--pxr) calc(100% - var(--pxr) / 2), calc(var(--pxr) / 2) calc(100% - var(--pxr) / 2), calc(var(--pxr) / 2) calc(100% - var(--pxr)), 0 calc(100% - var(--pxr))
          );
        }
        body {
          margin: 0;
          background: ${BG_COLOR};
          overflow: hidden;
        }
      `}</style>
    </div>
  )
}
