import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";

// POST /api/head_pos  { car: "Banana" | "BlueBanana", variant: "both"|"blue"|"red", pos: [x, y] }
// Пишет pos узла Head в public/game_data.json. Шарнир головы у всех машин
// head-local (инспекция scripts/inspect_heads.py), поэтому других правок не нужно.
const DATA_PATH = path.join(process.cwd(), "public", "game_data.json");
const BACKUP_DIR = path.join(process.cwd(), "scripts", "gamedata_backups");
const MAX_BACKUPS = 10;
const POS_LIMIT = 2; // юниты; все головы машин в пределах ~0.35

interface HeadPickBody {
  car?: unknown;
  variant?: unknown;
  pos?: unknown;
}

function bad(error: string, status = 400) {
  return NextResponse.json({ ok: false, error }, { status });
}

async function backup(raw: string): Promise<void> {
  await fs.mkdir(BACKUP_DIR, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  await fs.writeFile(path.join(BACKUP_DIR, `game_data.${stamp}.json`), raw, "utf8");
  const files = (await fs.readdir(BACKUP_DIR)).filter((f) => f.startsWith("game_data.")).sort();
  while (files.length > MAX_BACKUPS) {
    const oldest = files.shift();
    if (oldest) await fs.unlink(path.join(BACKUP_DIR, oldest)).catch(() => {});
  }
}

export async function POST(req: Request) {
  let body: HeadPickBody;
  try {
    body = (await req.json()) as HeadPickBody;
  } catch {
    return bad("тело запроса не JSON");
  }

  const car = typeof body.car === "string" ? body.car.trim() : "";
  const variant = body.variant === "blue" || body.variant === "red" ? body.variant : "both";
  if (!car) return bad("укажи car");
  if (!Array.isArray(body.pos) || body.pos.length !== 2 || !body.pos.every((n) => typeof n === "number" && Number.isFinite(n))) {
    return bad("pos должен быть [x, y] — конечные числа");
  }
  const [x, y] = body.pos as [number, number];
  if (Math.abs(x) > POS_LIMIT || Math.abs(y) > POS_LIMIT) {
    return bad(`pos вне разумного диапазона (|x|,|y| ≤ ${POS_LIMIT})`);
  }

  let raw: string;
  let data: { cars?: Record<string, { tree?: { children?: Array<{ name?: string; pos?: number[] }> } }> };
  try {
    raw = await fs.readFile(DATA_PATH, "utf8");
    data = JSON.parse(raw);
  } catch (e) {
    return bad("не удалось прочитать game_data.json: " + String(e), 500);
  }
  const cars = data.cars || {};

  // цель: либо прямой ключ ("BlueBanana"), либо базовое имя по вариантам
  let targets: string[];
  if (cars[car]) {
    targets = [car];
  } else {
    const want: string[] = [];
    if (variant === "blue" || variant === "both") want.push("Blue" + car);
    if (variant === "red" || variant === "both") want.push("Red" + car);
    targets = want;
  }
  const missing = targets.filter((t) => !cars[t]);
  if (missing.length === targets.length) {
    return bad("машина не найдена: " + car + (missing.length ? " (нет " + missing.join(", ") + ")" : ""));
  }

  await backup(raw).catch(() => {});

  const updated: string[] = [];
  const skipped: string[] = [];
  for (const t of targets) {
    const tree = cars[t]?.tree;
    const head = (tree?.children || []).find((c) => String(c?.name || "").toLowerCase() === "head");
    if (!head) {
      skipped.push(t);
      continue;
    }
    head.pos = [x, y];
    updated.push(t);
  }
  if (!updated.length) return bad("узел Head не найден у " + targets.join(", "));

  try {
    await fs.writeFile(DATA_PATH, JSON.stringify(data, null, 2) + "\n", "utf8");
  } catch (e) {
    return bad("не удалось записать game_data.json: " + String(e), 500);
  }

  return NextResponse.json({ ok: true, updated, skipped, pos: [x, y], variant });
}
