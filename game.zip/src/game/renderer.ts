/**
 * Canvas renderer — replicates Unity SpriteRenderers with the original sprite sheets.
 * Draw order follows Unity sorting layers: Default(0) < Car(1); inside Default by order.
 */
import * as pl from 'planck'
import { SHEETS, SPR, BACKGROUND, UI_SPRITES, type SpriteRef } from './data'
import { GameEngine, ORTHO_SIZE, TARGET_ASPECT, WORLD_HEIGHT, type Side } from './engine'

export const RT_W = 160 // Unity Screen.renderTexture 160x90, Point filter (pixelated jumbotron)
export const RT_H = 90

type Body = pl.Body

export class Renderer {
  private sheets = new Map<string, HTMLImageElement>()
  private loaded = 0
  private total = 0
  private ready = false
  private jumbo = document.createElement('canvas')
  private jumboCtx: CanvasRenderingContext2D

  constructor() {
    this.jumbo.width = RT_W
    this.jumbo.height = RT_H
    this.jumboCtx = this.jumbo.getContext('2d')!
  }

  load(onDone?: () => void) {
    const names = Object.keys(SHEETS)
    this.total = names.length
    for (const name of names) {
      const img = new Image()
      img.src = SHEETS[name].src
      img.onload = () => {
        this.loaded++
        if (this.loaded >= this.total) {
          this.ready = true
          onDone?.()
        }
      }
      this.sheets.set(name, img)
    }
  }

  isReady() {
    return this.ready
  }

  /** Camera framing — Unity CameraScaler (Expand mode): locks width on narrow screens, height on wide. */
  static viewSize(cssW: number, cssH: number) {
    const aspect = cssW / cssH
    if (TARGET_ASPECT > aspect) {
      // narrow portrait: lock world width to TARGET_ASPECT * WORLD_HEIGHT
      const w = TARGET_ASPECT * WORLD_HEIGHT
      return { w, h: w / aspect }
    }
    return { w: WORLD_HEIGHT * aspect, h: WORLD_HEIGHT }
  }

  static rtViewSize() {
    // RenderCamera renders to the 160x90 (16:9) texture
    const aspect = RT_W / RT_H
    return { w: WORLD_HEIGHT * aspect, h: WORLD_HEIGHT }
  }

  private drawSprite(
    ctx: CanvasRenderingContext2D,
    name: string | null,
    x: number,
    y: number,
    rotDeg: number,
    scale: number,
    worldToPx: (wx: number, wy: number) => [number, number],
    pxPerUnit: number
  ) {
    if (!name) return
    const ref = SPR[name] as SpriteRef | undefined
    if (!ref) return
    const img = this.sheets.get(ref.sheet)
    if (!img || !img.complete) return
    const ppu = SHEETS[ref.sheet].ppu
    const [cx, cy] = worldToPx(x, y)
    const w = (ref.w / ppu) * pxPerUnit * scale
    const h = (ref.h / ppu) * pxPerUnit * scale
    ctx.save()
    ctx.translate(cx, cy)
    if (rotDeg) ctx.rotate((rotDeg * Math.PI) / 180)
    ctx.drawImage(img, ref.x, ref.y, ref.w, ref.h, -w / 2, -h / 2, w, h)
    ctx.restore()
  }

  /** Draw the full scene once (used for both main view and the jumbotron RT). */
  drawScene(
    ctx: CanvasRenderingContext2D,
    engine: GameEngine,
    cssW: number,
    cssH: number,
    view: { w: number; h: number },
    includeJumbo: boolean
  ) {
    const pxPerUnit = cssH / view.h
    const worldToPx = (wx: number, wy: number): [number, number] => [
      (wx * pxPerUnit) + cssW / 2,
      cssH / 2 - wy * pxPerUnit,
    ]

    // RenderCamera clear color (0.192, 0.302, 0.475)
    ctx.fillStyle = `rgb(${BACKGROUND.color.map((c) => Math.round(c * 255)).join(',')})`
    ctx.fillRect(0, 0, cssW, cssH)

    // PeopleBackground (order 0) — center + side copies at ±9.46
    for (const sx of BACKGROUND.sideX) {
      this.drawSprite(ctx, BACKGROUND.peopleBack.sprite, sx + BACKGROUND.peopleBack.pos[0], BACKGROUND.peopleBack.pos[1], 0, 1, worldToPx, pxPerUnit)
    }

    // jumbotron screen quad (Unity MeshRenderer order 0 — above backdrop, below crowd)
    if (includeJumbo && this.ready) {
      const q = BACKGROUND.screenQuad
      const [qx, qy] = worldToPx(q.pos[0], q.pos[1])
      const qw = q.scale[0] * pxPerUnit
      const qh = q.scale[1] * pxPerUnit
      // render RenderCamera view (16:9) into the pixelated RT
      const rtView = Renderer.rtViewSize()
      this.jumboCtx.imageSmoothingEnabled = false
      this.drawScene(this.jumboCtx, engine, RT_W, RT_H, rtView, false)
      ctx.save()
      ctx.imageSmoothingEnabled = false
      ctx.drawImage(this.jumbo, qx - qw / 2, qy - qh / 2, qw, qh)
      ctx.restore()
    }

    // People crowd (order 1)
    for (const sx of BACKGROUND.sideX) {
      this.drawSprite(ctx, BACKGROUND.people.sprite, sx + BACKGROUND.people.pos[0], BACKGROUND.people.pos[1], 0, 1, worldToPx, pxPerUnit)
    }

    // Arena (order 2) + decorations
    const arena = engine.arena
    if (arena) {
      this.drawSprite(ctx, arena.sprite, arena.pos[0], arena.pos[1], 0, 1, worldToPx, pxPerUnit)
      for (const d of arena.deco) {
        this.drawSprite(ctx, d.sprite, d.pos[0], d.pos[1], d.rot, 1, worldToPx, pxPerUnit)
      }
    }

    // Cars (Unity sorting layer "Car" — above everything)
    for (const side of ['blue', 'red'] as Side[]) {
      const car = side === 'blue' ? engine.blue : engine.red
      if (!car) continue
      const bp = car.body.getPosition()
      const ba = car.body.getAngle()
      // body sprite first (Unity order 1), then wheels/head (order 2)
      this.drawSprite(ctx, car.def.body.sprite, bp.x, bp.y, (-ba * 180) / Math.PI, 1, worldToPx, pxPerUnit)
      for (const w of car.wheels) {
        const wp = w.getPosition()
        const wa = w.getAngle()
        this.drawSprite(ctx, car.def.wheels[0].sprite, wp.x, wp.y, (-wa * 180) / Math.PI, 1, worldToPx, pxPerUnit)
      }
      const hp = car.head.getPosition()
      const ha = car.head.getAngle()
      this.drawSprite(ctx, car.def.head.sprite, hp.x, hp.y, (-ha * 180) / Math.PI, 1, worldToPx, pxPerUnit)
    }

    // ball rotates: draw dynamic ball sprite rotation too
    if (arena?.ball && engine.ballBody) {
      const pos = engine.ballBody.getPosition()
      const ang = engine.ballBody.getAngle()
      this.drawSprite(ctx, arena.ball.sprite, pos.x, pos.y, (-ang * 180) / Math.PI, arena.ball.spriteScale, worldToPx, pxPerUnit)
    }

    // hit effects: 20 white particles, burst at t=0, lifetime 1s (Unity HitParticle)
    for (const e of engine.hitEffects) {
      const t = e.t
      ctx.save()
      for (let i = 0; i < 20; i++) {
        // deterministic pseudo-random per particle index
        const a1 = (i * 137.508 + Math.floor(e.x * 7 + e.y * 13) * 91.7) % (Math.PI * 2)
        const speed = 0.5 + ((i * 53) % 100) / 100 * 0.9
        const size = 0.3 + ((i * 29) % 100) / 100 * 0.2
        const px = e.x + Math.cos(a1) * speed * t
        const py = e.y + Math.sin(a1) * speed * t - 4.905 * t * t * 0.25
        const [cx, cy] = worldToPx(px, py)
        const r = (size / 2) * pxPerUnit * (1 - t * 0.4)
        ctx.globalAlpha = Math.max(0, 1 - t)
        ctx.fillStyle = '#ffffff'
        ctx.beginPath()
        ctx.arc(cx, cy, Math.max(0.5, r), 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.restore()
      ctx.globalAlpha = 1
    }
  }

  drawWorld(
    ctx: CanvasRenderingContext2D,
    engine: GameEngine,
    cssW: number,
    cssH: number
  ) {
    const view = Renderer.viewSize(cssW, cssH)
    this.drawScene(ctx, engine, cssW, cssH, view, true)
  }
}

export function bodyOf(b: Body) {
  return b
}

export { UI_SPRITES }
