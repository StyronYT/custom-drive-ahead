/**
 * Drive Ahead — main game controller: input, loop, wiring.
 * Controls replicate Unity InputSystem_Actions:
 *   Blue: A/D move, R reset  |  Red: ←/→ move, / reset  |  Space: restart after game over
 */
import { GameEngine, FIXED_DT } from './engine'
import { Renderer } from './renderer'

export interface GameCallbacks {
  onScore: (score: { blue: number; red: number }, scoredSide: 'blue' | 'red') => void
  onRoundStart: (info: { blueCar: string; redCar: string; arena: string }) => void
  onGameOver: (winner: 'blue' | 'red') => void
}

export class DriveAheadGame {
  engine = new GameEngine()
  renderer = new Renderer()
  private raf = 0
  private lastT = 0
  private keys = new Set<string>()
  private canvas: HTMLCanvasElement
  private ctx: CanvasRenderingContext2D
  private running = false
  private cb: GameCallbacks

  constructor(canvas: HTMLCanvasElement, cb: GameCallbacks) {
    this.canvas = canvas
    this.ctx = canvas.getContext('2d')!
    this.cb = cb
    this.engine.onScoreChanged = (side) => {
      this.cb.onScore({ ...this.engine.score }, side)
      if (this.engine.isGameOver()) this.cb.onGameOver(this.engine.whoWin())
    }
    this.engine.onRoundRestart = () => {
      this.cb.onRoundStart(this.roundInfo())
    }
  }

  roundInfo() {
    return {
      blueCar: this.engine.blue?.def.key ?? '',
      redCar: this.engine.red?.def.key ?? '',
      arena: this.engine.arena?.key ?? '',
    }
  }

  start() {
    ;(window as unknown as Record<string, unknown>).__game = this
    this.renderer.load(() => {
      this.engine.startRound()
      this.cb.onRoundStart(this.roundInfo())
    })
    window.addEventListener('keydown', this.onKeyDown)
    window.addEventListener('keyup', this.onKeyUp)
    this.running = true
    this.lastT = performance.now()
    this.raf = requestAnimationFrame(this.loop)
  }

  stop() {
    this.running = false
    cancelAnimationFrame(this.raf)
    window.removeEventListener('keydown', this.onKeyDown)
    window.removeEventListener('keyup', this.onKeyUp)
  }

  private updateInputs() {
    const k = this.keys
    const blue = (k.has('KeyD') ? 1 : 0) - (k.has('KeyA') ? 1 : 0)
    const red = (k.has('ArrowRight') ? 1 : 0) - (k.has('ArrowLeft') ? 1 : 0)
    this.engine.setMoveInput('blue', blue)
    this.engine.setMoveInput('red', red)
  }

  private onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) return
    this.keys.add(e.code)
    if (e.code === 'KeyR') this.engine.resetCar('blue')
    if (e.code === 'Slash') this.engine.resetCar('red')
    if (e.code === 'Space') {
      if (this.engine.canRestart()) this.engine.restartGame()
      e.preventDefault()
    }
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Slash'].includes(e.code)) {
      e.preventDefault()
    }
  }

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code)
  }

  private loop = (t: number) => {
    if (!this.running) return
    const dt = Math.min(0.1, (t - this.lastT) / 1000)
    this.lastT = t
    this.updateInputs()
    this.engine.update(dt)

    // resize canvas to css size x DPR
    const dpr = Math.min(2, window.devicePixelRatio || 1)
    const rect = this.canvas.getBoundingClientRect()
    const w = Math.round(rect.width * dpr)
    const h = Math.round(rect.height * dpr)
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w
      this.canvas.height = h
    }
    const ctx = this.ctx
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    ctx.imageSmoothingEnabled = true
    this.renderer.drawWorld(ctx, this.engine, rect.width, rect.height)
    void FIXED_DT
    this.raf = requestAnimationFrame(this.loop)
  }
}
