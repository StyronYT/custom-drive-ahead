/**
 * Drive Ahead — HTML port of the Unity C# game (github.com/blackvalter/Drive-Ahead).
 * Physics: planck.js (Box2D) — the same engine Unity's 2D physics is built on.
 * All constants are extracted verbatim from the Unity project assets.
 */
import * as pl from 'planck'
import { CARS, ARENAS, BORDER_BOXES, CAR_DATA, type CarDef, type ArenaDef } from './data'

// Unity CameraScaler: ReferenceResolution 1080x1920, Mode Expand, Main Camera ortho size 2.5714285
export const ORTHO_SIZE = 2.5714285
export const WORLD_HEIGHT = ORTHO_SIZE * 2
export const TARGET_ASPECT = 1080 / 1920
// Unity 2D default fixed timestep
export const FIXED_DT = 1 / 50
export const GRAVITY = -9.81
export const WIN_SCORE = 5

export type Side = 'blue' | 'red'

// Physics materials from the Unity project (TireFriction.physicsMaterial2D / NoFriction.physicsMaterial2D)
const MAT_FRICTION: Record<string, number> = {
  TireFriction: 3,
  NoFriction: 0.1,
  None: 0.6, // Unity default when no PhysicsMaterial2D is assigned
}
const MAT_BOUNCE: Record<string, number> = {
  TireFriction: 0,
  NoFriction: 0,
  None: 0,
}

export interface FixtureTag {
  kind: 'head' | 'wall' | 'border' | 'ball'
  car?: Side
}

interface CarInstance {
  def: CarDef
  side: Side
  body: pl.Body
  wheels: pl.Body[]
  head: pl.Body
  startPos: pl.Vec2
  moveInput: number
  destroyed: boolean
}

function polyArea(poly: number[][]): number {
  let a = 0
  for (let i = 0; i < poly.length; i++) {
    const [x1, y1] = poly[i]
    const [x2, y2] = poly[(i + 1) % poly.length]
    a += x1 * y2 - x2 * y1
  }
  return a / 2
}

function ensureCCW(poly: number[][]): number[][] {
  return polyArea(poly) < 0 ? [...poly].reverse() : poly
}

/** Ear-clipping triangulation (concave simple polygons from Unity PolygonCollider2D). */
function triangulate(input: number[][]): number[][][] {
  const poly = ensureCCW(input.map((p) => [p[0], p[1]]))
  const n = poly.length
  if (n < 3) return []
  if (n === 3) return [poly]
  const idx = Array.from({ length: n }, (_, i) => i)
  const triangles: number[][][] = []
  const cross = (o: number[], a: number[], b: number[]) =>
    (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
  let guard = 0
  while (idx.length > 3 && guard++ < 10000) {
    let clipped = false
    const m = idx.length
    for (let i = 0; i < m; i++) {
      const a = idx[(i + m - 1) % m], b = idx[i], c = idx[(i + 1) % m]
      const va = poly[a], vb = poly[b], vc = poly[c]
      if (cross(va, vb, vc) <= 1e-12) continue // reflex or degenerate
      let inCone = false
      for (const p of idx) {
        if (p === a || p === b || p === c) continue
        const vp = poly[p]
        if (
          cross(va, vb, vp) >= -1e-12 &&
          cross(vb, vc, vp) >= -1e-12 &&
          cross(vc, va, vp) >= -1e-12
        ) { inCone = true; break }
      }
      if (inCone) continue
      triangles.push([va, vb, vc])
      idx.splice(i, 1)
      clipped = true
      break
    }
    if (!clipped) {
      // fallback: fan triangulation
      for (let i = 1; i < idx.length - 1; i++) {
        triangles.push([poly[idx[0]], poly[idx[i]], poly[idx[i + 1]]])
      }
      break
    }
  }
  if (idx.length === 3) triangles.push([poly[idx[0]], poly[idx[1]], poly[idx[2]]])
  return triangles
}

export class GameEngine {
  world: pl.World
  blue: CarInstance | null = null
  red: CarInstance | null = null
  arena: ArenaDef | null = null
  ballBody: pl.Body | null = null
  score: { blue: number; red: number } = { blue: 0, red: 0 }
  roundOver = false
  timeScale = 1
  slowMoLeft = 0
  hitEffects: { x: number; y: number; t: number }[] = []

  onScoreChanged: (side: Side) => void = () => {}
  onRoundRestart: () => void = () => {}

  private pendingHits: Side[] = []
  private accumulator = 0

  constructor() {
    this.world = new pl.World({ gravity: pl.Vec2(0, GRAVITY) })
    // Unity FrictionCombine=Average, BounceCombine=Minimum
    this.world.on('pre-solve', (contact) => {
      const fa = contact.getFixtureA()
      const fb = contact.getFixtureB()
      contact.setFriction((fa.getFriction() + fb.getFriction()) / 2)
      contact.setRestitution(Math.min(fa.getRestitution(), fb.getRestitution()))
    })
    this.world.on('begin-contact', (contact) => {
      const fa = contact.getFixtureA()
      const fb = contact.getFixtureB()
      const ta = fa.getUserData() as FixtureTag | null
      const tb = fb.getUserData() as FixtureTag | null
      if (ta && ta.kind === 'head' && ta.car) this.pendingHits.push(ta.car)
      if (tb && tb.kind === 'head' && tb.car) this.pendingHits.push(tb.car)
    })
    this.buildBorders()
  }

  private buildBorders() {
    for (const b of BORDER_BOXES) {
      const body = this.world.createBody({ type: 'static' })
      body.createFixture(
        pl.Box(b.size[0] / 2, b.size[1] / 2, pl.Vec2(b.offset[0], b.offset[1]), 0),
        { friction: MAT_FRICTION['None'], restitution: MAT_BOUNCE['None'] }
      )
      body.setUserData({ kind: 'border' } as FixtureTag)
    }
  }

  isGameOver() {
    return this.score.blue >= WIN_SCORE || this.score.red >= WIN_SCORE
  }
  whoWin(): Side {
    return this.score.blue >= WIN_SCORE ? 'blue' : 'red'
  }

  /** BattleSetupManager.Start: random arena + random cars from per-color pools. */
  startRound() {
    this.destroyRound()
    const arena = ARENAS[Math.floor(Math.random() * ARENAS.length)]
    this.arena = arena
    this.buildArena(arena)
    const bluePool = CARS.filter((c) => c.color === 'Blue')
    const redPool = CARS.filter((c) => c.color === 'Red')
    const blueDef = bluePool[Math.floor(Math.random() * bluePool.length)]
    const redDef = redPool[Math.floor(Math.random() * redPool.length)]
    this.blue = this.spawnCar(blueDef, 'blue', arena.spawns.blue!)
    this.red = this.spawnCar(redDef, 'red', arena.spawns.red!)
    this.roundOver = false
    this.timeScale = 1
    this.slowMoLeft = 0
  }

  private destroyRound() {
    let body = this.world.getBodyList()
    while (body) {
      const next = body.getNext()
      const tag = body.getUserData() as FixtureTag | null
      if (!(tag && tag.kind === 'border')) {
        this.world.destroyBody(body)
      }
      body = next
    }
    this.blue = null
    this.red = null
    this.ballBody = null
    this.hitEffects = []
  }

  private buildArena(arena: ArenaDef) {
    // PolygonCollider2D paths of the arena object + its children, as chain loops (static)
    for (const path of arena.walls) {
      const body = this.world.createBody({ type: 'static' })
      const verts = path.map((p) => pl.Vec2(p[0], p[1]))
      body.createFixture(pl.Chain(verts, true), {
        friction: MAT_FRICTION['None'],
        restitution: MAT_BOUNCE['None'],
      })
      body.setUserData({ kind: 'wall' } as FixtureTag)
    }
    if (arena.ball) {
      const b = arena.ball
      const body = this.world.createBody({
        type: 'dynamic',
        position: pl.Vec2(b.pos[0], b.pos[1]),
        // Unity: HingeJoint2D to the world => ball spins in place
      })
      const area = Math.PI * b.radius * b.radius
      body.createFixture(pl.Circle(b.radius), {
        density: b.mass / area,
        friction: MAT_FRICTION['None'],
        restitution: MAT_BOUNCE['None'],
      })
      body.setUserData({ kind: 'ball' } as FixtureTag)
      const ground = this.world.createBody({ type: 'static', position: pl.Vec2(b.pos[0], b.pos[1]) })
      this.world.createJoint(pl.RevoluteJoint({}, ground, body, pl.Vec2(b.pos[0], b.pos[1])))
      this.ballBody = body
    }
  }

  private spawnCar(def: CarDef, side: Side, spawn: number[]): CarInstance {
    const data = CAR_DATA[def.bodyType]
    const car: CarInstance = {
      def,
      side,
      body: null as unknown as pl.Body,
      wheels: [],
      head: null as unknown as pl.Body,
      startPos: pl.Vec2(spawn[0], spawn[1]),
      moveInput: 0,
      destroyed: false,
    }

    // --- root body (Rigidbody2D mass = def.body.mass) ---
    const body = this.world.createBody({
      type: 'dynamic',
      position: pl.Vec2(spawn[0], spawn[1]),
      angularDamping: 0,
      linearDamping: 0,
    })
    car.body = body
    const polys = def.body.polys
    let totalArea = 0
    const tris: number[][][] = []
    for (const p of polys) {
      const t = triangulate(p)
      tris.push(...t)
      totalArea += Math.abs(polyArea(p))
    }
    const density = totalArea > 0 ? def.body.mass / totalArea : 1
    for (const t of tris) {
      body.createFixture(pl.Polygon(t.map((p) => pl.Vec2(p[0], p[1]))), {
        density,
        friction: MAT_FRICTION[def.body.material ?? 'None'],
        restitution: MAT_BOUNCE[def.body.material ?? 'None'],
      })
    }
    body.setUserData({ kind: 'wall' } as FixtureTag)

    // --- wheels (circle colliders, own Rigidbody2D) ---
    for (const w of def.wheels) {
      const wb = this.world.createBody({
        type: 'dynamic',
        position: pl.Vec2(spawn[0] + w.pos[0], spawn[1] + w.pos[1]),
        angularDamping: 0.05,
      })
      const area = Math.PI * w.radius * w.radius
      wb.createFixture(pl.Circle(w.radius), {
        density: w.mass / area,
        friction: MAT_FRICTION[w.material ?? 'None'],
        restitution: MAT_BOUNCE[w.material ?? 'None'],
      })
      wb.setUserData({ kind: 'wall' } as FixtureTag)
      car.wheels.push(wb)
    }

    // --- WheelJoint2D: suspension frequency 5 Hz, damping 0.3, axis (0,1) ---
    for (const j of def.wheelJoints) {
      const wheel = car.wheels[j.wheel]
      this.world.createJoint(
        pl.WheelJoint(
          { frequencyHz: j.frequency, dampingRatio: j.dampingRatio, enableLimit: false, enableMotor: false },
          body,
          wheel,
          pl.Vec2(spawn[0] + j.anchor[0], spawn[1] + j.anchor[1]),
          pl.Vec2(0, 1)
        )
      )
    }

    // --- head (HingeJoint2D with ±limits, gravityScale -0.1) ---
    const h = def.head
    const head = this.world.createBody({
      type: 'dynamic',
      position: pl.Vec2(spawn[0] + h.pos[0], spawn[1] + h.pos[1]),
      gravityScale: h.gravityScale,
      angularDamping: 0.05,
    })
    const hArea = Math.PI * h.radius * h.radius
    const headFixture = head.createFixture(pl.Circle(h.radius), {
      density: h.mass / hArea,
      friction: MAT_FRICTION['None'],
      restitution: MAT_BOUNCE['None'],
    })
    headFixture.setUserData({ kind: 'head', car: side } as FixtureTag)
    head.setUserData({ kind: 'head', car: side } as FixtureTag)
    car.head = head
    this.world.createJoint(
      pl.RevoluteJoint(
        {
          enableLimit: true,
          lowerAngle: (h.limits[0] * Math.PI) / 180,
          upperAngle: (h.limits[1] * Math.PI) / 180,
        },
        body,
        head,
        pl.Vec2(spawn[0] + h.anchorOnBody[0], spawn[1] + h.anchorOnBody[1])
      )
    )
    return car
  }

  /** CarController.OnReset (R / slash) */
  resetCar(side: Side) {
    const car = side === 'blue' ? this.blue : this.red
    if (!car || car.moveInput === undefined) return
    car.moveInput = 0
    car.body.setLinearVelocity(pl.Vec2(0, 0))
    car.body.setAngularVelocity(0)
    car.body.setAngle(0)
    car.body.setPosition(car.startPos)
    for (const w of car.wheels) w.setAngularVelocity(0)
  }

  setMoveInput(side: Side, input: number) {
    const car = side === 'blue' ? this.blue : this.red
    if (car) car.moveInput = input
  }

  /** GameManager.ReportHeadHit — head touched anything => round over. */
  private reportHeadHit(loser: Side) {
    if (this.roundOver) return
    this.roundOver = true
    const winner: Side = loser === 'blue' ? 'red' : 'blue'
    if (winner === 'blue') this.score.blue++
    else this.score.red++
    const car = loser === 'blue' ? this.blue : this.red
    if (car) this.hitEffects.push({ x: car.body.getPosition().x, y: car.body.getPosition().y, t: 0 })
    this.onScoreChanged(winner)
    // GameManager.HandleRoundEnd: lock movement, timeScale 0.5, 3 realtime seconds
    this.slowMoLeft = 3
    this.timeScale = 0.5
  }

  /** Realtime update (dt in real seconds). */
  update(realDt: number) {
    if (this.slowMoLeft > 0) {
      this.slowMoLeft -= realDt
      if (this.slowMoLeft <= 0) {
        this.slowMoLeft = 0
        this.timeScale = 1
        if (!this.isGameOver()) {
          this.startRound()
          this.onRoundRestart()
          return
        }
        // game over: keep last frame, wait for Space restart
      }
    }
    for (const e of this.hitEffects) e.t += realDt
    this.hitEffects = this.hitEffects.filter((e) => e.t < 1)

    this.accumulator += realDt * this.timeScale
    let steps = 0
    while (this.accumulator >= FIXED_DT && steps < 8) {
      this.accumulator -= FIXED_DT
      steps++
      this.fixedStep()
    }
  }

  /** CarController.FixedUpdate */
  private fixedStep() {
    const carBlue = this.blue
    const carRed = this.red
    for (const car of [carBlue, carRed]) {
      if (!car) continue
      const locked = this.roundOver
      const input = locked ? 0 : car.moveInput
      const data = CAR_DATA[car.def.bodyType]
      // wheelTorque = -moveInput * speed * fixedDeltaTime (Unity AddTorque, Force mode)
      const wheelTorque = -input * data.speed * FIXED_DT
      for (const w of car.wheels) w.applyTorque(wheelTorque)
      // body torque for wheelies
      car.body.applyTorque(input * data.rotationSpeed * FIXED_DT)
    }
    // process queued head hits AFTER torque setup, BEFORE world.step is fine — queue first
    this.world.step(FIXED_DT)
    if (this.pendingHits.length > 0) {
      const loser = this.pendingHits[0]
      this.pendingHits = []
      this.reportHeadHit(loser)
    }
  }

  canRestart() {
    return this.isGameOver() && this.roundOver && this.slowMoLeft <= 0
  }

  /** GameManager.RestartGame (Space) */
  restartGame() {
    this.score = { blue: 0, red: 0 }
    this.onScoreChanged(this.whoWin())
    this.startRound()
    this.onRoundRestart()
  }
}
