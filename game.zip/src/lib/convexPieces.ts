import decomp from 'poly-decomp'

void decomp.quickDecomp

export type Vec = [number, number]

/* Знаковая удвоенная площадь (shoelace): >0 — обход CCW (Y-up), <0 — CW */
function signedArea2(pts: Vec[]): number {
  let a2 = 0
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i]
    const q = pts[(i + 1) % pts.length]
    a2 += p[0] * q[1] - q[0] * p[1]
  }
  return a2
}

/* Убираем дубли точек и замыкающий повтор первой */
function clean(pts: Vec[]): Vec[] {
  const out: Vec[] = []
  for (const p of pts) {
    const last = out[out.length - 1]
    if (!last || Math.hypot(p[0] - last[0], p[1] - last[1]) > 1e-9) out.push([p[0], p[1]])
  }
  if (
    out.length >= 3 &&
    Math.hypot(out[0][0] - out[out.length - 1][0], out[0][1] - out[out.length - 1][1]) <= 1e-9
  )
    out.pop()
  return out
}

/* Все рёбра CCW-полигона повёрнуты влево (cross >= 0) */
function isConvexCcw(poly: Vec[]): boolean {
  const n = poly.length
  for (let i = 0; i < n; i++) {
    const a = poly[i]
    const b = poly[(i + 1) % n]
    const c = poly[(i + 2) % n]
    const cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
    if (cross < -1e-9) return false
  }
  return true
}

/* Доводим кусок до выпуклого CCW с положительной площадью, иначе null */
function fixPiece(piece: Vec[]): Vec[] | null {
  let p = clean(piece)
  if (signedArea2(p) < 0) p = [...p].reverse() // неверный обход → CW → отрицательная площадь/инерция
  if (Math.abs(signedArea2(p)) < 1e-9) return null // вырожденный кусок
  p = clean(p)
  return p.length >= 3 && isConvexCcw(p) ? p : null
}

/* Куски больше 8 вершин триангулируем веером: лимит Box2D b2_maxPolygonVertices.
   Куски quickDecomp выпуклые — fan-триангуляция для них корректна. */
function splitBig(piece: Vec[]): Vec[][] {
  if (piece.length <= 8) return [piece]
  const tris: Vec[][] = []
  for (let i = 1; i < piece.length - 1; i++) tris.push([piece[0], piece[i], piece[i + 1]])
  return tris
}

/* Запасная триангуляция невыпуклого полигона (ear clipping) */
function earClip(pts: Vec[]): Vec[][] {
  const idx = pts.map((_, i) => i)
  const tris: Vec[][] = []
  let guard = 0
  while (idx.length > 3 && guard++ < 500) {
    let clipped = false
    for (let i = 0; i < idx.length; i++) {
      const a = pts[idx[(i + idx.length - 1) % idx.length]]
      const b = pts[idx[i]]
      const c = pts[idx[(i + 1) % idx.length]]
      const cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
      if (cross <= 0) continue // вершина не выпуклая (CCW)
      let ok = true
      for (const j of idx) {
        const p = pts[j]
        if (p === a || p === b || p === c) continue
        const d1 = (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])
        const d2 = (c[0] - b[0]) * (p[1] - b[1]) - (c[1] - b[1]) * (p[0] - b[0])
        const d3 = (a[0] - c[0]) * (p[1] - c[1]) - (a[1] - c[1]) * (p[0] - c[0])
        if (d1 >= 0 && d2 >= 0 && d3 >= 0) {
          ok = false
          break
        }
      }
      if (!ok) continue
      tris.push([a, b, c])
      idx.splice(i, 1)
      clipped = true
      break
    }
    if (!clipped) break
  }
  if (idx.length === 3) tris.push([pts[idx[0]], pts[idx[1]], pts[idx[2]]])
  return tris
}

/* Выпуклая декомпозиция полигона (как Unity делает для PolygonCollider2D).
   Гарантия результата: все куски выпуклые, CCW, с положительной площадью.
   Именно это защищает массу/инерцию корпуса: при CW-обходе computeMass даёт
   отрицательные значения и корпус перестаёт вращаться и сталкиваться. */
export function convexPieces(points: Vec[]): Vec[][] {
  const pts0 = clean(points)
  if (pts0.length < 3) return []
  // нормализуем обход к CCW
  const pts = signedArea2(pts0) < 0 ? [...pts0].reverse() : pts0
  if (isConvexCcw(pts)) return [pts]

  // декомпозиция
  const raw = (decomp as any).quickDecomp(pts as unknown as number[][]) as number[][][]
  const out: Vec[][] = []
  for (const piece of raw) {
    for (const sub of splitBig(piece.map((p) => [p[0], p[1]] as Vec))) {
      const fixed = fixPiece(sub)
      if (fixed) out.push(fixed)
    }
  }
  if (out.length) return out

  // запасной план: ear-clipping триангуляция всего полигона
  for (const t of earClip(pts)) {
    const fixed = fixPiece(t)
    if (fixed) out.push(fixed)
  }
  return out
}
