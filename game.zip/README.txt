Игра (Next.js + TypeScript + Tailwind) — как запустить

1. Установи зависимости: bun install (или npm install)
2. Запуск в режиме разработки: bun run dev (или npm run dev) -> http://localhost:3000
3. Прод-сборка: bun run build, затем bun run start

База данных: prisma/sqlite, файл db/custom.db. .env уже настроен на
относительный путь (file:../db/custom.db — резолвится от папки prisma/).

Данные игры:
- public/game_data.json — рабочая копия, которую читает игра;
- game-assets/ — исходные ассеты (спрайты, шрифты, game_data.json);
- repo-src/ — исходники Unity-проекта (C#-скрипты, сцены, префабы).

Инструмент подбора позиции головы машины: страница /head_picker.html на
запущенном сервере. Его же файл public/head_picker.html можно открыть и
отдельно — тогда перетащи в него game_data.json и сохрани через скачивание.

Скрипты ассетов и резервные копии game_data.json лежат в scripts/.
