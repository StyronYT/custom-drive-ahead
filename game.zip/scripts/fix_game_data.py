#!/usr/bin/env python3
"""Точечные фиксы game_data.json:
1) Arenas1_0 (карта с пилой): главный контур (path1, n=182) был закручен по часовой
   (единственный CW в датасете) — односторонние chain-нормали Box2D вывернуты,
   из-за этого коллизия карты «баганная». Разворачиваем порядок точек → CCW.
2) Arenas2_2: collider.paths[0] — открытая ломаная (стена), игра замыкала петлю
   хордой длиной 9.5 (во всю карту) → невидимая стена поперёк арены. Помечаем
   путь как открытый: collider.open = [0] (page.tsx не замыкает такие цепи).
Проверки: winding всех путей после фикса; отчёт.
"""
import json

PATH = '/home/z/my-project/public/game_data.json'
d = json.load(open(PATH))

def area(p):
    a = 0
    for i in range(len(p)):
        x1, y1 = p[i]
        x2, y2 = p[(i + 1) % len(p)]
        a += x1 * y2 - x2 * y1
    return a / 2

fixed = []

# --- 1) карта с пилой: winding главного контура ---
for a in d['arenas']:
    if a['name'] == 'Arenas1_0':
        p1 = a['collider']['paths'][1]
        assert len(p1) == 182, len(p1)
        assert area(p1) < 0, f'ожидали CW, A={area(p1):.2f}'
        a['collider']['paths'][1] = p1[::-1]
        assert area(a['collider']['paths'][1]) > 0
        fixed.append('Arenas1_0 path1: CW -> CCW')

# --- 2) Arenas2_2: открытая ломаная вместо петли ---
for a in d['arenas']:
    if a['name'] == 'Arenas2_2':
        a['collider']['open'] = [0]
        fixed.append('Arenas2_2: collider.open=[0] (цепь не замыкается)')

json.dump(d, open(PATH, 'w'), ensure_ascii=False)
print('FIXED:', *fixed, sep='\n  ')

# контроль: все пути CCW, кроме помеченных open
bad = []
for i, a in enumerate(d['arenas']):
    op = set((a.get('collider') or {}).get('open') or [])
    for j, p in enumerate((a.get('collider') or {}).get('paths') or []):
        if j in op:
            continue
        if area(p) <= 0:
            bad.append((i, a['name'], j, round(area(p), 2)))
print('остальные CW-пути (должно быть пусто):', bad)
