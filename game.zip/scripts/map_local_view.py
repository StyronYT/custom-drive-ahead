#!/usr/bin/env python3
"""Арена в ЧИСТОМ локальном пространстве: спрайт как есть (pivot центр), коллайдер-пути
в локальных координатах. Никаких поворотов и ресайзов — 100% достоверное сравнение."""
import json, math, os
from PIL import Image, ImageDraw

BASE = '/home/z/my-project'
data = json.load(open(f'{BASE}/public/game_data.json'))
manifest = json.load(open(f'{BASE}/public/sprite_manifest.json'))
imgs = {}
for f in os.listdir(f'{BASE}/public/sprites'):
    if f.endswith('.png'):
        imgs[f] = Image.open(f'{BASE}/public/sprites/{f}').convert('RGBA')

S = 90  # px на мировой юнит
PAD = 30

def panel(idx):
    a = data['arenas'][idx]
    f = a['sprite'].replace('/', '__') + '.png'
    img = imgs[f]
    m = manifest.get(a['sprite']) or {}
    ppu = m.get('ppu', 48)
    W = int(img.width / ppu * S) + 2 * PAD
    H = int(img.height / ppu * S) + 2 * PAD
    im = Image.new('RGBA', (W, H), (18, 18, 22, 255))
    # спрайт: центр в (0,0), x вправо, y ВНИЗ у пикселей → мировой y-вверх: рисуем с переворотом
    # PIL: (0,0) сверху. Мировой локальный (x,y): sx = PAD + (x + Wu/2)*S, sy = PAD + (Hu/2 - y)*S
    Wu, Hu = img.width / ppu, img.height / ppu
    im.alpha_composite(img.resize((int(Wu * S), int(Hu * S)), Image.NEAREST), (PAD, PAD))
    d = ImageDraw.Draw(im)
    def w2s(x, y):
        return (PAD + (x + Wu / 2) * S, PAD + (Hu / 2 - y) * S)
    col = a.get('collider') or {}
    for pi, path in enumerate(col.get('paths') or []):
        pts = [w2s(*p) for p in path]
        d.line(pts + [pts[0]], fill=(255, 40, 40, 255), width=2)
        for q in pts:
            d.ellipse([q[0] - 2, q[1] - 2, q[0] + 2, q[1] + 2], fill=(255, 210, 60, 255))
    for name, colr in (('BlueSpawn', (60, 130, 255)), ('RedSpawn', (255, 70, 60))):
        sp = (a.get('spawns') or {}).get(name)
        if sp:
            q = w2s(*sp)
            d.ellipse([q[0] - 7, q[1] - 7, q[0] + 7, q[1] + 7], outline=colr, width=3)
    d.text((6, 4), f"#{idx} {a['name']} LOCAL", fill=(255, 255, 0, 255))
    return im

targets = [0, 1, 2, 6, 10, 11, 12]
os.makedirs('/tmp/mapview', exist_ok=True)
for i in targets:
    panel(i).convert('RGB').save(f'/tmp/mapview/local_{i}.png')

# склеим в один лист вертикально (ширина max)
panels = [Image.open(f'/tmp/mapview/local_{i}.png') for i in targets]
W = max(p.width for p in panels)
H = sum(p.height for p in panels) + len(panels) * 4
sheet = Image.new('RGB', (W, H), (0, 0, 0))
y = 0
for p in panels:
    sheet.paste(p, (0, y))
    y += p.height + 4
sheet.save('/tmp/mapview/local_all.png')
print('saved local_all.png', sheet.size, 'targets:', targets)
