window.__probe2 = (async () => {
  const S = window.__game
  const sleep = ms => new Promise(r => setTimeout(r, ms))
  S.forceCars = { blue: 'BlueWeevil', red: 'RedWeevil' }
  S.roundOver = false
  S.buildRound()
  await sleep(350)
  const log = []
  const label = b => {
    if (b === S.blue.body) return 'blueBody'
    if (b === S.red.body) return 'redBody'
    if (S.blue.wheels.includes(b)) return 'blueWheel'
    if (S.red.wheels.includes(b)) return 'redWheel'
    if (b === S.blue.head) return 'blueHead'
    if (b === S.red.head) return 'redHead'
    if (S.ballBodies.includes(b)) return 'saw'
    return 'other'
  }
  S.world.on('begin-contact', c => {
    const a = label(c.getFixtureA().getBody())
    const b = label(c.getFixtureB().getBody())
    if ((a.startsWith('blue') && b.startsWith('red')) || (a.startsWith('red') && b.startsWith('blue')))
      log.push(a + '-' + b)
  })
  // корпус в корпус: ставим синий корпус вплотную к красному на той же высоте
  const rx = S.red.body.getPosition().x
  const ry = S.red.body.getPosition().y
  S.blue.body.setPosition({ x: rx - 1.6, y: ry + 0.25 })
  S.blue.body.setLinearVelocity({ x: 4, y: 0 })
  await sleep(600)
  const bx = S.blue.body.getPosition().x
  return JSON.stringify({ contacts: log, finalDx: +(rx - bx).toFixed(2) })
})()
