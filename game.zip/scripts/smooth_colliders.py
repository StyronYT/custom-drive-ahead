#!/usr/bin/env python3
"""Сглаживание коллайдеров арен (game_data.json):
1) удаление «джанк»-вершин вне арта (альфа спрайта < порога) — хвосты-диагонали к углам bbox;
2) упрощение Рамера-Дугласа-Пекера (eps=0.03 юнита ≈ 4px) — меньше швов между сегментами цепи;
3) срез (chamfer) острых углов — колёса катятся по кончику пандуса, а не цепляются за него.
Winding (CCW) и open-пути сохраняются. Отчёт по каждой карте.
"""
import json, math
from PIL import Image

BASE = '/home/z/my-project'
PATH = f'{BASE}/public/game_data.json'
d = json.load(open(PATH))
manifest = json.load(open(f'{BASE}/public/sprite_manifest.json'))

RDP_EPS = 0.055
CHAMFER_D = 0.05
CHAMFER_ANGLE = 65.0   # градусов внешнего угла
ALPHA_TH = 10

img_cache = {}

def get_alpha(name):
    if name in img_cache:
        return img_cache[name]
    a = [x for x in d['arenas'] if x['name'] == name][0]
    f = a['sprite'].replace('/', '__') + '.png'
    im = Image.open(f'{BASE}/public/sprites/{f}').convert('RGBA')
    mm = manifest.get(a['sprite']) or {}
    ppu = mm.get('ppu', 48)
    W, H = im.width, im.height
    al = im.split()[3].load()
    img_cache[name] = (al, W, H, W / ppu, H / ppu)
    return img_cache[name]

def alpha_at(name, lx, ly, r=2):
    """max альфы в квадрате (2r+1) вокруг точки (локальные юниты)."""
    al, W, H, Wu, Hu = get_alpha(name)
    px = int(round((lx + Wu / 2) * (W / Wu)))
    py = int(round((Hu / 2 - ly) * (H / Hu)))
    best = 0
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            x, y = px + dx, py + dy
            if 0 <= x < W and 0 <= y < H:
                v = al[x, y]
                if v > best:
                    best = v
    return best

def area(p):
    a = 0
    for i in range(len(p)):
        x1, y1 = p[i]
        x2, y2 = p[(i + 1) % len(p)]
        a += x1 * y2 - x2 * y1
    return a / 2

def rdp(pts, eps):
    if len(pts) < 3:
        return pts[:]
    keep = [False] * len(pts)
    keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    while stack:
        i0, i1 = stack.pop()
        if i1 <= i0 + 1:
            continue
        ax, ay = pts[i0]
        bx, by = pts[i1]
        dx, dy = bx - ax, by - ay
        L = math.hypot(dx, dy) or 1e-9
        imax, dmax = -1, -1
        for i in range(i0 + 1, i1):
            px, py = pts[i]
            dist = abs(dx * (py - ay) - dy * (px - ax)) / L
            if dist > dmax:
                dmax, imax = dist, i
        if dmax > eps:
            keep[imax] = True
            stack.append((i0, imax))
            stack.append((imax, i1))
    return [p for p, k in zip(pts, keep) if k]

def simplify_closed(pts, eps):
    """RDP замкнутого контура: режем кольцо двумя открытыми дугами
    (якорь → самая дальняя точка → якорь), иначе хорда вырождается в точку."""
    n = len(pts)
    if n < 5:
        return pts[:]
    cx = sum(p[0] for p in pts) / n
    cy = sum(p[1] for p in pts) / n
    anchor = max(range(n), key=lambda i: (pts[i][0] - cx) ** 2 + (pts[i][1] - cy) ** 2)
    far = max(range(n), key=lambda i: (pts[i][0] - pts[anchor][0]) ** 2 + (pts[i][1] - pts[anchor][1]) ** 2)
    if far == anchor:
        far = (anchor + n // 2) % n
    if anchor < far:
        segA = pts[anchor:far + 1]
        segB = pts[far:] + pts[:anchor + 1]
    else:
        segA = pts[anchor:] + pts[:far + 1]
        segB = pts[far:anchor + 1]
    outA = rdp(segA, eps)
    outB = rdp(segB, eps)
    return outA[:-1] + outB[:-1]

def chamfer(pts, d_cut, ang_th):
    n = len(pts)
    if n < 3:
        return pts[:]
    out = []
    for i in range(n):
        p0 = pts[(i - 1) % n]
        p1 = pts[i]
        p2 = pts[(i + 1) % n]
        v1x, v1y = p1[0] - p0[0], p1[1] - p0[1]
        v2x, v2y = p2[0] - p1[0], p2[1] - p1[1]
        l1 = math.hypot(v1x, v1y)
        l2 = math.hypot(v2x, v2y)
        if l1 < 1e-6 or l2 < 1e-6:
            out.append(p1)
            continue
        cosA = max(-1.0, min(1.0, (v1x * v2x + v1y * v2y) / (l1 * l2)))
        turn = math.degrees(math.acos(cosA))  # внешний угол поворота
        if turn < ang_th:
            out.append(p1)
            continue
        d1 = min(d_cut, l1 * 0.45)
        d2 = min(d_cut, l2 * 0.45)
        out.append([p1[0] - v1x / l1 * d1, p1[1] - v1y / l1 * d1])
        out.append([p1[0] + v2x / l2 * d2, p1[1] + v2y / l2 * d2])
    return out

report = []
for a in d['arenas']:
    col = a.get('collider') or {}
    paths = col.get('paths') or []
    if not paths:
        continue
    open_idx = set(col.get('open') or [])
    before_total = after_total = junk_total = 0
    new_paths = []
    for j, p in enumerate(paths):
        before_total += len(p)
        A0 = area(p)
        # 1) джанк-вершины вне арта
        kept = [q for q in p if alpha_at(a['name'], q[0], q[1]) >= ALPHA_TH]
        if len(kept) < 3:
            kept = p[:]  # арт-путь мог целиком попасть под порог — не трогаем
        junk_total += len(p) - len(kept)
        p2 = kept
        # 2) RDP
        p2 = simplify_closed(p2, RDP_EPS) if j not in open_idx else rdp(p2, RDP_EPS)
        # 3) chamfer
        p2 = chamfer(p2, CHAMFER_D, CHAMFER_ANGLE)
        # сохранить ориентацию winding
        if j not in open_idx and len(p2) >= 3 and area(p2) * A0 < 0:
            p2 = p2[::-1]
        if len(p2) < 2:
            p2 = p[:]  # не даём выродиться
        after_total += len(p2)
        new_paths.append(p2)
    col['paths'] = new_paths
    report.append((a['name'], before_total, after_total, junk_total))

json.dump(d, open(PATH, 'w'), ensure_ascii=False)
print(f"{'арена':<16}{'вершин до':>10}{'после':>8}{'джанк':>7}")
tb = ta = tj = 0
for n, b, aft, jk in report:
    print(f'{n:<16}{b:>10}{aft:>8}{jk:>7}')
    tb += b; ta += aft; tj += jk
print(f'{"ИТОГО":<16}{tb:>10}{ta:>8}{tj:>7}')

# контроль winding всех закрытых путей
bad = []
for i, a in enumerate(d['arenas']):
    col = a.get('collider') or {}
    op = set(col.get('open') or [])
    for j, p in enumerate(col.get('paths') or []):
        if j in op:
            continue
        if len(p) >= 3 and area(p) <= 0:
            bad.append((a['name'], j))
print('CW-пути (должно быть пусто):', bad)
