# -*- coding: utf-8 -*-
"""Собирает download/game.zip — весь проект игры без мусора:
без node_modules/.next/.git/skills/upload/download, логов и pid-файлов.
.env переписывается на переносимый относительный путь к sqlite (от папки prisma/)."""
import os
import zipfile

ROOT = '/home/z/my-project'
OUT = os.path.join(ROOT, 'download', 'game.zip')

SKIP_DIRS = {'node_modules', '.next', '.git', 'skills', 'upload', 'download'}
SKIP_FILES = {'.DS_Store', 'dev.pid'}
SKIP_EXT = {'.log'}

README = """Игра (Next.js + TypeScript + Tailwind) — как запустить

1. Установи зависимости: bun install (или npm install)
2. Запуск в режиме разработки: bun run dev (или npm run dev) -> http://localhost:3000
3. Прод-сборка: bun run build, затем bun run start

База данных: prisma/sqlite, файл db/custom.db. .env уже настроен на
относительный путь (file:../db/custom.db — резолвится от папки prisma/).

Данные игры:
- public/game_data.json — рабочая копия, которую читает игра;
- game-assets/ — исходные ассеты (спрайты, шрифты, game_data.json);
- repo-src/ — исходники Unity-проекта (C#-скрипты, сцены, префабы).

Инструмент подбора позиции головы машины: страница /head_picker.html на
запущенном сервере. Его же файл public/head_picker.html можно открыть и
отдельно — тогда перетащи в него game_data.json и сохрани через скачивание.

Скрипты ассетов и резервные копии game_data.json лежат в scripts/.
"""

def is_junk(name):
    return name in SKIP_FILES or name.lower().endswith('.log') or name == '.DS_Store'

count = 0
total = 0
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    z.writestr('README.txt', README)
    count += 1
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            if is_junk(fn):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, ROOT)
            if rel == os.path.join('download', 'game.zip'):
                continue
            if rel == '.env':
                # переносимый путь вместо сандбокс-абсолютного
                src = open(full, encoding='utf-8').read()
                src = src.replace('file:/home/z/my-project/db/custom.db', 'file:../db/custom.db')
                z.writestr(rel, src)
            else:
                z.write(full, rel)
            count += 1
            total += os.path.getsize(full)

size = os.path.getsize(OUT)
print('OK:', OUT)
print('files:', count, '| uncompressed: %.1f MB' % (total / 1e6), '| zip: %.1f MB' % (size / 1e6))
