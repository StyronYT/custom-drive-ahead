#!/usr/bin/env python3
"""Extract complete game data from scene: arenas with collider points, camera, UI."""
import json, sys
sys.path.insert(0, "/home/z/my-project/scripts")
from parse_unity import load_docs, vec2

docs = load_docs("/home/z/my-project/repo-src/SampleScene.unity")
gameobjects, transforms, comps = {}, {}, {}
for d in docs:
    c = d["_class"]
    if c == 1:
        gameobjects[d["_id"]] = {"name": d.get("m_Name"), "layer": d.get("m_Layer"), "active": d.get("m_IsActive"),
                                 "components": [list(cc.values())[0].get("fileID") if isinstance(list(cc.values())[0], dict) else list(cc.values())[0] for cc in d.get("m_Component", [])]}
    elif c == 4:
        transforms[d["_id"]] = {"pos": vec2(d.get("m_LocalPosition")) if isinstance(d.get("m_LocalPosition"), dict) else [0, 0],
                                "rotZ": (d.get("m_LocalRotation") or {}).get("z", 0) if isinstance(d.get("m_LocalRotation"), dict) else 0,
                                "rotW": (d.get("m_LocalRotation") or {}).get("w", 1) if isinstance(d.get("m_LocalRotation"), dict) else 1,
                                "scale": vec2(d.get("m_LocalScale")) if isinstance(d.get("m_LocalScale"), dict) else [1, 1],
                                "father": (d.get("m_Father") or {}).get("fileID") or 0,
                                "go": d.get("m_GameObject", {}).get("fileID")}
        comps[d["_id"]] = d
    else:
        comps[d["_id"]] = d

children = {}
for tid, t in transforms.items():
    if t["father"]:
        children.setdefault(t["father"], []).append(tid)

def comp_of(go_id, cls):
    if not go_id: return None
    for cid in gameobjects.get(go_id, {}).get("components", []):
        d = comps.get(cid)
        if d and d["_class"] == cls:
            return d
    return None

SCRIPTS = {"40151d1587914ddfbdb70b701ee4d02d": "Arena"}

def sprite_info(go_id):
    spr = comp_of(go_id, 212)
    if not spr: return None
    s = spr.get("m_Sprite") or {}
    return {"guid": s.get("guid"), "fileID": s.get("fileID"), "flipX": spr.get("m_FlipX"),
            "order": spr.get("m_SortingOrder"), "size": vec2(spr.get("m_Size"))}

def collider_info(go_id):
    p = comp_of(go_id, 60)
    if p:
        paths = []
        for path in (p.get("m_Points") or {}).get("m_Paths") or []:
            paths.append([vec2(v) for v in path])
        return {"type": "poly", "paths": paths}
    b = comp_of(go_id, 61)
    if b:
        return {"type": "box", "offset": vec2(b.get("m_Offset")), "size": vec2(b.get("m_Size"))}
    c = comp_of(go_id, 58)
    if c:
        return {"type": "circle", "offset": vec2(c.get("m_Offset")), "radius": c.get("m_Radius")}
    e = comp_of(go_id, 65)
    if e:
        pts = [vec2(v) for v in (e.get("m_Points") or {}).get("m_Path") or []]
        return {"type": "edge", "points": pts}
    return None

def mb_scripts(go_id):
    out = []
    for cid in gameobjects.get(go_id, {}).get("components", []):
        d = comps.get(cid)
        if d and d["_class"] == 114:
            out.append((d.get("m_Script") or {}).get("guid"))
    return out

def build_tree(tid):
    t = transforms[tid]
    go = t["go"]
    node = {"name": gameobjects.get(go, {}).get("name") if go else None,
            "layer": gameobjects.get(go, {}).get("layer") if go else None,
            "active": gameobjects.get(go, {}).get("active") if go else None,
            "pos": t["pos"], "rotZ": t["rotZ"], "rotW": t["rotW"], "scale": t["scale"],
            "sprite": sprite_info(go), "collider": collider_info(go), "scripts": mb_scripts(go)}
    node["children"] = [build_tree(ct) for ct in children.get(tid, []) if transforms[ct]["go"] is not None]
    return node

roots = [tid for tid, t in transforms.items() if not t["father"]]
data = [build_tree(r) for r in roots]

# cameras
cams = []
for cid, d in comps.items():
    if d["_class"] == 20:
        cams.append({"go": gameobjects.get((d.get("m_GameObject") or {}).get("fileID"), {}).get("name"),
                     "orthographic": d.get("m_orthographic"), "size": d.get("orthographic size"),
                     "orthoSize": d.get("m_OrthographicSize"), "bg": d.get("m_BackGroundColor"),
                     "depth": d.get("m_Depth")})
# Unity YAML uses "orthographic size" key? print raw keys of one camera
for cid, d in comps.items():
    if d["_class"] == 20:
        print("CAMERA keys:", [k for k in d.keys() if not k.startswith("_")])
        break

json.dump(data, open("/home/z/my-project/repo-src/parsed/scene.json", "w"), indent=1)
print("saved scene.json, roots:", [n["name"] for n in data])
