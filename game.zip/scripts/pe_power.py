#!/usr/bin/env python3
"""Planetary Explorer: усиление мощности.
speed (сила тяги двигателя в Car.fixedUpdate: dv = speed*0.05*dt) 25 -> 40.
maxSpeed 50 не трогаем (по требованиям), rotationSpeed не трогаем.
Правит обе копии: public/game_data.json (её читает игра) и game-assets/game_data.json."""
import json, copy

NEW_SPEED = 40
PATHS = ['public/game_data.json', 'game-assets/game_data.json']

for p in PATHS:
    with open(p, 'r', encoding='utf-8') as f:
        d = json.load(f)
    changed = []
    for key in ('BluePlanetaryExplorer', 'RedPlanetaryExplorer'):
        cd = d['cars'].get(key)
        if cd is None:
            print(f'{p}: {key} ОТСУТСТВУЕТ')
            continue
        old = copy.deepcopy(cd['carData'])
        cd['carData']['speed'] = NEW_SPEED
        changed.append((key, old, cd['carData']))
    with open(p, 'w', encoding='utf-8') as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    for key, old, new in changed:
        print(f'{p}: {key}: {old} -> {new}')
print('done')
