#!/usr/bin/env python3
"""Copy only the sprites used by game_data.json + UI sprites to public/."""
import json, shutil, os

GA = "/home/z/my-project/game-assets"
PUB = "/home/z/my-project/public/sprites"
os.makedirs(PUB, exist_ok=True)

data = json.load(open(f"{GA}/game_data.json"))
used = set()

def collect_sprite(s):
    if s and "/" in s:
        used.add(s)

for cname, c in data["cars"].items():
    def walk(n):
        collect_sprite(n.get("sprite"))
        for k in n.get("children", []): walk(k)
    walk(c["tree"])

for a in data["arenas"]:
    collect_sprite(a.get("sprite"))
    for ch in a.get("children", []):
        collect_sprite(ch.get("sprite"))
        for k in ch.get("children", []):
            collect_sprite(k.get("sprite"))

# UI + backgrounds + effects
used.update([
    "Img (1)/Img (1)_8",   # blue star
    "Img (1)/Img (1)_9",   # red star
    "Img (1)/Img (1)_2",   # empty star
    "SpinEffects/SpinEffects_0", "SpinEffects/SpinEffects_1",
    "Img (1)/Img (1)_41",  # People
    "Img (1)/Img (1)_49",  # PeopleBackground
])

manifest = json.load(open(f"{GA}/sprite_manifest.json"))
copied = []
for u in sorted(used):
    fn = u.replace("/", "__") + ".png"
    src = f"{GA}/sprites/{fn}"
    if os.path.exists(src):
        shutil.copy(src, f"{PUB}/{fn}")
        copied.append(fn)
    else:
        print("MISSING:", src)

shutil.copy(f"{GA}/game_data.json", "/home/z/my-project/public/game_data.json")
shutil.copy(f"{GA}/sprite_manifest.json", "/home/z/my-project/public/sprite_manifest.json")
os.makedirs("/home/z/my-project/public/fonts", exist_ok=True)
for f in ("barcade.ttf", "pressstart.ttf"):
    shutil.copy(f"{GA}/fonts/{f}", f"/home/z/my-project/public/fonts/{f}")

print(f"copied {len(copied)} sprites")
total = sum(os.path.getsize(f"{PUB}/{f}") for f in os.listdir(PUB))
print(f"total size: {total/1024:.0f} KB")
