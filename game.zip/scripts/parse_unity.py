#!/usr/bin/env python3
"""Parse Unity project files (prefabs, scene, metas) into structured JSON."""
import re, json, os, sys
from collections import defaultdict

SRC = "/home/z/my-project/repo-src"
OUT = "/home/z/my-project/repo-src/parsed"
os.makedirs(OUT, exist_ok=True)

import yaml

GUID_ATLAS = {
    "e2b04d599181ca5c2b162ea6ca69893b": "Arenas1",
    "e8f561d18a0655c4bbd56a3a1fcbe4b1": "Arenas2",
}

def load_docs(path):
    """Parse Unity YAML: split documents on --- !u!<class> &<id>"""
    text = open(path, encoding="utf-8", errors="replace").read()
    docs = []
    # split on document headers
    parts = re.split(r"^--- !u!(\d+) &(-?\d+)( stripped)?\s*$", text, flags=re.M)
    # parts: [pre, class, id, (stripped?), body, ...] → groups of 4
    for i in range(1, len(parts) - 3, 4):
        cls, oid = parts[i], parts[i+1]
        body = parts[i+3]
        try:
            data = yaml.safe_load(body)
        except Exception as e:
            print(f"YAML fail {path} doc {cls}&{oid}: {e}", file=sys.stderr)
            continue
        if data is None:
            continue
        cls_name = {k: v for k, v in data.items() if not k.startswith("_")}
        inner = next(iter(cls_name.values())) if cls_name else {}
        if isinstance(inner, dict):
            inner["_class"] = int(cls)
            inner["_id"] = int(oid)
            docs.append(inner)
        else:
            docs.append({"_class": int(cls), "_id": int(oid)})
    return docs

def parse_meta_sprites(path):
    """Parse a .png.meta file: return {fileID: {name, rect, pivot}} and guid."""
    text = open(path, encoding="utf-8", errors="replace").read()
    guid_m = re.search(r"^guid: ([0-9a-f]{32})", text, re.M)
    guid = guid_m.group(1) if guid_m else None
    # internalIDToNameTable
    id2name = {}
    m = re.search(r"internalIDToNameTable:\n((?:  - first:\n(?:    .*\n)+)+)", text)
    if m:
        for first, second in re.findall(r"first:\n\s+213: (-?\d+)\n\s+second: (.+)", m.group(1)):
            id2name[int(first)] = second.strip()
    # spriteSheet sprites
    sprites = {}
    sheet = re.search(r"  spriteSheet:\n(.*?)(?=  spriteIDToName|\Z)", text, re.S)
    body = sheet.group(1) if sheet else text
    # each sprite entry: 4-space dash, 6-space fields
    for m2 in re.finditer(r"^    - serializedVersion: 2\n      name: (.+?)\n((?:      (?!- serializedVersion).*\n)+)", body, re.M):
        name = m2.group(1).strip()
        blk = m2.group(2)
        rect = re.search(r"^      rect:\n        serializedVersion: 2\n        x: ([-\d.]+)\n        y: ([-\d.]+)\n        width: ([-\d.]+)\n        height: ([-\d.]+)", blk, re.M)
        pivot = re.search(r"^      pivot: \{x: ([-\d.]+), y: ([-\d.]+)\}", blk, re.M)
        internal = re.search(r"^      internalID: (-?\d+)", blk, re.M)
        pshape = re.search(r"^      physicsShape:\n((?:      - \[.*\n)+)", blk, re.M)
        ps = []
        if pshape:
            for pm in re.finditer(r"- \\?\[([^\]]*)\\?\]", pshape.group(1)):
                pts = []
                for pv in re.finditer(r"\{x: ([-\d.eE+]+), y: ([-\d.eE+]+)\}", pm.group(1)):
                    pts.append([float(pv.group(1)), float(pv.group(2))])
                if pts: ps.append(pts)
        if rect:
            sprites[name] = {
                "rect": [float(rect.group(1)), float(rect.group(2)), float(rect.group(3)), float(rect.group(4))],
                "pivot": [float(pivot.group(1)), float(pivot.group(2))] if pivot else [0.5, 0.5],
                "physicsShape": ps,
                "internalID": int(internal.group(1)) if internal else None,
            }
    # map internalID -> sprite name via id2name
    fid2sprite = {}
    for fid, name in id2name.items():
        if name in sprites:
            fid2sprite[fid] = name
    return guid, sprites, fid2sprite

def vec2(s):
    if not s: return [0.0, 0.0]
    return [float(s.get("x", 0)), float(s.get("y", 0))]

def parse_prefab_car(path):
    docs = load_docs(path)
    gameobjects = {}
    transforms = {}
    comps = defaultdict(list)
    for d in docs:
        c = d["_class"]
        if c == 1:  # GameObject
            gameobjects[d["_id"]] = {
                "name": d.get("m_Name"),
                "layer": d.get("m_Layer"),
                "components": [list(c.values())[0].get("fileID") if isinstance(list(c.values())[0], dict) else list(c.values())[0] for c in d.get("m_Component", [])],
            }
        elif c == 4:  # Transform
            transforms[d["_id"]] = {
                "pos": vec2(d.get("m_LocalPosition")),
                "rot": d.get("m_LocalRotation", {}).get("z", 0) if isinstance(d.get("m_LocalRotation"), dict) else 0,
                "scale": vec2(d.get("m_LocalScale")),
                "father": (d.get("m_Father") or {}).get("fileID") if d.get("m_Father") else None,
                "go": d.get("m_GameObject", {}).get("fileID"),
            }
        else:
            comps[d["_id"]] = d
    # gather per-GO component details
    def rigidbody(go_id):
        for cid in gameobjects[go_id]["components"]:
            d = comps.get(cid)
            if d and d["_class"] == 50:
                return {
                    "mass": d.get("m_Mass"), "gravityScale": d.get("m_GravityScale"),
                    "linearDamping": d.get("m_LinearDamping"), "angularDamping": d.get("m_AngularDamping"),
                    "mat_guid": (d.get("m_Material") or {}).get("guid"),
                }
        return None
    def circle(go_id):
        for cid in gameobjects[go_id]["components"]:
            d = comps.get(cid)
            if d and d["_class"] == 58:
                return {"radius": d.get("m_Radius"), "offset": vec2(d.get("m_Offset")),
                        "mat_guid": (d.get("m_Material") or {}).get("guid")}
        return None
    def poly(go_id):
        for cid in gameobjects[go_id]["components"]:
            d = comps.get(cid)
            if d and d["_class"] == 60:
                paths = []
                for p in (d.get("m_Points") or {}).get("m_Paths") or []:
                    paths.append([vec2(v) for v in p])
                return {"paths": paths, "offset": vec2(d.get("m_Offset"))}
        return None
    def sprite(go_id):
        for cid in gameobjects[go_id]["components"]:
            d = comps.get(cid)
            if d and d["_class"] == 212:
                sp = d.get("m_Sprite") or {}
                return {"guid": sp.get("guid"), "fileID": sp.get("fileID"),
                        "size": vec2(d.get("m_Size")), "flipX": d.get("m_FlipX"),
                        "sortOrder": d.get("m_SortingOrder")}
        return None
    def hinge(go_id):
        for cid in gameobjects[go_id]["components"]:
            d = comps.get(cid)
            if d and d["_class"] == 233:
                lim = (d.get("m_AngleLimits") or {})
                return {"connected": (d.get("m_ConnectedRigidBody") or {}).get("fileID"),
                        "anchor": vec2(d.get("m_Anchor")), "connectedAnchor": vec2(d.get("m_ConnectedAnchor")),
                        "limits": [lim.get("m_LowerAngle"), lim.get("m_UpperAngle")] if d.get("m_UseLimits") else None}
        return None
    def wheeljoint(go_id):
        js = []
        for cid in gameobjects[go_id]["components"]:
            d = comps.get(cid)
            if d and d["_class"] == 235:
                susp = d.get("m_Suspension") or {}
                js.append({
                    "connected": (d.get("m_ConnectedRigidBody") or {}).get("fileID"),
                    "anchor": vec2(d.get("m_Anchor")),
                    "suspension": {
                        "dampingRatio": susp.get("m_DampingRatio"),
                        "frequency": susp.get("m_Frequency"),
                        "angle": susp.get("m_Angle"),
                    }})
        return js
    # find root GO (transform without father)
    root_tf = next((t for t in transforms.values() if not t["father"]), None)
    # map rigidbody fileID -> GO
    rb2go = {}
    for cid, d in comps.items():
        if d["_class"] == 50:
            rb2go[cid] = (d.get("m_GameObject") or {}).get("fileID")
    # children by transform
    children = defaultdict(list)
    for tid, t in transforms.items():
        if t["father"]:
            children[t["father"]].append(tid)
    def build(go_id, tid):
        t = transforms[tid]
        node = {
            "name": gameobjects[go_id]["name"],
            "layer": gameobjects[go_id]["layer"],
            "pos": t["pos"], "scale": t["scale"], "rotZ": t["rot"],
            "rigidbody": rigidbody(go_id), "circle": circle(go_id),
            "poly": poly(go_id), "sprite": sprite(go_id),
            "hinge": hinge(go_id),
        }
        if node["hinge"] is None:
            node.pop("hinge")
        wj = wheeljoint(go_id)
        if wj: node["wheelJoints"] = wj
        kids = []
        for ctid in children.get(tid, []):
            cgoid = transforms[ctid]["go"]
            kids.append(build(cgoid, ctid))
        node["children"] = kids
        return node
    root = build(root_tf["go"], [tid for tid, t in transforms.items() if not t["father"]][0])
    return root

if __name__ == "__main__":
    # parse all metas
    atlas = {}
    for f in os.listdir(f"{SRC}/metas"):
        if not f.endswith(".png.meta"): continue
        guid, sprites, fid2sprite = parse_meta_sprites(f"{SRC}/metas/{f}")
        atlas[f.replace(".png.meta", "")] = {"guid": guid, "sprites": sprites, "fid2sprite": fid2sprite}
        print(f"{f}: {len(sprites)} sprites, {len(fid2sprite)} mapped")
    json.dump(atlas, open(f"{OUT}/atlas.json", "w"), indent=1)

    # parse car prefabs
    cars = {}
    for sub, color in (("prefabs_blue", "blue"), ("prefabs_red", "red")):
        for f in sorted(os.listdir(f"{SRC}/{sub}")):
            if not f.endswith(".prefab"): continue
            name = f.replace(".prefab", "")
            cars[name] = {"color": color, "tree": parse_prefab_car(f"{SRC}/{sub}/{f}")}
            print(f"parsed car {name}")
    json.dump(cars, open(f"{OUT}/cars.json", "w"), indent=1)
    print("DONE")
