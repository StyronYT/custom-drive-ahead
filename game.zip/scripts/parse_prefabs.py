#!/usr/bin/env python3
"""Parse Unity Drive Ahead project: prefabs, sprites, scene -> JSON for HTML port."""
import re, os, json, glob, math

ROOT = "/tmp/drive-ahead/Assets"
OUT = "/home/z/my-project/scripts/parsed"
os.makedirs(OUT, exist_ok=True)

# ---------- 1. GUID -> asset path ----------
guid_map = {}
for meta in glob.glob(f"{ROOT}/**/*.meta", recursive=True):
    txt = open(meta, encoding="utf-8", errors="ignore").read()
    m = re.search(r"guid: ([0-9a-f]{32})", txt)
    if m:
        guid_map[m.group(1)] = meta[:-5]

# ---------- 2. Sprite sheets: internalID -> rect ----------
def parse_spritesheet(png_path):
    meta = png_path + ".meta"
    txt = open(meta, encoding="utf-8", errors="ignore").read()
    sprites = {}
    for m in re.finditer(r"- serializedVersion: 2\n\s+name: (.+?)\n\s+rect:\n\s+serializedVersion: 2\n\s+x: (-?[\d.]+)\n\s+y: (-?[\d.]+)\n\s+width: ([\d.]+)\n\s+height: ([\d.]+)\n\s+alignment: (\d+)\n\s+pivot: \{x: ([\d.]+), y: ([\d.]+)\}(.*?)internalID: (-?\d+)", txt, re.S):
        name, x, y, w, h, align, px, py, rest, iid = m.groups()
        shapes = []
        for sm in re.finditer(r"physicsShape:\n((?:\s+- - \{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+)\}\n(?:\s+- \{x: -?[\d.eE+-]+, y: -?[\d.eE+-]+\}\n)*)+)", rest):
            pts = [[float(a), float(b)] for a, b in re.findall(r"\{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+)\}", sm.group(1))]
            if pts: shapes.append(pts)
        sprites[iid] = {"name": name.strip(), "x": float(x), "y": float(y), "w": float(w), "h": float(h), "pivot": [float(px), float(py)], "shapes": shapes}
    return sprites

sprite_sheets = {}
for png in glob.glob(f"{ROOT}/**/*.png", recursive=True):
    if png.endswith(".meta"): continue
    sheets = parse_spritesheet(png)
    if sheets:
        sprite_sheets[os.path.basename(png)] = sheets

# ---------- 3. Parse prefab/scene docs ----------
def parse_docs(path):
    txt = open(path, encoding="utf-8", errors="ignore").read()
    docs = {}
    for m in re.finditer(r"--- !u!(\d+) &(\d+)\n(.*?)(?=--- !u!|\Z)", txt, re.S):
        docs[m.group(2)] = {"cls": m.group(1), "body": m.group(3)}
    return docs

def get_float(body, key, default=None):
    m = re.search(rf"{key}: (-?[\d.eE+]+|Infinity)", body)
    if not m: return default
    v = m.group(1)
    return default if v == "Infinity" else float(v)

def get_vec(body, key):
    m = re.search(rf"{key}: \{{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+)(?:, z: (-?[\d.eE+-]+))?\}}", body)
    if not m: return None
    return [float(m.group(1)), float(m.group(2)), float(m.group(3)) if m.group(3) else 0.0]

def get_quat(body):
    m = re.search(r"m_LocalRotation: \{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+), z: (-?[\d.eE+-]+), w: (-?[\d.eE+-]+)\}", body)
    if not m: return 0.0
    x, y, z, w = [float(g) for g in m.groups()]
    return math.degrees(math.atan2(2*(w*z + x*y), 1 - 2*(z*z + x*x)))

def get_sprite_ref(body):
    m = re.search(r"m_Sprite: \{fileID: (-?\d+), guid: ([0-9a-f]{32})", body)
    return {"fileID": m.group(1), "guid": m.group(2)} if m else None

def sprite_info(ref):
    if not ref: return None
    path = guid_map.get(ref["guid"])
    if not path: return None
    base = os.path.basename(path)
    spr = sprite_sheets.get(base, {}).get(ref["fileID"])
    return {"sheet": base, **spr} if spr else None

def mat_name(body):
    m = re.search(r"m_Material: \{fileID: \d+, guid: ([0-9a-f]{32})", body)
    if m and guid_map.get(m.group(1)):
        return os.path.basename(guid_map[m.group(1)]).replace(".physicsMaterial2D", "")
    return None

def get_rigidbody(body):
    if get_float(body, "m_BodyType") is None: return None
    return {
        "mass": get_float(body, "m_Mass", 1),
        "linearDamping": get_float(body, "m_LinearDamping", 0),
        "angularDamping": get_float(body, "m_AngularDamping", 0.05),
        "gravityScale": get_float(body, "m_GravityScale", 1),
        "fixedRotation": get_float(body, "m_FreezeRotation", 0) == 1,
        "material": mat_name(body),
        "selfBody": re.search(r"m_GameObject: \{fileID: (\d+)\}", body).group(1),
    }

def get_collider(body, cls):
    col = {"material": mat_name(body), "isTrigger": get_float(body, "m_IsTrigger", 0) == 1,
           "offset": (get_vec(body, "m_Offset") or [0, 0])[:2],
           "selfBody": re.search(r"m_GameObject: \{fileID: (\d+)\}", body).group(1)}
    if cls == "58":
        col["type"] = "circle"; col["radius"] = get_float(body, "m_Radius", 0.1)
    elif cls == "61":
        col["type"] = "box"; col["size"] = (get_vec(body, "m_Size") or [1, 1])[:2]
    elif cls == "60":
        verts = []
        m_paths = re.search(r"m_Points:\s*\n\s*m_Paths:\s*\n(.*?)(?=\n  \w|\Z)", body, re.S)
        if m_paths:
            cur = None
            for line in m_paths.group(1).splitlines():
                s = line.strip()
                pm = re.match(r"- - \{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+)\}", s)
                cm = re.match(r"- \{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+)\}", s)
                if pm:
                    if cur: verts.append(cur)
                    cur = [[float(pm.group(1)), float(pm.group(2))]]
                elif cm and cur is not None:
                    cur.append([float(cm.group(1)), float(cm.group(2))])
            if cur: verts.append(cur)
        col["type"] = "polygon"; col["polygons"] = verts
    return col

def get_joint(body, cls):
    j = {}
    con = re.search(r"m_ConnectedRigidBody: \{fileID: (\d+)\}", body)
    j["connectedBody"] = con.group(1) if con and con.group(1) != "0" else None
    j["anchor"] = (get_vec(body, "m_Anchor") or [0, 0])[:2]
    ca = get_vec(body, "m_ConnectedAnchor")
    j["connectedAnchor"] = (ca[:2] if ca else [0, 0])
    j["enableCollision"] = get_float(body, "m_EnableCollision", 0) == 1
    j["selfBody"] = re.search(r"m_GameObject: \{fileID: (\d+)\}", body).group(1)
    if cls == "235":
        j["type"] = "wheel"
        j["dampingRatio"] = get_float(body, "m_DampingRatio", 0)
        j["frequency"] = get_float(body, "m_Frequency", 0)
        ax = re.search(r"m_Axis: \{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+)", body)
        j["axis"] = [float(ax.group(1)), float(ax.group(2))] if ax else [0, 1]
    elif cls == "233":
        j["type"] = "hinge"
        j["useLimits"] = get_float(body, "m_UseLimits", 0) == 1
        lo = re.search(r"m_LowerAngle: (-?[\d.]+)", body)
        hi = re.search(r"m_UpperAngle: (-?[\d.]+)", body)
        j["limits"] = [float(lo.group(1)), float(hi.group(1))] if lo and hi else [-360, 360]
    return j

def parse_transforms(docs):
    transforms = {}
    for fid, d in docs.items():
        if d["cls"] == "4" or d["cls"] == "224":
            b = d["body"]
            children = []
            ch = re.search(r"m_Children:(.*?)m_Father:", b, re.S)
            if ch:
                children = re.findall(r"fileID: (\d+)\}", ch.group(1))
            father = re.search(r"m_Father: \{fileID: (\d+)\}", b)
            transforms[fid] = {
                "pos": (get_vec(b, "m_LocalPosition") or [0, 0, 0]),
                "rot": get_quat(b),
                "scale": (get_vec(b, "m_LocalScale") or [1, 1, 1])[:2],
                "father": father.group(1) if father and father.group(1) != "0" else None,
                "children": children,
                "rect": d["cls"] == "224",
            }
    return transforms

def parse_gameobjects(docs, transforms):
    gos = {}
    transform_to_go = {}
    for fid, d in docs.items():
        if d["cls"] != "1": continue
        b = d["body"]
        nm = re.search(r"m_Name: (.+)", b)
        go = {"name": nm.group(1) if nm else "?", "active": get_float(b, "m_IsActive", 1) == 1, "components": [], "children": []}
        comps = re.findall(r"  - component: \{fileID: (\d+)\}", b)
        for cid in comps:
            if docs.get(cid, {}).get("cls") in ("4", "224"):
                transform_to_go[cid] = fid
        for cid in comps:
            cd = docs.get(cid)
            if not cd: continue
            cb = cd["body"]
            c = None
            if cd["cls"] in ("4", "224"):
                tr = transforms.get(cid, {})
                c = {"kind": "transform", "pos": tr.get("pos", [0,0,0]), "rot": tr.get("rot", 0), "scale": tr.get("scale", [1,1])}
            elif cd["cls"] == "212":
                cm = re.search(r"m_Color: \{r: ([\d.]+), g: ([\d.]+), b: ([\d.]+), a: ([\d.]+)\}", cb)
                sr = get_sprite_ref(cb)
                spr = sprite_info(sr) if sr else None
                # fallback: look up by name from spriteSheet guid
                if not spr:
                    sm = re.search(r"m_Sprite: \{fileID: (-?\d+), guid: ([0-9a-f]{32}), type: 3\}", cb)
                    if sm:
                        path = guid_map.get(sm.group(2))
                        if path:
                            sheet = sprite_sheets.get(os.path.basename(path), {})
                            # try by index in sheet order
                            try:
                                keys = list(sheet.keys())
                                spr = {"sheet": os.path.basename(path), **sheet[keys[0]]}
                            except Exception:
                                spr = None
                c = {"kind": "sprite", "sprite": spr,
                     "order": get_float(cb, "m_SortingOrder", 0),
                     "color": [float(g) for g in cm.groups()] if cm else [1,1,1,1],
                     "flipX": "m_FlipX: 1" in cb}
            elif cd["cls"] == "50":
                rb = get_rigidbody(cb)
                if rb: c = {"kind": "rigidbody", **rb}
            elif cd["cls"] in ("58", "61", "60"):
                c = {"kind": "collider", **get_collider(cb, cd["cls"])}
            elif cd["cls"] in ("233", "235"):
                c = {"kind": "joint", **get_joint(cb, cd["cls"])}
            elif cd["cls"] == "114":
                sr = re.search(r"m_Script: \{fileID: \d+, guid: ([0-9a-f]{32})", cb)
                c = {"kind": "script", "script": os.path.basename(guid_map.get(sr.group(1), "?")).replace(".cs", "") if sr and guid_map.get(sr.group(1)) else "HeadCollision"}
            if c: go["components"].append(c)
        gos[fid] = go
    for fid, tr in transforms.items():
        if tr["father"] and fid in transform_to_go:
            father_go = transform_to_go[tr["father"]]
            child_go = transform_to_go.get(fid)
            if father_go in gos and child_go in gos:
                gos[father_go]["children"].append(child_go)
    return gos, transform_to_go

def flatten(go_map, root_fid, parent_pos=(0,0,0), parent_rot=0.0, parent_scale=(1,1)):
    go = go_map[root_fid]
    comp = next((c for c in go["components"] if c["kind"] == "transform"), None)
    lp = comp["pos"] if comp else [0,0,0]
    lr = comp["rot"] if comp else 0.0
    ls = comp["scale"] if comp else [1,1]
    r = math.radians(parent_rot)
    wx = parent_pos[0] + lp[0]*math.cos(r)*parent_scale[0] - lp[1]*math.sin(r)*parent_scale[1]
    wy = parent_pos[1] + lp[0]*math.sin(r)*parent_scale[0] + lp[1]*math.cos(r)*parent_scale[1]
    wr = parent_rot + lr
    wsc = [parent_scale[0]*ls[0], parent_scale[1]*ls[1]]
    entry = {"name": go["name"], "active": go["active"], "pos": [round(wx,5), round(wy,5)], "rot": round(wr,4),
             "scale": wsc,
             "components": [c for c in go["components"] if c["kind"] != "transform"], "children": []}
    for ch in go["children"]:
        if ch in go_map:
            entry["children"].append(flatten(go_map, ch, (wx, wy), wr, wsc))
    return entry

def find_root(docs, transforms):
    for fid, d in docs.items():
        if d["cls"] != "1": continue
        comps = re.findall(r"  - component: \{fileID: (\d+)\}", d["body"])
        for cid in comps:
            if cid in transforms and transforms[cid]["father"] is None:
                return fid
    return None

# ---------- 4. Cars ----------
cars = {}
for pf in sorted(glob.glob(f"{ROOT}/Drive Ahead/Prefabs/Cars/*/*.prefab")):
    docs = parse_docs(pf)
    transforms = parse_transforms(docs)
    go_map, _t2g = parse_gameobjects(docs, transforms)
    rf = find_root(docs, transforms)
    if not rf:
        print("NO ROOT", pf); continue
    cars[os.path.basename(pf).replace(".prefab", "")] = flatten(go_map, rf)
json.dump(cars, open(f"{OUT}/cars.json", "w"), indent=1)
print("CARS:", list(cars.keys()))

# ---------- 5. Arenas ----------
arenas = {}
for pf in sorted(glob.glob(f"{ROOT}/Drive Ahead/Prefabs/Maps/*.prefab")):
    docs = parse_docs(pf)
    transforms = parse_transforms(docs)
    go_map, _t2g = parse_gameobjects(docs, transforms)
    rf = find_root(docs, transforms)
    if not rf:
        print("NO ROOT ARENA", pf); continue
    arenas[os.path.basename(pf).replace(".prefab", "")] = flatten(go_map, rf)
json.dump(arenas, open(f"{OUT}/arenas.json", "w"), indent=1)
print("ARENAS:", list(arenas.keys()))

# ---------- 6. Scene ----------
docs = parse_docs(f"{ROOT}/Drive Ahead/Scenes/SampleScene.unity")
transforms = parse_transforms(docs)
go_map, transform_to_go = parse_gameobjects(docs, transforms)
scene_tree = []
for fid, tr in transforms.items():
    if tr["father"] is None and fid in transform_to_go and transform_to_go[fid] in go_map:
        scene_tree.append(flatten(go_map, transform_to_go[fid]))
json.dump(scene_tree, open(f"{OUT}/scene.json", "w"), indent=1)
print("SCENE top-level:", [t["name"] for t in scene_tree])

# ---------- 7. Sprite sheets dump ----------
json.dump({k: v for k, v in sprite_sheets.items()}, open(f"{OUT}/sprites.json", "w"), indent=1)
total = sum(len(v) for v in sprite_sheets.values())
print("SPRITES:", total, "in", len(sprite_sheets), "sheets")
print("OK")
