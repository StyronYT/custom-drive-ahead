#!/usr/bin/env python3
"""Визуализация коллайдеров поверх спрайтов арен — точно как в игре рисует page.tsx."""
import json, math, os
from PIL import Image, ImageDraw, ImageFont

BASE = '/home/z/my-project'
data = json.load(open(f'{BASE}/public/game_data.json'))
manifest = json.load(open(f'{BASE}/public/sprite_manifest.json'))
imgs = {}
for f in os.listdir(f'{BASE}/public/sprites'):
    if f.endswith('.png'):
        imgs[f] = Image.open(f'{BASE}/public/sprites/{f}').convert('RGBA')

ORTHO = 2.5714285
ASPECT = 16 / 9  # как канвас в игре
PANEL_W = 900    # px панели (ширина)
PANEL_H = int(PANEL_W / ASPECT)
s = PANEL_W / (2 * ORTHO * ASPECT)
cx = PANEL_W / 2
cy = PANEL_H / 2

def w2s(x, y):
    return (cx + x * s, cy - y * s)

def rot(p, ang):
    return (p[0] * math.cos(ang) - p[1] * math.sin(ang), p[0] * math.sin(ang) + p[1] * math.cos(ang))

def draw_arena(a):
    """Один кадр арены как в игре: спрайт(ы) + коллайдер-цепи + пила + спавны."""
    im = Image.new('RGBA', (PANEL_W, PANEL_H), (24, 24, 30, 255))
    d = ImageDraw.Draw(im)
    aAngle = 2 * math.atan2(a['rotZ'], a.get('rotW', math.sqrt(max(0.0, 1 - a['rotZ'] ** 2)))) if a.get('rotW') is not None else 2 * math.asin(min(1, a['rotZ']))

    def draw_sprite(sprite, pos, ang, scale, flip=False):
        f = sprite.replace('/', '__') + '.png'
        img = imgs[f]
        key = sprite
        m = manifest.get(key) or {}
        ppu = m.get('ppu', 48)
        w = (img.width / ppu) * (scale[0] if scale else 1) * s
        h = (img.height / ppu) * (scale[1] if scale else 1) * s
        img2 = img.transpose(Image.FLIP_LEFT_RIGHT) if flip else img
        # в игре canvas rotate(-ang) при y-down = CCW визуально; PIL rotate(+deg) тоже CCW
        img2 = img2.rotate(ang * 180 / math.pi, expand=True, resample=Image.NEAREST)
        sx, sy = w2s(*pos)
        im.alpha_composite(img2.resize((max(1, int(w)), max(1, int(h))), Image.NEAREST), (int(sx - w / 2), int(sy - h / 2)))

    draw_sprite(a['sprite'], a['pos'], aAngle, a.get('scale'))
    for chn in a.get('children') or []:
        w = rot(chn['pos'], aAngle)
        wp = (a['pos'][0] + w[0] * (a['scale'][0] if a.get('scale') else 1), a['pos'][1] + w[1] * (a['scale'][1] if a.get('scale') else 1))
        is_saw = chn.get('collider', {}) and chn.get('collider', {}).get('type') == 'circle' and 'Img (1)_0' in chn.get('name', '')
        if chn.get('sprite') and not is_saw:
            cang = aAngle + (2 * math.asin(min(1, chn['rotZ'])) if chn.get('rotZ') else 0)
            draw_sprite(chn['sprite'], wp, cang, [(chn.get('scale', [1, 1])[0]) * (a['scale'][0] if a.get('scale') else 1), (chn.get('scale', [1, 1])[1]) * (a['scale'][1] if a.get('scale') else 1)], chn.get('flipX', False))
        elif is_saw:
            r = (chn.get('collider') or {}).get('radius', 0.65) * s
            sx, sy = w2s(*wp)
            d.ellipse([sx - r, sy - r, sx + r, sy + r], outline=(255, 230, 0, 255), width=2)

    # коллайдер-цепи: локальные точки → поворот aAngle → + arena.pos (loop=true в игре)
    col = a.get('collider') or {}
    for pi, path in enumerate(col.get('paths') or []):
        pts = []
        for p in path:
            w = rot(p, aAngle)
            pts.append(w2s(a['pos'][0] + w[0], a['pos'][1] + w[1]))
        pts_c = pts + [pts[0]]
        d.line(pts_c, fill=(255, 40, 40, 255), width=2)
        for q in pts:
            d.ellipse([q[0] - 2, q[1] - 2, q[0] + 2, q[1] + 2], fill=(255, 200, 40, 255))

    # спавны
    for name, colr in (('BlueSpawn', (60, 130, 255)), ('RedSpawn', (255, 70, 60))):
        sp = (a.get('spawns') or {}).get(name)
        if sp:
            w = rot(sp, aAngle)
            q = w2s(a['pos'][0] + w[0], a['pos'][1] + w[1])
            d.ellipse([q[0] - 9, q[1] - 9, q[0] + 9, q[1] + 9], outline=colr, width=3)
    d.text((8, 6), f"#{a['_idx']} {a['name']} rot={a['rotZ']:.2f}", fill=(255, 255, 255, 255))
    return im

os.makedirs('/tmp/mapview', exist_ok=True)
sheets = []
panels = []
for i, a in enumerate(data['arenas']):
    a['_idx'] = i
    panels.append(draw_arena(a))
for si in range(0, len(panels), 2):
    grp = panels[si:si + 2]
    W = PANEL_W
    H = 2 * PANEL_H
    sheet = Image.new('RGBA', (W, H), (0, 0, 0, 255))
    for k, p in enumerate(grp):
        sheet.alpha_composite(p, (0, k * PANEL_H))
    sheet.convert('RGB').save(f'/tmp/mapview/sheet{si // 2}.png')
    sheets.append(f'/tmp/mapview/sheet{si // 2}.png')
print('saved', len(panels), 'panels ->', sheets)
# подсказка: какие панели на каком листе
for si in range(0, len(data['arenas']), 2):
    print(f'sheet{si // 2}:', [(i, data['arenas'][i]['name']) for i in range(si, min(si + 2, len(data['arenas'])))])
