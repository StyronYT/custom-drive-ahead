#!/usr/bin/env python3
"""Match prefab polygon colliders to sprite physicsShapes to learn (name, fileID) pairs."""
import re, glob, os, json

ROOT = "/tmp/drive-ahead/Assets"
PPU = 48

def parse_sheet_meta(png):
    meta = open(png + ".meta", encoding="utf-8", errors="ignore").read()
    sprites = []
    # each entry: - serializedVersion: 2\n      name: X ... rect ... pivot ... physicsShape: [ [pts...] ]
    for m in re.finditer(r"- serializedVersion: 2\n\s+name: (.+?)\n\s+rect:\n\s+serializedVersion: 2\n\s+x: (-?[\d.]+)\n\s+y: (-?[\d.]+)\n\s+width: ([\d.]+)\n\s+height: ([\d.]+)\n\s+alignment: (\d+)\n\s+pivot: \{x: ([\d.]+), y: ([\d.]+)\}(.*?)edges:", meta, re.S):
        name, x, y, w, h, align, px, py, rest = m.groups()
        x, y, w, h = float(x), float(y), float(w), float(h)
        px, py = float(px), float(py)
        shapes = []
        # physicsShape is list of point-lists: "- - {x: .., y: ..}\n        - {x: ..}"
        for sm in re.finditer(r"physicsShape:\n((?:\s+- - \{x: (-?[\d.]+), y: (-?[\d.]+)\}\n(?:\s+- \{x: (-?[\d.]+), y: (-?[\d.]+)\}\n)*)+)", rest):
            block = sm.group(1)
            pts = [[float(a), float(b)] for a, b in re.findall(r"\{x: (-?[\d.]+), y: (-?[\d.]+)\}", block)]
            if pts:
                shapes.append(pts)
        sprites.append({"name": name.strip(), "rect": [x, y, w, h], "pivot": [px, py], "shapes": shapes})
    return sprites

sheet = parse_sheet_meta(f"{ROOT}/Drive Ahead/Sprites/CarParts.png")
print("parsed sprites:", len(sheet))

def meta_to_units(spr, pts):
    """Meta physicsShape pts (pixel, y-down, from rect origin) -> center-relative y-up units."""
    rx, ry, rw, rh = spr["rect"]
    px, py = spr["pivot"]
    cx = rx + rw * px
    cy = ry + rh * py
    return [[round((p[0] - cx) / PPU, 5), round((cy - p[1]) / PPU, 5)] for p in pts]

def bbox(pts):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)

# ---- get polygon colliders from a prefab ----
def prefab_polys(path):
    txt = open(path, encoding="utf-8", errors="ignore").read()
    polys = []
    for m in re.finditer(r"--- !u!60 &(\d+)\n(.*?)(?=--- !u!|\Z)", txt, re.S):
        body = m.group(2)
        block = re.search(r"m_Points:\s*\n\s*m_Paths:\s*\n((?:\s*- - \{x: -?[\d.]+, y: -?[\d.]+\}\s*\n(?:\s*- \{x: -?[\d.]+, y: -?[\d.]+\}\s*\n)*)+)", body)
        if not block: continue
        for pm in re.finditer(r"- - \{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+)\}\s*\n((?:\s*- \{x: -?[\d.eE+-]+, y: -?[\d.eE+-]+\}\s*\n)*)", block.group(1)):
            pts = [[float(pm.group(1)), float(pm.group(2))]]
            for a, b in re.findall(r"\{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+)\}", pm.group(3)):
                pts.append([float(a), float(b)])
            if len(pts) >= 3:
                polys.append(pts)
    return polys

# match each prefab's polygons to sprite shapes
for pf in sorted(glob.glob(f"{ROOT}/Drive Ahead/Prefabs/Cars/*/*.prefab")):
    name = os.path.basename(pf)
    polys = prefab_polys(pf)
    matches = []
    for poly in polys:
        pb = bbox(poly)
        pw, ph = pb[2]-pb[0], pb[3]-pb[1]
        best = None
        for spr in sheet:
            for shape in spr["shapes"]:
                up = meta_to_units(spr, shape)
                sb = bbox(up)
                sw, sh = sb[2]-sb[0], sb[3]-sb[1]
                if abs(sw-pw) < 0.02 and abs(sh-ph) < 0.02 and len(up) == len(poly):
                    # compare vertex sets
                    norm_poly = sorted([(round(p[0]-pb[0],3), round(p[1]-pb[1],3)) for p in poly])
                    norm_shape = sorted([(round(p[0]-sb[0],3), round(p[1]-sb[1],3)) for p in up])
                    if norm_poly == norm_shape:
                        best = spr["name"]; break
            if best: break
        matches.append(best)
    print(f"{name}: {[(len(p), m) for p, m in zip(polys, matches)]}")
