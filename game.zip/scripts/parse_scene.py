#!/usr/bin/env python3
"""Analyze SampleScene.unity: hierarchy, sprites, colliders, Arena objects."""
import json, re, sys
sys.path.insert(0, "/home/z/my-project/scripts")
from parse_unity import load_docs, vec2

docs = load_docs("/home/z/my-project/repo-src/SampleScene.unity")
gameobjects, transforms, comps = {}, {}, {}
for d in docs:
    c = d["_class"]
    if c == 1:
        gameobjects[d["_id"]] = {"name": d.get("m_Name"), "layer": d.get("m_Layer"), "active": d.get("m_IsActive"),
                                 "components": [list(cc.values())[0].get("fileID") if isinstance(list(cc.values())[0], dict) else list(cc.values())[0] for cc in d.get("m_Component", [])]}
    elif c == 4:
        transforms[d["_id"]] = {"pos": vec2(d.get("m_LocalPosition")) if isinstance(d.get("m_LocalPosition"), dict) else [0,0],
                                "rotZ": (d.get("m_LocalRotation") or {}).get("z", 0) if isinstance(d.get("m_LocalRotation"), dict) else 0,
                                "rotW": (d.get("m_LocalRotation") or {}).get("w", 1) if isinstance(d.get("m_LocalRotation"), dict) else 1,
                                "scale": vec2(d.get("m_LocalScale")) if isinstance(d.get("m_LocalScale"), dict) else [1,1],
                                "father": (d.get("m_Father") or {}).get("fileID") or 0,
                                "go": d.get("m_GameObject", {}).get("fileID")}
        comps[d["_id"]] = d
    else:
        comps[d["_id"]] = d

SCRIPTS = {
    "40151d1587914ddfbdb70b701ee4d02d": "Arena",
    "94462af0f53d7b14985c09a9ed22843b": "BattleSetupManager",
    "2d390fb638d6e1c4c8201fdd965076c6": "GameManager",
    "4459ce737c2d63d3fba6a4e6ec0f59a2": "CarController",
    "2869f0ac65e6225d3b9386eeb0f6d7de": "HeadCollision",
    "e8862be4209a413698647bd33690509f": "UIManager",
    "14cb04611e1cf4041b5cc8fd8d119432": "StarsViewer",
}

# find MonoBehaviours
children = {}
for tid, t in transforms.items():
    if t["father"]:
        children.setdefault(t["father"], []).append(tid)

def go_of(tid): return transforms[tid]["go"]
def name_of(go_id): return gameobjects.get(go_id, {}).get("name") if go_id else None
def comp_of(go_id, cls):
    if not go_id: return None
    for cid in gameobjects[go_id]["components"]:
        d = comps.get(cid)
        if d and d["_class"] == cls:
            return d
    return None

# MonoBehaviours by script guid
mb_script = {}
for cid, d in comps.items():
    if d["_class"] == 114:
        g = (d.get("m_Script") or {}).get("guid")
        mb_script[cid] = SCRIPTS.get(g, g)

# arenas: GOs with Arena script component
arena_gos = []
for cid, sname in mb_script.items():
    if sname == "Arena":
        d = comps[cid]
        go_id = (d.get("m_GameObject") or {}).get("fileID")
        arena_gos.append(go_id)

print("Arena GOs:", [(g, name_of(g), gameobjects[g]["active"]) for g in arena_gos])

def dump_tree(tid, depth=0, max_depth=3):
    t = transforms[tid]
    go = t["go"]
    if go is None:
        return
    ind = "  " * depth
    spr = comp_of(go, 212)
    sinfo = ""
    if spr:
        s = spr.get("m_Sprite") or {}
        sinfo = f" spr={s.get('guid','')[:8]}/{s.get('fileID')} flip={spr.get('m_FlipX')} order={spr.get('m_SortingOrder')}"
    col = comp_of(go, 60) or comp_of(go, 58) or comp_of(go, 61) or comp_of(go, 65)
    cinfo = ""
    if col:
        cc = col["_class"]
        cinfo = f" col={'poly' if cc==60 else 'circle' if cc==58 else 'box' if cc==61 else 'edge' if cc==65 else cc}"
    mb = ""
    for cid in gameobjects[go]["components"]:
        d = comps.get(cid)
        if d and d["_class"] == 114:
            mb += f" MB:{mb_script.get(cid)}"
    print(f"{ind}{name_of(go)} [layer {gameobjects[go]['layer']}] pos=({t['pos'][0]:.2f},{t['pos'][1]:.2f}) rotZ={t['rotZ']:.3f} scale=({t['scale'][0]},{t['scale'][1]}){sinfo}{cinfo}{mb}")
    if depth < max_depth:
        for ct in children.get(tid, []):
            if transforms[ct]["go"] is not None:
                dump_tree(ct, depth + 1, max_depth)

roots = [tid for tid, t in transforms.items() if not t["father"]]
print("\n=== ROOTS ===")
for r in roots:
    dump_tree(r, 0, 1)

print("\n=== ARENA TREES ===")
for g in arena_gos:
    tid = next((t for t, tt in transforms.items() if tt["go"] == g), None)
    print(f"\n--- Arena: {name_of(g)} (active={gameobjects[g]['active']}) ---")
    dump_tree(tid, 0, 5)

json.dump({
    "gameobjects": {str(k): v for k, v in gameobjects.items()},
}, open("/home/z/my-project/repo-src/parsed/scene_raw.json", "w"))
print("\nscene doc count:", len(docs))
