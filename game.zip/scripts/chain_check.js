(() => {
  const S = window.__game
  let chains = 0
  const out = []
  for (let b = S.world.getBodyList(); b; b = b.getNext()) {
    for (let f = b.getFixtureList(); f; f = f.getNext()) {
      const sh = f.getShape()
      if (sh.getType() === 'chain') {
        chains++
        const keys = Object.keys(sh)
        const prev = sh._prevVertex !== undefined ? '_prevVertex' : sh.m_prevVertex !== undefined ? 'm_prevVertex' : 'NONE'
        const cnt = sh._count !== undefined ? sh._count : sh.m_count
        out.push({ keys, prev, cnt, vertsLen: (sh._vertices || sh.m_vertices || []).length })
        if (chains >= 1) break
      }
    }
    if (chains >= 1) break
  }
  return JSON.stringify({ chains, out })
})()