#!/usr/bin/env python3
"""Для повёрнутых арен (rotZ!=0): 3 варианта согласования коллайдера и спрайта.
A) как в игре сейчас: и спрайт, и коллайдер повёрнуты на aAngle
B) спрайт повёрнут, коллайдер БЕЗ поворота (уже в мировых координатах)
C) и спрайт, и коллайдер без поворота (сырые)
"""
import json, math, os
from PIL import Image, ImageDraw

BASE = '/home/z/my-project'
data = json.load(open(f'{BASE}/public/game_data.json'))
manifest = json.load(open(f'{BASE}/public/sprite_manifest.json'))
imgs = {}
for f in os.listdir(f'{BASE}/public/sprites'):
    if f.endswith('.png'):
        imgs[f] = Image.open(f'{BASE}/public/sprites/{f}').convert('RGBA')

ORTHO = 2.5714285
ASPECT = 16 / 9
PW = 620
PH = int(PW / ASPECT)
s = PW / (2 * ORTHO * ASPECT)

def w2s(x, y, cy):
    return (PW / 2 + x * s, cy - y * s)

def rot(p, ang):
    return (p[0] * math.cos(ang) - p[1] * math.sin(ang), p[0] * math.sin(ang) + p[1] * math.cos(ang))

def panel(a, variant):
    """variant: 'A' | 'B' | 'C'"""
    im = Image.new('RGBA', (PW, PH), (24, 24, 30, 255))
    d = ImageDraw.Draw(im)
    cy = PH / 2
    aAngle = 2 * math.asin(min(1, a['rotZ']))
    spr_ang = aAngle if variant != 'C' else 0.0
    col_ang = aAngle if variant == 'A' else 0.0

    def draw_sprite(sprite, pos, ang, scale):
        f = sprite.replace('/', '__') + '.png'
        img = imgs[f]
        m = manifest.get(sprite) or {}
        ppu = m.get('ppu', 48)
        w = (img.width / ppu) * (scale[0] if scale else 1) * s
        h = (img.height / ppu) * (scale[1] if scale else 1) * s
        img2 = img.rotate(ang * 180 / math.pi, expand=True, resample=Image.NEAREST)
        sx, sy = w2s(*pos, cy)
        im.alpha_composite(img2.resize((max(1, int(w)), max(1, int(h))), Image.NEAREST), (int(sx - w / 2), int(sy - h / 2)))

    draw_sprite(a['sprite'], a['pos'], spr_ang, a.get('scale'))
    col = a.get('collider') or {}
    for path in col.get('paths') or []:
        pts = []
        for p in path:
            w = rot(p, col_ang)
            pts.append(w2s(a['pos'][0] + w[0], a['pos'][1] + w[1], cy))
        d.line(pts + [pts[0]], fill=(255, 40, 40, 255), width=2)
    d.text((8, 6), f"#{a['_idx']} {a['name']} var={variant}", fill=(255, 255, 0, 255))
    return im

targets = [1, 2, 6, 10, 13]  # повёрнутые и проблемные (11 похожа на 6, посмотрим потом)
os.makedirs('/tmp/mapview', exist_ok=True)
for i in targets:
    a = data['arenas'][i]
    a['_idx'] = i
    row = Image.new('RGBA', (PW * 3, PH), (0, 0, 0, 255))
    for k, v in enumerate(('A', 'B', 'C')):
        row.alpha_composite(panel(a, v), (k * PW, 0))
    row.convert('RGB').save(f'/tmp/mapview/variant_{i}.png')
print('saved', targets)
