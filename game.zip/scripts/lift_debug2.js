(() => {
  const S = window.__game
  const d = S.__dbgData ? S.__dbgData : null
  const def = S.blue.def
  const t = def.tree
  const fp = { minY: Infinity, minX: Infinity, maxX: -Infinity }
  const nodes = [t, ...(t.children || [])]
  const rows = []
  for (const n of nodes) {
    const px = (n.pos && n.pos[0]) || 0
    const py = (n.pos && n.pos[1]) || 0
    if (n.poly) for (const path of n.poly.paths) for (const p of path) {
      const y = py + p[1], x = px + p[0]
      if (y < fp.minY) fp.minY = y
      if (x < fp.minX) fp.minX = x
      if (x > fp.maxX) fp.maxX = x
    }
    if (n.circle) {
      const y = py - n.circle.r, xl = px - n.circle.r, xr = px + n.circle.r
      if (y < fp.minY) fp.minY = y
      if (xl < fp.minX) fp.minX = xl
      if (xr > fp.maxX) fp.maxX = xr
      rows.push('circle at (' + px + ',' + py + ') r=' + n.circle.r + ' -> lowY=' + y.toFixed(2))
    }
  }
  const sy = -1
  const sx = -2
  const xLo = sx + fp.minX, xHi = sx + fp.maxX
  const paths = (S.arena.collider && S.arena.collider.paths) || []
  const tops = []
  for (const path of paths) {
    for (let i = 0; i < path.length; i++) {
      const p1 = path[i], p2 = path[(i + 1) % path.length]
      const lo = Math.max(Math.min(p1[0], p2[0]), xLo)
      const hi = Math.min(Math.max(p1[0], p2[0]), xHi)
      if (hi <= lo) continue
      const xm = (lo + hi) / 2
      const tt = p2[0] === p1[0] ? 0 : (xm - p1[0]) / (p2[0] - p1[0])
      const y = p1[1] + tt * (p2[1] - p1[1])
      tops.push({ y: +y.toFixed(3), below: y < sy + 0.2, span: [+lo.toFixed(2), +hi.toFixed(2)] })
    }
  }
  tops.sort((a, b) => b.y - a.y)
  return JSON.stringify({ fp: { minY: +fp.minY.toFixed(3), minX: +fp.minX.toFixed(2), maxX: +fp.maxX.toFixed(2) }, wheels: rows, xRange: [+xLo.toFixed(2), +xHi.toFixed(2)], sy, topCandidates: tops.slice(0, 6) })
})()