/* Регрессионный тест выпуклой декомпозиции корпуса.
   Запуск: node scripts/test_convex.mjs
   Проверяет: каждый кусок выпуклый CCW с площадью > 0; масса и инерция
   корпуса каждой машины из game_data.json совпадают с префабом. */
import { convexPieces } from '../src/lib/convexPieces.ts'
import * as pl from 'planck'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const data = JSON.parse(readFileSync(join(root, 'public/game_data.json'), 'utf8'))

let failures = 0
const fail = (msg) => {
  failures++
  console.log('  FAIL:', msg)
}

function shoelace(pts) {
  let a = 0
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i]
    const q = pts[(i + 1) % pts.length]
    a += p[0] * q[1] - q[0] * p[1]
  }
  return a / 2
}

function isConvexCcw(pts) {
  const n = pts.length
  for (let i = 0; i < n; i++) {
    const a = pts[i]
    const b = pts[(i + 1) % n]
    const c = pts[(i + 2) % n]
    const cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
    if (cross < -1e-9) return false
  }
  return true
}

/* Универсальная проверка: набор кусков → физическое тело */
function checkPieces(label, pieces, expectedMass) {
  if (!pieces.length) return fail(`${label}: декомпозиция пуста`)
  let totalArea = 0
  for (const pc of pieces) {
    const area = shoelace(pc)
    if (!(area > 1e-9)) return fail(`${label}: кусок с площадью ${area.toFixed(6)} (обход CW или вырожден)`)
    if (!isConvexCcw(pc)) return fail(`${label}: кусок не выпуклый/не CCW`)
    if (pc.length > 8) return fail(`${label}: кусок с ${pc.length} вершинами > 8 (лимит Box2D)`)
    totalArea += area
  }
  if (!(totalArea > 0)) return fail(`${label}: суммарная площадь ${totalArea}`)
  // физическая проверка через planck (как в игре)
  const world = new pl.World({ gravity: new pl.Vec2(0, -7) })
  const body = world.createBody({ type: 'dynamic' })
  const density = expectedMass / totalArea
  for (const pc of pieces) {
    body.createFixture({ shape: pl.Polygon(pc.map((p) => new pl.Vec2(p[0], p[1]))), density })
  }
  const m = body.getMass()
  const I = body.getInertia()
  if (Math.abs(m - expectedMass) > 0.02) fail(`${label}: масса ${m.toFixed(3)} != ${expectedMass}`)
  if (!(I > 0)) fail(`${label}: инерция ${I} <= 0 — крутящий момент не вращает корпус`)
  console.log(`  OK: ${label} — кусков ${pieces.length}, площадь ${totalArea.toFixed(3)}, масса ${m.toFixed(3)}, инерция ${I.toFixed(3)}`)
}

console.log('=== синтетика (CW/CCW/вырожденные случаи) ===')
const square = [
  [0, 0],
  [1, 0],
  [1, 1],
  [0, 1],
]
const squareCw = [...square].reverse()
const lShape = [
  [0, 0],
  [2, 0],
  [2, 1],
  [1, 1],
  [1, 2],
  [0, 2],
]
const lShapeCw = [...lShape].reverse()
const withDupes = [...square, [0, 0]]
const collinear = [
  [0, 0],
  [0.5, 0],
  [1, 0],
  [1, 1],
  [0, 1],
]
const star8 = []
for (let i = 0; i < 16; i++) {
  const ang = (i * Math.PI) / 8
  const r = i % 2 === 0 ? 1 : 0.5
  star8.push([Math.cos(ang) * r, Math.sin(ang) * r])
}
for (const [label, poly, mass] of [
  ['квадрат CCW', square, 2],
  ['квадрат CW (баг-репорт)', squareCw, 2],
  ['L-образный CCW', lShape, 3],
  ['L-образный CW', lShapeCw, 3],
  ['дубль точки', withDupes, 2],
  ['коллинейные точки', collinear, 2],
  ['звезда 16 вершин', star8, 2.5],
]) {
  checkPieces(label, convexPieces(poly), mass)
}

console.log('=== все машины из game_data.json ===')
for (const [name, car] of Object.entries(data.cars)) {
  const bodyNode = (car.tree.children || []).find((c) => c.poly) || (car.tree.poly ? car.tree : null)
  if (!bodyNode) {
    fail(`${name}: нет полигона корпуса`)
    continue
  }
  for (const path of bodyNode.poly.paths) {
    const shifted = path.map((p) => [p[0] + bodyNode.pos[0], p[1] + bodyNode.pos[1]])
    checkPieces(`${name}`, convexPieces(shifted), car.tree.rb.mass)
  }
}

console.log(failures ? `\nИТОГ: ${failures} ОШИБОК` : '\nИТОГ: все проверки пройдены')
process.exit(failures ? 1 : 0)
