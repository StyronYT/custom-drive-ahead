#!/usr/bin/env python3
"""Overlay: arena sprite + collider paths (world coords) for Arenas1_0."""
import json, math
from PIL import Image, ImageDraw

d = json.load(open('/home/z/my-project/public/game_data.json'))
a = d['arenas'][0]
PPU = 48
ax, ay = a['pos']
theta = a.get('theta', 0.0)

# load arena sprite to know its world size (center at arena.pos)
import os
spr = '/home/z/my-project/public/sprites/' + a['sprite'].replace('/', '__') + '.png'
img = Image.open(spr).convert('RGBA')
W, H = img.size
# world rect covered by sprite (center ax,ay; size W/PPU x H/PPU)
ww, wh = W / PPU, H / PPU
scale = 180  # px per world unit
out_w = int(ww * scale) + 80
out_h = int(wh * scale) + 80
canvas = Image.new('RGB', (out_w, out_h), (30, 40, 60))

def w2s(x, y):
    # screen: center of canvas = world center of sprite
    sx = out_w / 2 + (x - ax) * scale
    sy = out_h / 2 - (y - ay) * scale
    return sx, sy

# draw sprite centered
canvas.paste(img.resize((int(ww * scale), int(wh * scale))), (int(out_w / 2 - ww * scale / 2), int(out_h / 2 - wh * scale / 2)), )

draw = ImageDraw.Draw(canvas)
colors = [(255, 60, 60), (60, 255, 60), (80, 160, 255), (255, 220, 60)]
for j, path in enumerate(a['collider']['paths']):
    pts = [w2s(p[0] * (a['scale'][0] or 1) + 0, p[1] * (a['scale'][1] or 1)) for p in path]
    # NOTE: collider coords are in arena-local space (arena at pos, no rotation for this arena)
    pts = [w2s(ax + p[0], ay + p[1]) for p in [(pp[0], pp[1]) for pp in path]]
    color = colors[j % len(colors)]
    draw.line(pts + [pts[0]], fill=color, width=3)
    for p in pts:
        draw.ellipse([p[0] - 3, p[1] - 3, p[0] + 3, p[1] + 3], fill=color)

# children positions
for ch in a['children']:
    lx, ly = ch['pos']
    wx, wy = ax + lx, ay + ly
    p = w2s(wx, wy)
    draw.ellipse([p[0] - 6, p[1] - 6, p[0] + 6, p[1] + 6], outline=(255, 0, 255), width=2)
    if ch.get('collider') and ch['collider'].get('type') == 'circle':
        r = ch['collider']['radius'] * scale
        draw.ellipse([p[0] - r, p[1] - r, p[0] + r, p[1] + r], outline=(255, 0, 255), width=3)

# spawns
for name, sp in a['spawns'].items():
    p = w2s(sp[0], sp[1])
    draw.ellipse([p[0] - 8, p[1] - 8, p[0] + 8, p[1] + 8], outline=(0, 255, 255), width=3)

canvas.save('/home/z/my-project/download/saw_arena_overlay.png')
print('saved overlay, sprite size', W, H, 'world', ww, wh)
