#!/usr/bin/env python3
"""1) Cart: голова по координатам юзера Top Left (12.9, 6.2) px спрайта Cart_0 (29x19, PPU 48).
   Тот же пересчёт, что и раньше для (12.5, 7.9): центр спрайта = (14.5, 9.5).
     x_local = (12.9 - 14.5)/48 = -0.0333   (у Red зеркально +0.0333)
     y_local = (9.5  - 6.2)/48 = +0.0688
2) Пила на Arenas1_0: присвоить спрайты детям Img (1)_0 (само лезвие, 83x83)
   и Img (1)_1 (ступица, 25x25) — они уже нарезаны в game-assets, но не были
   прописаны в game_data (sprite: null) → лезвие было невидимым, машины
   врезались в невидимый коллайдер.
3) Манифест: дописать px/ppu/pivot для пилы, ступицы и Cart.
"""
import json
import shutil

PPU = 48.0
CART_W, CART_H = 29, 19
HEAD_TL = (12.9, 6.2)  # px от верхнего левого угла, как задал пользователь

hx = round((HEAD_TL[0] - CART_W / 2) / PPU, 4)      # -0.0333
hy = round((CART_H / 2 - HEAD_TL[1]) / PPU, 4)      # +0.0688

DATA = 'public/game_data.json'
data = json.load(open(DATA))

# --- Cart: голова ---
for name, car in data['cars'].items():
    if car.get('carType') != 'Cart':
        continue
    flip = car['color'] == 'red'
    x = round(-hx, 4) if flip else hx
    head = next(ch for ch in car['tree']['children'] if ch.get('hinge'))
    head['pos'] = [x, hy]
    head['hinge']['connectedAnchor'] = [x, round(hy - 0.07, 4)]
    print(f"{name}: голова -> ({x}, {hy})")

# --- Пила: спрайты детей Arenas1_0 ---
a = next(a for a in data['arenas'] if a['name'] == 'Arenas1_0')
for ch in a['children']:
    if ch['name'] == 'Img (1)_0':
        ch['sprite'] = 'Img (1)/Img (1)_0'   # лезвие пилы 83x83
    elif ch['name'] == 'Img (1)_1':
        ch['sprite'] = 'Img (1)/Img (1)_1'   # ступица 25x25
print('Arenas1_0: спрайты пилы и ступицы прописаны')

json.dump(data, open(DATA, 'w'), indent=1, ensure_ascii=False)

# --- копия спрайтов в public ---
for f in ('Img (1)__Img (1)_0.png', 'Img (1)__Img (1)_1.png'):
    shutil.copy(f'game-assets/sprites/{f}', f'public/sprites/{f}')
    print('copied', f)

# --- манифест ---
ga = json.load(open('game-assets/sprite_manifest.json'))
pub_path = 'public/sprite_manifest.json'
try:
    pub = json.load(open(pub_path))
except Exception:
    pub = {}
for key in ('Img (1)/Img (1)_0', 'Img (1)/Img (1)_1'):
    pub[key] = ga[key]
pub.setdefault('Cart/Cart_0', {'px': [CART_W, CART_H], 'ppu': 48, 'pivot': [0.5, 0.5]})
json.dump(pub, open(pub_path, 'w'), indent=1)
print('manifest: добавлены', 'Img (1)_0/_1, Cart_0')
print('OK')
