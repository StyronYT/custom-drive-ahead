#!/usr/bin/env python3
"""Добавляет TV car (BlueTVCar/RedTVCar) в game_data.json + спрайты и манифест.
Заодно: cart_red.png (зеркало Cart_1 по X) как спрайт красного карта.

Координаты от пользователя (Top Left, px на спрайте 48x20, PPU=48):
  голова (на КРАСНОЙ): (9.4, 5.9)   -> units ((9.4-24)/48, (10-5.9)/48) = (-0.30417, 0.08542)
  колёса: (11.0, 19.9) -> (-0.27083, -0.20625); (36.9, 20.0) -> (0.26875, -0.20833)
Синий = зеркальный по X.
"""
import json
import shutil
from PIL import Image

ROOT = '/home/z/my-project'
PUB = ROOT + '/public'
GA = ROOT + '/game-assets'

# ---------- 1. спрайты ----------
shutil.copy(ROOT + '/upload/tv_car_blue.png', PUB + '/sprites/TVCar__TVCar_0.png')
shutil.copy(ROOT + '/upload/tv_car_red.png', PUB + '/sprites/TVCar__TVCar_1.png')
shutil.copy(ROOT + '/upload/cart_red.png', PUB + '/sprites/cart_red.png')
for f in ['TVCar__TVCar_0.png', 'TVCar__TVCar_1.png', 'cart_red.png']:
    shutil.copy(PUB + '/sprites/' + f, GA + '/sprites/' + f)

# ---------- 2. манифест ----------
for mf in [PUB + '/sprite_manifest.json', GA + '/sprite_manifest.json']:
    m = json.load(open(mf))
    m['TVCar/TVCar_0'] = {'px': [48, 20], 'ppu': 48, 'pivot': [0.5, 0.5]}
    m['TVCar/TVCar_1'] = {'px': [48, 20], 'ppu': 48, 'pivot': [0.5, 0.5]}
    m['cart_red'] = {'px': [29, 19], 'ppu': 48, 'pivot': [0.5, 0.5]}
    json.dump(m, open(mf, 'w'), indent=1, ensure_ascii=False)

# ---------- 3. poly корпуса (обводка силуэта синего, CCW, units) ----------
# трассировка силуэта tv_car_blue.png (см. анализ): корпус + антенна + кабина
BLUE_POLY = [
    [-0.4583, -0.1667], [0.4583, -0.1667], [0.4792, -0.125], [0.4792, -0.0208],
    [0.4583, 0.0208], [0.4583, 0.0833], [0.4375, 0.0833], [0.3333, 0.0417],
    [0.2292, 0.0625], [0.2083, 0.0833], [0.1667, 0.125], [0.125, 0.2083],
    [-0.4375, 0.2083], [-0.5, 0.125], [-0.5, 0.0208], [-0.5, -0.1042], [-0.4792, -0.125],
]
# красный = зеркальный по X, обход развернут обратно для CCW
RED_POLY = [[-x, y] for x, y in reversed(BLUE_POLY)]

RB_ROOT = {'mass': 4, 'gravityScale': 1, 'linearDamping': 0.2, 'angularDamping': 0.05, 'friction': 0.1}
RB_WHEEL = {'mass': 1, 'gravityScale': 1, 'linearDamping': 0, 'angularDamping': 0.05, 'friction': 3}
RB_HEAD = {'mass': 0.5, 'gravityScale': -0.1, 'linearDamping': 0, 'angularDamping': 0.05, 'friction': 0.4}
CIRCLE_W = {'r': 0.09, 'off': [0.0, 0.0], 'friction': 3}
CIRCLE_H = {'r': 0.075, 'off': [0.0, 0.0], 'friction': 0.4}
SUSP = [0.7, 8]


def wheel(name, pos, sprite):
    return {
        'name': name, 'layer': 0, 'pos': pos, 'scale': [1.0, 1.0],
        'rb': dict(RB_WHEEL), 'circle': dict(CIRCLE_W),
        'sprite': sprite, 'flipX': False, 'order': 1,
    }


def head(pos, sprite, conn_anchor):
    return {
        'name': 'Head', 'layer': 0, 'pos': pos, 'scale': [1.0, 1.0],
        'rb': dict(RB_HEAD), 'circle': dict(CIRCLE_H),
        'sprite': sprite, 'flipX': False, 'order': 3,
        'hinge': {'anchor': [0.0, -0.07], 'connectedAnchor': conn_anchor, 'limits': [-20, 20]},
    }


def body(poly, sprite):
    return {
        'name': 'Body', 'layer': 0, 'pos': [0.0, 0.0], 'scale': [1.0, 1.0],
        'poly': {'paths': [poly]},
        'sprite': sprite, 'flipX': False, 'order': 2,
    }


def tv_car(color):
    if color == 'blue':
        # синий: кабина/голова справа, заднее колесо слева
        h_pos, h_sprite = [0.30417, 0.08542], 'CarParts/CarParts_304'
        back, front = [-0.26875, -0.20833], [0.27083, -0.20625]
        b_poly, b_sprite = BLUE_POLY, 'TVCar/TVCar_0'
        conn = [0.30417, 0.01542]
    else:
        # красный: кабина/голова слева (голова (9.4,5.9) на красной), заднее колесо справа
        h_pos, h_sprite = [-0.30417, 0.08542], 'CarParts/CarParts_302'
        back, front = [0.26875, -0.20833], [-0.27083, -0.20625]
        b_poly, b_sprite = RED_POLY, 'TVCar/TVCar_1'
        conn = [-0.30417, 0.01542]
    return {
        'carType': 'TVCar',
        'color': color,
        'carData': {'speed': 200, 'maxSpeed': 360, 'rotationSpeed': 120},
        'tree': {
            'name': ('BlueTVCar' if color == 'blue' else 'RedTVCar'),
            'layer': 0, 'pos': [0.0, 0.0], 'scale': [1.0, 1.0],
            'rb': dict(RB_ROOT),
            'wheelJoints': [
                {'connected': None, 'anchor': list(back), 'susp': list(SUSP)},
                {'connected': None, 'anchor': list(front), 'susp': list(SUSP)},
            ],
            'children': [
                wheel('BackWheel', back, 'CarParts/CarParts_329' if color == 'blue' else 'CarParts/CarParts_327'),
                wheel('FrontWheel', front, 'CarParts/CarParts_329' if color == 'blue' else 'CarParts/CarParts_327'),
                head(h_pos, h_sprite, conn),
                body(b_poly, b_sprite),
            ],
        },
    }


# game-assets/game_data.json — устаревшая копия (без RedCart): sync целиком из public
shutil.copy(PUB + '/game_data.json', GA + '/game_data.json')
shutil.copy(PUB + '/sprite_manifest.json', GA + '/sprite_manifest.json')
for gd in [PUB + '/game_data.json', GA + '/game_data.json']:
    d = json.load(open(gd))
    d['cars']['BlueTVCar'] = tv_car('blue')
    d['cars']['RedTVCar'] = tv_car('red')
    # cart_red.png: спрайт красного карта = зеркальная картинка, flipX больше не нужен
    for c in d['cars']['RedCart']['tree']['children']:
        if c.get('poly'):
            c['sprite'] = 'cart_red'
            c['flipX'] = False
    json.dump(d, open(gd, 'w'), indent=1, ensure_ascii=False)

print('OK: TVCar sprites + manifest + game_data updated')
for f in ['public/sprites/TVCar__TVCar_0.png', 'public/sprites/TVCar__TVCar_1.png', 'public/sprites/cart_red.png']:
    im = Image.open(ROOT + '/' + f)
    print(f, im.size, im.mode)
