#!/usr/bin/env python3
"""Visualize arena polygons over their sprites to verify correctness."""
import json, re, math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MplPoly
from PIL import Image

arenas = json.load(open('/home/z/my-project/scripts/parsed/scene_arenas.json'))
scene = json.load(open('/home/z/my-project/scripts/parsed/scene.json'))

# find arena sprite rect from scene.json (BattleSetup children)
def find_arena_sprite(name):
    for t in scene:
        if t['name'] == 'BattleSetup':
            for ch in t['children']:
                if ch['name'] == name:
                    for c in ch['components']:
                        if c['kind'] == 'sprite' and c.get('sprite'):
                            return c['sprite']
    return None

PPU = 48
sheets = {}
for sname in ['Arenas1', 'Arenas2', 'Arenas3', 'Arenas4']:
    sheets[sname + '.png'] = Image.open(f'/tmp/drive-ahead/Assets/Drive Ahead/Sprites/{sname}.png')

fig, axes = plt.subplots(4, 4, figsize=(16, 16))
names = [n for n in arenas if n != 'What']
for i, name in enumerate(sorted(arenas.keys())):
    ax = axes[i // 4][i % 4]
    a = arenas[name]
    spr = find_arena_sprite(name)
    if spr:
        sheet_name = spr['sheet']
        x, y, w, h = spr['x'], spr['y'], spr['w'], spr['h']
        img = sheets[sheet_name].crop((int(x), int(y), int(x + w), int(y + h)))
        px, py = a['pos']
        ax.imshow(img, extent=[px - w/PPU/2, px + w/PPU/2, py - h/PPU/2, py + h/PPU/2], origin='upper')
    for p in a['polys']:
        if 'path' in p:
            ax.add_patch(MplPoly(p['path'], fill=False, edgecolor='lime', linewidth=1))
        elif p['type'] == 'circle':
            import matplotlib.pyplot as mp
            c = mp.Circle(p['pos'], p['radius'], fill=False, edgecolor='orange')
            ax.add_patch(c)
    bs = a['spawns'].get('BlueSpawn'); rs = a['spawns'].get('RedSpawn')
    if bs: ax.plot(bs[0], bs[1], 'b*', markersize=10)
    if rs: ax.plot(rs[0], rs[1], 'r*', markersize=10)
    ax.set_xlim(-5.2, 5.2); ax.set_ylim(-3.8, 3.8)
    ax.set_title(name, fontsize=8)
    ax.set_aspect('equal')
plt.tight_layout()
plt.savefig('/home/z/my-project/scripts/arena_check.png', dpi=80)
print('saved')
