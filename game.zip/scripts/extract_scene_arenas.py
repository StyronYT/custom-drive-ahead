#!/usr/bin/env python3
"""Extract arena polygon colliders (world coords), correctly splitting multi-path polygons."""
import re, math, json

txt = open('/tmp/drive-ahead/Assets/Drive Ahead/Scenes/SampleScene.unity').read()
docs = {}
for m in re.finditer(r"--- !u!(\d+) &(\d+)\n(.*?)(?=--- !u!|\Z)", txt, re.S):
    docs[m.group(2)] = {"cls": m.group(1), "body": m.group(3)}

def get_vec(b, key):
    m = re.search(rf"{key}: \{{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+)(?:, z: (-?[\d.eE+-]+))?\}}", b)
    if not m: return None
    return [float(m.group(1)), float(m.group(2)), float(m.group(3)) if m.group(3) else 0.0]

def get_quat(b):
    m = re.search(r"m_LocalRotation: \{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+), z: (-?[\d.eE+-]+), w: (-?[\d.eE+-]+)\}", b)
    if not m: return 0.0
    x, y, z, w = [float(g) for g in m.groups()]
    return math.degrees(math.atan2(2*(w*z + x*y), 1 - 2*(z*z + x*x)))

transforms = {}
for fid, d in docs.items():
    if d["cls"] in ("4", "224"):
        b = d["body"]
        ch = re.search(r"m_Children:(.*?)m_Father:", b, re.S)
        father = re.search(r"m_Father: \{fileID: (\d+)\}", b)
        transforms[fid] = {
            "pos": (get_vec(b, "m_LocalPosition") or [0,0,0]),
            "rot": get_quat(b),
            "scale": (get_vec(b, "m_LocalScale") or [1,1,1])[:2],
            "father": father.group(1) if father and father.group(1) != "0" else None,
            "children": re.findall(r"fileID: (\d+)\}", ch.group(1)) if ch else [],
        }

t2go, go2t = {}, {}
for fid, d in docs.items():
    if d["cls"] != "1": continue
    for cid in re.findall(r"  - component: \{fileID: (\d+)\}", d["body"]):
        if docs.get(cid, {}).get("cls") in ("4", "224"):
            t2go[cid] = fid; go2t[fid] = cid

def world_pos(tfid):
    tr = transforms[tfid]
    if tr["father"] and tr["father"] in transforms:
        pp, pr, ps = world_pos(tr["father"])
    else:
        pp, pr, ps = [0,0,0], 0.0, [1,1]
    r = math.radians(pr)
    lp = tr["pos"]
    wx = pp[0] + lp[0]*math.cos(r)*ps[0] - lp[1]*math.sin(r)*ps[1]
    wy = pp[1] + lp[0]*math.sin(r)*ps[0] + lp[1]*math.cos(r)*ps[1]
    return (wx, wy), pr + tr["rot"], [ps[0]*tr["scale"][0], ps[1]*tr["scale"][1]]

def parse_polygon_paths(body):
    """Parse m_Paths into list of paths (each = list of [x,y])."""
    m = re.search(r"m_Paths:\s*\n(.*?)(?=\n  \w|\Z)", body, re.S)
    if not m: return []
    block = m.group(1)
    paths = []
    # each path begins with "- - {x:" at lower indent than continuation "- {"
    # split lines and group
    cur = None
    for line in block.splitlines():
        s = line.strip()
        pm = re.match(r"- - \{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+)\}", s)
        cm = re.match(r"- \{x: (-?[\d.eE+-]+), y: (-?[\d.eE+-]+)\}", s)
        if pm:
            if cur: paths.append(cur)
            cur = [[float(pm.group(1)), float(pm.group(2))]]
        elif cm and cur is not None:
            cur.append([float(cm.group(1)), float(cm.group(2))])
    if cur: paths.append(cur)
    return paths

arena_script_go = []
for fid, d in docs.items():
    if d["cls"] == "114" and 'guid: 40151d1587914ddfbdb70b701ee4d02d' in d["body"]:
        gofid = re.search(r"m_GameObject: \{fileID: (\d+)\}", d["body"]).group(1)
        arena_script_go.append(gofid)

arenas = {}
for gofid in arena_script_go:
    tfid = go2t[gofid]
    (wx, wy), wr, wsc = world_pos(tfid)
    gname = re.search(r"m_Name: (.+)", docs[gofid]["body"]).group(1)
    spawns, polys = {}, []
    for ctf in transforms[tfid]["children"]:
        cgo = t2go.get(ctf)
        if not cgo or cgo not in docs: continue
        cname = re.search(r"m_Name: (.+)", docs[cgo]["body"]).group(1)
        cpos, crot, cscl = world_pos(ctf)
        if cname in ("BlueSpawn", "RedSpawn"):
            spawns[cname] = [round(cpos[0], 4), round(cpos[1], 4)]
        for cid in re.findall(r"  - component: \{fileID: (\d+)\}", docs[cgo]["body"]):
            cd = docs.get(cid)
            if not cd: continue
            if cd["cls"] == "60":
                for path in parse_polygon_paths(cd["body"]):
                    # apply child world transform
                    r = math.radians(crot)
                    tp = []
                    for p in path:
                        lx, ly = p
                        tpx = cpos[0] + lx*math.cos(r)*cscl[0] - ly*math.sin(r)*cscl[1]
                        tpy = cpos[1] + lx*math.sin(r)*cscl[0] + ly*math.cos(r)*cscl[1]
                        tp.append([round(tpx, 5), round(tpy, 5)])
                    polys.append({"path": tp, "src": cname})
            elif cd["cls"] in ("58", "61"):
                col = {"type": "circle" if cd["cls"]=="58" else "box", "pos": [round(cpos[0],4), round(cpos[1],4)], "src": cname}
                if cd["cls"]=="58": col["radius"] = float(re.search(r"m_Radius: ([\d.]+)", cd["body"]).group(1))
                else:
                    col["size"] = get_vec(cd["body"], "m_Size")[:2]
                polys.append(col)
    for cid in re.findall(r"  - component: \{fileID: (\d+)\}", docs[gofid]["body"]):
        cd = docs.get(cid)
        if cd and cd["cls"] == "60":
            for path in parse_polygon_paths(cd["body"]):
                r = math.radians(wr)
                tp = []
                for p in path:
                    lx, ly = p
                    tpx = wx + lx*math.cos(r)*wsc[0] - ly*math.sin(r)*wsc[1]
                    tpy = wy + lx*math.sin(r)*wsc[0] + ly*math.cos(r)*wsc[1]
                    tp.append([round(tpx, 5), round(tpy, 5)])
                polys.append({"path": tp, "src": gname})
    arenas[gname] = {"pos": [round(wx,4), round(wy,4)], "rot": round(wr,3), "spawns": spawns, "polys": polys}

json.dump(arenas, open('/home/z/my-project/scripts/parsed/scene_arenas.json', 'w'), indent=1)
for name, a in arenas.items():
    npaths = len([p for p in a['polys'] if 'path' in p])
    others = [p for p in a['polys'] if 'path' not in p]
    print(f"{name}: spawns={a['spawns']} paths={npaths} extras={others}")
