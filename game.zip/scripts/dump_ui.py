#!/usr/bin/env python3
"""Dump UI objects (stars, panels, spins) with RectTransform data from scene."""
import json, sys
sys.path.insert(0, "/home/z/my-project/scripts")
from parse_unity import load_docs, vec2

docs = load_docs("/home/z/my-project/repo-src/SampleScene.unity")
go, tf, comp = {}, {}, {}
for d in docs:
    c = d["_class"]
    if c == 1:
        go[d["_id"]] = d
    elif c == 4:
        tf[d["_id"]] = d
    else:
        comp[d["_id"]] = d

# build GO -> transform (via components), sprite ref, script refs
def comps_of(goid):
    return [list(cc.values())[0].get("fileID") for cc in go[goid].get("m_Component", [])]

names = {}
for goid, d in go.items():
    names[goid] = d.get("m_Name")

UI_GUIDS = {"e5a1b9e7842524a45af5b3ec48d1e77e": "Menus"}
results = []
for goid, d in go.items():
    n = d.get("m_Name") or ""
    if any(k in n for k in ("Star", "Spin", "WinPanel", "WinText", "ScoreText", "Stars", "Canvas", "Text")):
        info = {"name": n, "components": []}
        for cid in comps_of(goid):
            dd = comp.get(cid)
            if not dd: continue
            cls = dd["_class"]
            if cls == 212:
                s = dd.get("m_Sprite") or {}
                info["sprite"] = f"{(s.get('guid') or '')[:8]}/{s.get('fileID')}"
                info["color"] = dd.get("m_Color")
            if cls == 224:  # RectTransform
                ap = dd.get("m_AnchorPosition") or vec2(dd.get("m_AnchoredPosition"))
                info["anchoredPos"] = vec2(dd.get("m_AnchoredPosition"))
                info["sizeDelta"] = vec2(dd.get("m_SizeDelta"))
                info["anchorMin"] = vec2(dd.get("m_AnchorMin"))
                info["anchorMax"] = vec2(dd.get("m_AnchorMax"))
                info["scale"] = vec2(dd.get("m_LocalScale"))
                info["father"] = (dd.get("m_Father") or {}).get("fileID")
            if cls == 114:
                info["script"] = (dd.get("m_Script") or {}).get("guid", "")[:8]
            if cls == 1:
                info["active"] = dd.get("m_IsActive")
        info["active"] = d.get("m_IsActive")
        results.append(info)

for r in results:
    print(json.dumps(r, ensure_ascii=False))
