# -*- coding: utf-8 -*-
"""Инспекция game_data.json: узлы Head, шарниры головы, спрайты, манифест."""
import json, os

d = json.load(open('public/game_data.json'))
cars = d['cars']
print('=== cars:', len(cars))
for name in sorted(cars):
    c = cars[name]
    tree = c.get('tree', {})
    root = {k: v for k, v in tree.items() if k != 'children'}
    kids = tree.get('children', [])
    heads = [k for k, _ in enumerate(kids) if str(kids[k].get('name', '')).lower() == 'head']
    # найти узел головы по имени
    head = next((k for k in kids if str(k.get('name', '')).lower() == 'head'), None)
    info = []
    if head is not None:
        info.append('pos=%s' % head.get('pos'))
        info.append('sprite=%s' % head.get('sprite'))
        for comp in head.get('components', []):
            if comp.get('kind') == 'joint':
                info.append('joint(type=%s, anchor=%s, connectedAnchor=%s, ON-HEAD)' % (
                    comp.get('type'), comp.get('anchor'), comp.get('connectedAnchor')))
    # шарниры, живущие на ДРУГИХ узлах и соединённые с головой?
    head_bid = head.get('body') if head else None
    for k in kids:
        if k is head:
            continue
        for comp in k.get('components', []):
            if comp.get('kind') == 'joint' and head_bid and comp.get('connectedBody') == head_bid:
                info.append('JOINT-ON-%s -> head (anchor=%s, connectedAnchor=%s)' % (
                    k.get('name'), comp.get('anchor'), comp.get('connectedAnchor')))
    body_sprite = root.get('sprite') or (kids[0].get('sprite') if kids else None)
    print('%-24s kids=%d head=%s body_sprite=%s %s' % (
        name, len(kids), 'YES' if head is not None else 'NO!',
        body_sprite, ' | '.join(info)))

print()
print('=== manifest ===')
mf = json.load(open('public/sprites_manifest.json'))
if isinstance(mf, dict):
    ks = list(mf.keys())
    print('entries:', len(ks), 'sample:', {k: mf[k] for k in ks[:3]})
    need = ['CarParts/CarParts_304', 'CarParts/CarParts_25', 'CarParts/CarParts_304']
    for n in set(need + ks[:2]):
        print(n, '->', mf.get(n))
print()
print('=== файлы спрайтов на диске ===')
for p in ['public/sprites/CarParts__CarParts_304.png', 'public/sprites/CarParts__CarParts_25.png']:
    print(p, os.path.exists(p))
