(() => {
  const S = window.__game;
  if (!S || !S.world) return 'no world';
  if (S.__dbgOn) return 'already on';
  S.__dbgOn = true;
  const cv = document.querySelector('canvas');
  const ctx = cv.getContext('2d');
  fetch('/game_data.json').then(r => r.json()).then(d => { S.__dbgData = d; });
  S.__dbgDraw = () => {
    try {
      if (!S.world) return;
      const cw = cv.width, chh = cv.height;
      const s = chh / (2 * 2.5714285);
      const cx = cw / 2, cy = chh / 2;
      const T = (x, y) => [cx + x * s, cy - y * s];
      const openInfo = {};
      if (S.__dbgData && S.arena) {
        const a = S.__dbgData.arenas.find(a => a.name === S.arena.name);
        if (a && a.collider && a.collider.open) (a.collider.open || []).forEach(i => openInfo[i] = true);
      }
      let pi = 0;
      for (let b = S.world.getBodyList(); b; b = b.getNext()) {
        for (let f = b.getFixtureList(); f; f = f.getNext()) {
          const sh = f.getShape();
          if (sh.getType() !== 'chain') continue;
          const vs = (sh._vertices || sh.m_vertices || []), n = (sh._count ?? sh.m_count ?? vs.length);
          const pos = b.getPosition(), ang = b.getAngle();
          const ca = Math.cos(ang), sa = Math.sin(ang);
          const P = v => {
            const wx = pos.x + v.x * ca - v.y * sa;
            const wy = pos.y + v.x * sa + v.y * ca;
            return T(wx, wy);
          };
          ctx.save();
          ctx.strokeStyle = 'rgba(255,30,30,0.95)';
          ctx.lineWidth = 2;
          ctx.beginPath();
          for (let i = 0; i < n; i++) { const [sx, sy] = P(vs[i]); if (i === 0) ctx.moveTo(sx, sy); else ctx.lineTo(sx, sy); }
          if (!openInfo[pi]) { const [sx, sy] = P(vs[n - 1]); ctx.lineTo(sx, sy); }
          ctx.stroke();
          ctx.fillStyle = 'rgba(255,220,40,0.95)';
          for (let i = 0; i < n; i++) { const [sx, sy] = P(vs[i]); ctx.fillRect(sx - 2, sy - 2, 4, 4); }
          ctx.restore();
          pi++;
        }
      }
    } catch (e) { S.__dbgErr = String(e); }
  };
  const raf = window.requestAnimationFrame.bind(window);
  window.requestAnimationFrame = (cb) => raf(t => { cb(t); try { S.__dbgDraw(); } catch (e) {} });
  return 'overlay on (rAF)';
})()