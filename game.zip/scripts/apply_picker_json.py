# -*- coding: utf-8 -*-
"""Применение результата оффлайн-пикера (download/head_picker.html) к game_data.json.

Формат JSON пикера (кнопки «копировать всё (JSON)» / «скачать JSON»):
{
  "car": "Banana",
  "head": [x, y],
  "wheels": { "BackWheel": [x, y], "FrontWheel": [x, y] }
}

Что делает для каждого варианта машины (BlueCar, RedCar):
- Head:        пишет pos узла Head и синхронно пересчитывает hinge.connectedAnchor
               = pos + hinge.anchor (движок считает якорь из pos, поле держим
               консистентным, как это делал add_banana.py).
- Колёса:      пишет pos узла <Имя> И якорь соответствующего wheelJoints.
               КРИТИЧНО: игра (page.tsx) сопоставляет колесо с шарниром по якорю
               (допуск 0.01), без синхронной правки якоря колесо теряется.

Запуск:
  python3 scripts/apply_picker_json.py banana_positions.json            # применить
  python3 scripts/apply_picker_json.py banana_positions.json --dry      # только показать
  python3 scripts/apply_picker_json.py banana_positions.json --data X   # другой файл
"""
import argparse
import json
import math
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA = ROOT / "public" / "game_data.json"
BACKUP_DIR = ROOT / "scripts" / "gamedata_backups"
MAX_BACKUPS = 10

TOL = 1e-2   # допуск сопоставления якоря wheelJoints — как в page.tsx
LIMIT = 2.0  # разумный диапазон pos (юниты) — как в POST /api/head_pos


def fail(msg: str):
    raise SystemExit("ОШИБКА: " + msg)


def check_pos(v, what):
    if (not isinstance(v, (list, tuple)) or len(v) != 2
            or not all(isinstance(n, (int, float)) and not isinstance(n, bool) and math.isfinite(n) for n in v)):
        fail(f"{what}: должен быть [x, y] — конечные числа")
    if abs(v[0]) > LIMIT or abs(v[1]) > LIMIT:
        fail(f"{what}: pos вне разумного диапазона (|x|,|y| ≤ {LIMIT})")
    return [float(v[0]), float(v[1])]


def children(tree):
    return tree.get("children") or []


def find_node(tree, name, key):
    for c in children(tree):
        if str(c.get("name") or "") == name:
            return c
    fail(f"{key}: узел {name} не найден")


def apply_head(tree, key, pos):
    node = find_node(tree, "Head", key)
    old = node.get("pos")
    node["pos"] = pos
    hinge = node.get("hinge") or {}
    if isinstance(hinge.get("anchor"), list):
        a = hinge["anchor"]
        hinge["connectedAnchor"] = [round(pos[0] + a[0], 6), round(pos[1] + a[1], 6)]
    return f"Head      {old} -> {pos}"


def apply_wheel(tree, key, name, pos):
    node = find_node(tree, name, key)
    old = node.get("pos")
    joints = tree.get("wheelJoints") or []
    best_i, best_d = None, None
    for i, j in enumerate(joints):
        a = j.get("anchor")
        if not isinstance(a, list):
            continue
        d = max(abs(a[0] - old[0]), abs(a[1] - old[1]))
        if best_d is None or d < best_d:
            best_i, best_d = i, d
    if best_i is None or best_d > TOL:
        fail(f"{key}: для {name} не найден якорь wheelJoints около {old} (ближайший {best_d})")
    node["pos"] = pos
    joints[best_i]["anchor"] = list(pos)
    return f"{name:<9} {old} -> {pos}  (+якорь wheelJoints #{best_i})"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("picker_json", help="JSON из оффлайн-пикера")
    ap.add_argument("--data", default=str(DEFAULT_DATA))
    ap.add_argument("--dry", action="store_true", help="не писать файл, только показать")
    args = ap.parse_args()

    spec_path = Path(args.picker_json)
    if not spec_path.exists():
        fail("файл не найден: " + str(spec_path))
    try:
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
    except Exception as e:
        fail("пикер-JSON не читается: " + str(e))

    car = str(spec.get("car") or "").strip()
    if not car:
        fail("в JSON нет car")
    head = check_pos(spec.get("head"), "head")
    wheels = spec.get("wheels") or {}
    if not isinstance(wheels, dict):
        fail("wheels: должен быть объект {Имя: [x, y]}")

    try:
        data = json.loads(Path(args.data).read_text(encoding="utf-8"))
    except Exception as e:
        fail("game_data не читается: " + str(e))
    cars = data.get("cars") or {}
    keys = [k for k in cars if k == car or k.endswith(car)]
    if not keys:
        fail(f"машина не найдена: {car}")

    changes = {}
    for k in keys:
        tree = cars[k].get("tree") or {}
        lines = [apply_head(tree, k, head)]
        for name, pos in wheels.items():
            lines.append(apply_wheel(tree, k, str(name), check_pos(pos, f"wheels.{name}")))
        changes[k] = lines

    print("== Изменения ==")
    for k, lines in changes.items():
        print(k + ":")
        for ln in lines:
            print("  " + ln)

    if args.dry:
        print("== DRY RUN: файл не изменён ==")
        return

    src = Path(args.data)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = BACKUP_DIR / f"{src.stem}.{stamp}.json"
    backup.write_bytes(src.read_bytes())
    backups = sorted(BACKUP_DIR.glob(src.stem + ".*.json"))
    for old in backups[:-MAX_BACKUPS]:
        old.unlink(missing_ok=True)
    print("бэкап:", backup)

    src.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    # верификация: перечитать файл и сверить, что записалось
    again = json.loads(src.read_text(encoding="utf-8"))
    for k in keys:
        tree = again["cars"][k]["tree"]
        h = find_node(tree, "Head", k)
        assert h["pos"] == head, f"{k}: Head pos не записался"
        for name, pos in wheels.items():
            n = find_node(tree, name, k)
            assert n["pos"] == pos, f"{k}: {name} pos не записался"
            anch = [j["anchor"] for j in tree.get("wheelJoints") or []]
            assert any(max(abs(a[0]-pos[0]), abs(a[1]-pos[1])) <= 1e-9 for a in anch), \
                f"{k}: якорь wheelJoints для {name} не записался"
    print(f"✅ Записано в {src}: {', '.join(keys)}; перечитано, значения на месте.")


if __name__ == "__main__":
    main()
