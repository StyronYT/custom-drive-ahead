import json
import matplotlib.font_manager as fm
fm.fontManager.addfont('/usr/share/fonts/truetype/chinese/NotoSansSC-Regular.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['Noto Sans SC', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

d = json.load(open('/home/z/my-project/public/game_data.json'))
a = [x for x in d['arenas'] if x['name'] == 'Arenas1_0'][0]
paths = a['collider']['paths']

fig, ax = plt.subplots(figsize=(10, 6.8), constrained_layout=True)
for i, p in enumerate(paths):
    xs = [q[0] for q in p] + [p[0][0]]
    ys = [q[1] for q in p] + [p[0][1]]
    ax.plot(xs, ys, '-o', ms=3, lw=1.4, label=f'path{i} ({len(p)})')

# спавны и колёса Monster
bs = a['spawns']['BlueSpawn']; rs = a['spawns']['RedSpawn']
ax.plot(*bs, 'b^', ms=12, label='BlueSpawn')
ax.plot(*rs, 'r^', ms=12, label='RedSpawn')
# Monster: центр (-2,-1), колёса (∓0.3,-0.48), r=0.2
ax.add_patch(plt.Circle((-1.7, -1.48), 0.2, fill=False, color='b', ls='--'))
ax.add_patch(plt.Circle((-2.3, -1.48), 0.2, fill=False, color='b', ls='--'))
ax.axhline(0, color='gray', lw=0.4); ax.axvline(0, color='gray', lw=0.4)
ax.set_aspect('equal')
ax.grid(True, alpha=0.3)
ax.legend(loc='upper left', bbox_to_anchor=(1.01, 1), fontsize=8)
ax.set_title('Arenas1_0: коллайдеры (сглаженные) vs спавн/колёса Monster')
ax.set_xlabel('x (юниты)'); ax.set_ylabel('y (юниты)')
fig.savefig('/tmp/render/saw_geo.png', dpi=110)
print('saved /tmp/render/saw_geo.png')
