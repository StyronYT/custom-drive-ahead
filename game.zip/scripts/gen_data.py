#!/usr/bin/env python3
"""Generate src/game/data.ts from parsed Unity project data."""
import json, re, math

SC = "/home/z/my-project/scripts/parsed"
cars = json.load(open(f"{SC}/cars.json"))
arenas = json.load(open(f"{SC}/scene_arenas.json"))
sprites = json.load(open(f"{SC}/sprites.json"))
scene = json.load(open(f"{SC}/scene.json"))

# ---- car data table (from CarsData assets) ----
CAR_DATA = {
    "AntiqueFormula": {"speed": 35, "maxSpeed": 70, "rotationSpeed": 70},
    "Dragster": {"speed": 300, "maxSpeed": 600, "rotationSpeed": 200},
    "Limouse": {"speed": 45, "maxSpeed": 90, "rotationSpeed": 120},
    "Monster": {"speed": 200, "maxSpeed": 400, "rotationSpeed": 150},
    "OffRoadTruck": {"speed": 50, "maxSpeed": 100, "rotationSpeed": 120},
    "PlanetaryExplorer": {"speed": 25, "maxSpeed": 50, "rotationSpeed": 100},
    "Weevil": {"speed": 60, "maxSpeed": 120, "rotationSpeed": 130},
}
NAME_MAP = {"Off-RoadTruck": "OffRoadTruck"}

def body_type_of(prefab_name):
    # "BlueMonster" -> "Monster"; "RedOff-RoadTruck" -> "Off-RoadTruck"
    tail = prefab_name[4:] if prefab_name.startswith("Blue") else prefab_name[3:]
    for bt in ["AntiqueFormula", "Off-RoadTruck", "PlanetaryExplorer", "Limouse", "Dragster", "Monster", "Weevil"]:
        if tail.startswith(bt):
            return bt
    raise ValueError(prefab_name)

def spr_ref(s, sheet=None):
    if not s: return None
    orig = sheet or s.get("sheet")
    sh = "Img1.png" if orig == "Img (1).png" else orig
    # Unity meta rect y is BOTTOM-UP; PNG/canvas is TOP-DOWN: y_png = H - y - h
    from PIL import Image
    H = Image.open(f"/tmp/drive-ahead/Assets/Drive Ahead/Sprites/{orig}").height
    y_png = H - s["y"] - s["h"]
    return {"sheet": sh, "x": s["x"], "y": y_png, "w": s["w"], "h": s["h"]}

def find_part(node, name):
    if node["name"] == name: return node
    for ch in node["children"]:
        r = find_part(ch, name)
        if r: return r
    return None

def find_all_parts(node, pred):
    out = []
    if pred(node): out.append(node)
    for ch in node["children"]:
        out += find_all_parts(ch, pred)
    return out

def comp(node, kind):
    for c in node["components"]:
        if c["kind"] == kind: return c
    return None

def poly_paths(node):
    """Extract polygon collider paths from a node (world-less, local pts)."""
    cols = [c for c in node["components"] if c["kind"] == "collider" and c["type"] == "polygon"]
    paths = []
    for c in cols:
        for poly in c.get("polygons", []):
            paths.append(poly)
    return paths

# Build car defs
car_defs = []
used_sprites = {}
def use_sprite(s):
    if not s: return None
    ref = spr_ref(s)
    used_sprites[s["name"]] = ref
    return s["name"]

for key in sorted(cars.keys()):
    tree = cars[key]
    bt = body_type_of(key)
    color = "Blue" if key.startswith("Blue") else "Red"
    body_node = find_part(tree, "Body")
    head_node = find_part(tree, "Head")
    wheels = find_all_parts(tree, lambda n: n["name"].startswith(("BackWheel", "FrontWheel")))
    wheels.sort(key=lambda n: n["name"])
    root_rb = comp(tree, "rigidbody")

    # wheel joints from root: match by anchor == wheel position
    joints = []
    for c in tree["components"]:
        if c["kind"] == "joint" and c["type"] == "wheel":
            best_i, best_d = 0, 1e9
            for i, w in enumerate(wheels):
                d = (w["pos"][0] - c["anchor"][0])**2 + (w["pos"][1] - c["anchor"][1])**2
                if d < best_d:
                    best_d, best_i = d, i
            joints.append({"wheel": best_i, "anchor": c["anchor"], "frequency": c["frequency"], "dampingRatio": c["dampingRatio"]})
    joints.sort(key=lambda j: (j["wheel"], -j["anchor"][0]))

    head_j = comp(head_node, "joint")
    head_col = comp(head_node, "collider")
    head_rb = comp(head_node, "rigidbody")
    body_col = comp(body_node, "collider")
    body_rb = comp(tree, "rigidbody")

    body_sprites = [c for c in body_node["components"] if c["kind"] == "sprite"]
    wheel_sprites = [c for c in wheels[0]["components"] if c["kind"] == "sprite"]
    head_sprites = [c for c in head_node["components"] if c["kind"] == "sprite"]

    body_paths = poly_paths(body_node)

    car_defs.append({
        "key": key,
        "color": color,
        "bodyType": NAME_MAP.get(bt, bt),
        "body": {
            "mass": body_rb["mass"],
            "material": body_rb.get("material"),
            "sprite": use_sprite(body_sprites[0].get("sprite")),
            "polys": body_paths,
        },
        "wheels": [
            {
                "pos": [round(w["pos"][0], 5), round(w["pos"][1], 5)],
                "radius": comp(w, "collider")["radius"],
                "mass": comp(w, "rigidbody")["mass"],
                "material": comp(w, "rigidbody").get("material"),
                "sprite": use_sprite(wheel_sprites[0].get("sprite")),
            } for w in wheels
        ],
        "head": {
            "pos": [round(head_node["pos"][0], 5), round(head_node["pos"][1], 5)],
            "radius": head_col["radius"],
            "mass": head_rb["mass"],
            "gravityScale": head_rb["gravityScale"],
            "sprite": use_sprite(head_sprites[0].get("sprite")),
            "anchorOnBody": head_j["connectedAnchor"],
            "limits": head_j["limits"],
        },
        "wheelJoints": [{"wheel": j["wheel"], "anchor": j["anchor"], "frequency": j["frequency"], "dampingRatio": j["dampingRatio"]} for j in joints],
    })

# ---- arenas ----
def find_arena_sprite(name):
    for t in scene:
        if t["name"] == "BattleSetup":
            for ch in t["children"]:
                if ch["name"] == name:
                    for c in ch["components"]:
                        if c["kind"] == "sprite" and c.get("sprite"):
                            return c, ch
    return None, None

arena_defs = []
for name, a in arenas.items():
    spr_comp, node = find_arena_sprite(name)
    deco = []
    ball = None
    if node:
        for ch in node["children"]:
            sp = [c for c in ch["components"] if c["kind"] == "sprite"]
            col = [c for c in ch["components"] if c["kind"] == "collider"]
            rb = [c for c in ch["components"] if c["kind"] == "rigidbody"]
            if sp:
                s = sp[0].get("sprite")
                if s and col:
                    # ball obstacle
                    ball = {
                        "pos": ch["pos"][:2],
                        "radius": col[0]["radius"],
                        "mass": rb[0]["mass"] if rb else 1,
                        "sprite": use_sprite(s),
                        "spriteScale": ch["scale"][0],
                        "order": sp[0]["order"],
                    }
                elif s:
                    deco.append({"sprite": use_sprite(s), "pos": ch["pos"][:2], "rot": ch["rot"], "order": sp[0]["order"]})
    walls = []
    extras = []
    for p in a["polys"]:
        if "path" in p:
            walls.append(p["path"])
        else:
            extras.append(p)
    arena_defs.append({
        "key": name,
        "sprite": use_sprite(spr_comp.get("sprite")),
        "spriteOrder": spr_comp["order"],
        "pos": a["pos"],
        "walls": walls,
        "spawns": {"blue": a["spawns"].get("BlueSpawn"), "red": a["spawns"].get("RedSpawn")},
        "deco": deco,
        "ball": ball,
        "extras": extras,
    })

# ---- border boxes (from Border GO) ----
border = []
for t in scene:
    if t["name"] == "Border":
        for c in t["components"]:
            if c["kind"] == "collider":
                border.append({"offset": c["offset"], "size": c["size"]})

# ---- used sprite rect map ----
sprite_out = {}
for name, ref in used_sprites.items():
    sprite_out[name] = ref

# star & UI sprites (fixed refs found earlier)
sprite_out["Img (1)_2"] = spr_ref(sprites["Img (1).png"]["-2428446364636465068"], "Img (1).png")  # empty star
sprite_out["Img (1)_8"] = spr_ref(sprites["Img (1).png"]["3112694687959637627"], "Img (1).png")   # blue star
sprite_out["Img (1)_9"] = spr_ref(sprites["Img (1).png"]["7867579526668088053"], "Img (1).png")   # red star
sprite_out["SpinEffects_1"] = spr_ref(sprites["SpinEffects.png"]["-2430675501420733699"], "SpinEffects.png")

# people bg sprites
sprite_out["Img (1)_41"] = spr_ref(sprites["Img (1).png"]["1304886605700465282"], "Img (1).png")
sprite_out["Img (1)_49"] = spr_ref(sprites["Img (1).png"]["4071783765766920861"], "Img (1).png")
sprite_out["SpinEffects_0"] = spr_ref(sprites["SpinEffects.png"]["-5238100470319202939"], "SpinEffects.png")

# ---- materials ----
materials = {
    "TireFriction": {"friction": 3, "bounciness": 0, "frictionCombine": "Average", "bounceCombine": "Minimum"},
    "NoFriction": {"friction": 0.1, "bounciness": 0, "frictionCombine": "Average", "bounceCombine": "Minimum"},
    "None": {"friction": 0.6, "bounciness": 0, "frictionCombine": "Average", "bounceCombine": "Minimum"},
}

def py2ts(obj, indent=0):
    return json.dumps(obj, ensure_ascii=False)

out = []
out.append("// AUTO-GENERATED from Unity project 'Drive Ahead' (github.com/blackvalter/Drive-Ahead).")
out.append("// All physics values, sprite rects, positions and configs are extracted verbatim from the Unity assets.")
out.append("")
out.append("export interface SpriteRef { sheet: string; x: number; y: number; w: number; h: number }")
out.append("")
out.append("export const SHEETS: Record<string, { src: string; ppu: number }> = {")
for name, ppu in [("CarParts.png", 48), ("Arenas1.png", 48), ("Arenas2.png", 48), ("Arenas3.png", 48), ("Arenas4.png", 48), ("Img1.png", 48), ("SpinEffects.png", 100)]:
    out.append(f"  '{name}': {{ src: '/sprites/{name}', ppu: {ppu} }},")
out.append("}")
# fix star/UI sprite refs that still point to the old sheet name
sprite_out = {k: (dict(v) if v else v) for k, v in sprite_out.items()}
for k, v in sprite_out.items():
    if isinstance(v, dict) and v.get("sheet") == "Img (1).png":
        v["sheet"] = "Img1.png"
out.append("")
out.append("export const SPR: Record<string, SpriteRef> = " + json.dumps(sprite_out, ensure_ascii=False, indent=2).replace('"sheet"', "sheet").replace('"x"', "x").replace('"y"', "y").replace('"w"', "w").replace('"h"', "h").replace("{", "{").replace(": ", ": ") + "")
out.append("")
out.append("export const CAR_DATA: Record<string, { speed: number; maxSpeed: number; rotationSpeed: number }> = " + json.dumps(CAR_DATA) + "")
out.append("")
out.append("export const PHYSICS_MATERIALS: Record<string, { friction: number; bounciness: number }> = " + json.dumps(materials) + "")
out.append("")
out.append("export interface CarWheel { pos: [number, number]; radius: number; mass: number; material: string | null; sprite: string | null }")
out.append("export interface CarDef {")
out.append("  key: string")
out.append("  color: 'Blue' | 'Red'")
out.append("  bodyType: string")
out.append("  body: { mass: number; material: string | null; sprite: string | null; polys: number[][][] }")
out.append("  wheels: CarWheel[]")
out.append("  head: { pos: [number, number]; radius: number; mass: number; gravityScale: number; sprite: string | null; anchorOnBody: number[]; limits: number[] }")
out.append("  wheelJoints: { wheel: number; anchor: number[]; frequency: number; dampingRatio: number }[]")
out.append("}")
out.append("")
out.append("export const CARS: CarDef[] = " + json.dumps(car_defs, ensure_ascii=False) + "")
out.append("")
out.append("export interface ArenaDef {")
out.append("  key: string")
out.append("  sprite: string | null")
out.append("  spriteOrder: number")
out.append("  pos: number[]")
out.append("  walls: number[][][]")
out.append("  spawns: { blue: number[] | null; red: number[] | null }")
out.append("  deco: { sprite: string | null; pos: number[]; rot: number; order: number }[]")
out.append("  ball: { pos: number[]; radius: number; mass: number; sprite: string | null; spriteScale: number; order: number } | null")
out.append("  extras: unknown[]")
out.append("}")
out.append("")
out.append("export const ARENAS: ArenaDef[] = " + json.dumps(arena_defs, ensure_ascii=False) + "")
out.append("")
out.append("export const BORDER_BOXES: { offset: number[]; size: number[] }[] = " + json.dumps(border) + "")
out.append("")
out.append("export const BACKGROUND = {")
out.append("  color: [0.19215687, 0.3019608, 0.4745098],")
out.append("  peopleBack: { sprite: 'Img (1)_49', pos: [0, -0.6] },")
out.append("  people: { sprite: 'Img (1)_41', pos: [0, -0.587] },")
out.append("  sideX: [0, -9.46, 9.46],")
out.append("  screenQuad: { pos: [0.0015, 1.3004], scale: [1.9741182, 1.0536549] },")
out.append("}")
out.append("")
out.append("export const UI_SPRITES = {")
out.append("  blueStar: 'Img (1)_8',")
out.append("  redStar: 'Img (1)_9',")
out.append("  emptyStar: 'Img (1)_2',")
out.append("  spinEffect: 'SpinEffects_1',")
out.append("}")
out.append("")

dst = "/home/z/my-project/src/game/data.ts"
import os
os.makedirs("/home/z/my-project/src/game", exist_ok=True)
open(dst, "w").write("\n".join(out))
print("written", dst, len("\n".join(out)), "bytes")
print("cars:", len(car_defs), "arenas:", len(arena_defs), "sprites used:", len(sprite_out))
