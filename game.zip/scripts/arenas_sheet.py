#!/usr/bin/env python3
"""Contact sheet: all arena sprites with collider overlays to spot missing collisions."""
import json
from PIL import Image, ImageDraw, ImageFont

d = json.load(open('/home/z/my-project/public/game_data.json'))
PPU = 48
scale = 60  # px per world unit
cols = 4
pad = 30
tiles = []
for i, a in enumerate(d['arenas']):
    spr = '/home/z/my-project/public/sprites/' + a['sprite'].replace('/', '__') + '.png'
    img = Image.open(spr).convert('RGBA')
    W, H = img.size
    ww, wh = W / PPU, H / PPU
    ax, ay = a['pos']
    tw, th = int(ww * scale) + pad, int(wh * scale) + pad + 14
    tile = Image.new('RGB', (tw, th), (25, 30, 45))
    tile.paste(img.resize((int(ww * scale), int(wh * scale))), (pad // 2, pad // 2))
    dr = ImageDraw.Draw(tile)

    def w2s(x, y):
        return pad / 2 + (x - (ax - ww / 2)) * scale, pad / 2 + ((ay + wh / 2) - y) * scale

    colors = [(255, 70, 70), (70, 255, 70), (80, 160, 255), (255, 220, 60)]
    col = a.get('collider') or {}
    for j, path in enumerate(col.get('paths') or []):
        pts = [w2s(ax + p[0], ay + p[1]) for p in path]
        dr.line(pts + [pts[0]], fill=colors[j % len(colors)], width=2)
    for ch in a.get('children') or []:
        if ch.get('collider') and ch['collider'].get('type') == 'circle':
            lx, ly = ch['pos']
            p = w2s(ax + lx, ay + ly)
            r = ch['collider'].get('radius', 0.65) * scale
            dr.ellipse([p[0] - r, p[1] - r, p[0] + r, p[1] + r], outline=(255, 0, 255), width=2)
    try:
        f = ImageFont.load_default()
        dr.text((4, 2), f"{i}:{a['name']}", fill=(255, 255, 255), font=f)
    except Exception:
        pass
    tiles.append(tile)

cw = max(t.width for t in tiles)
chh = max(t.height for t in tiles)
rows = (len(tiles) + cols - 1) // cols
sheet = Image.new('RGB', (cw * cols + 10, chh * rows + 10), (10, 12, 20))
for k, t in enumerate(tiles):
    x = (k % cols) * cw + 5
    y = (k // cols) * chh + 5
    sheet.paste(t, (x, y))
sheet.save('/home/z/my-project/download/arenas_sheet.png')
print('sheet size', sheet.size, 'tiles', len(tiles))
