#!/usr/bin/env python3
"""Cut sprites from Unity atlases with correct Y-flip (Unity origin = bottom-left)."""
import json, os, sys
from PIL import Image

SRC = "/home/z/my-project/repo-src"
OUT = "/home/z/my-project/game-assets/sprites"
os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, "/home/z/my-project/scripts")
from parse_unity import parse_meta_sprites

# atlas file name (without .png) -> keys
ATLAS_FILES = {
    "Arenas1": "Arenas1", "Arenas2": "Arenas2", "Arenas3": "Arenas3", "Arenas4": "Arenas4", "Arenas5": "Arenas5",
    "CarParts": "CarParts", "Img (1)": "Img (1)", "Menus": "Menus", "SpinEffects": "SpinEffects",
}

# guid -> atlas name (from parsed metas)
guid_map = {}
atlas_data = {}
for atlas in ATLAS_FILES:
    guid, sprites, fid2sprite = parse_meta_sprites(f"{SRC}/metas/{atlas}.png.meta")
    atlas_data[atlas] = {"guid": guid, "sprites": sprites, "fid2sprite": fid2sprite}
    guid_map[guid] = atlas
print("guids:", {k[:8]: v for k, v in guid_map.items()})

manifest = {}  # "atlas/sprite" -> {w,h,ppu,pivot}

for atlas, fname in ATLAS_FILES.items():
    img = Image.open(f"{SRC}/sprites/{fname}.png").convert("RGBA")
    W, H = img.size
    d = atlas_data[atlas]
    for name, sp in d["sprites"].items():
        x, y, w, h = sp["rect"]
        # Unity: y from bottom-left → PIL: top-left
        box = (int(x), int(H - y - h), int(x + w), int(H - y))
        crop = img.crop(box)
        # verify non-empty
        alpha = crop.getchannel("A").getextrema()[1]
        if alpha == 0:
            print(f"WARN {atlas}/{name} fully transparent")
        crop.save(f"{OUT}/{atlas}__{name}.png")
        manifest[f"{atlas}/{name}"] = {
            "px": [crop.width, crop.height],
            "ppu": 48 if atlas not in ("Menus", "SpinEffects", "Thumbnails") else 100,
            "pivot": sp["pivot"],
        }
    print(f"{atlas}: cut {len(d['sprites'])} sprites from {fname}.png ({W}x{H})")

json.dump(manifest, open("/home/z/my-project/game-assets/sprite_manifest.json", "w"), indent=1)
print("total:", len(manifest))
