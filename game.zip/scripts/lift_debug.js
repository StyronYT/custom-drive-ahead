(() => {
  const S = window.__game
  const car = S.blue
  const box = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity }
  const acc = (b) => {
    const pos = b.getPosition()
    const ang = b.getAngle()
    const ca = Math.cos(ang), sa = Math.sin(ang)
    for (let f = b.getFixtureList(); f; f = f.getNext()) {
      const sh = f.getShape()
      if (sh.getType() === 'circle') {
        const r = sh.getRadius ? sh.getRadius() : sh.m_radius
        box.minX = Math.min(box.minX, pos.x - r); box.maxX = Math.max(box.maxX, pos.x + r)
        box.minY = Math.min(box.minY, pos.y - r); box.maxY = Math.max(box.maxY, pos.y + r)
      } else {
        const vs = sh.m_vertices || []
        for (const v of vs) {
          const wx = pos.x + v.x * ca - v.y * sa
          const wy = pos.y + v.x * sa + v.y * ca
          box.minX = Math.min(box.minX, wx); box.maxX = Math.max(box.maxX, wx)
          box.minY = Math.min(box.minY, wy); box.maxY = Math.max(box.maxY, wy)
        }
      }
    }
  }
  acc(car.body); for (const w of car.wheels) acc(w); if (car.head) acc(car.head)
  const a = S.arena
  const paths = (a.collider && a.collider.paths) || []
  const tops = []
  for (const path of paths) {
    for (let i = 0; i < path.length; i++) {
      const p1 = path[i], p2 = path[(i + 1) % path.length]
      const lo = Math.max(Math.min(p1[0], p2[0]), box.minX)
      const hi = Math.min(Math.max(p1[0], p2[0]), box.maxX)
      if (hi <= lo) continue
      const xm = (lo + hi) / 2
      const t = p2[0] === p1[0] ? 0 : (xm - p1[0]) / (p2[0] - p1[0])
      const y = p1[1] + t * (p2[1] - p1[1])
      tops.push({ y: +y.toFixed(3), span: [ +lo.toFixed(2), +hi.toFixed(2) ] })
    }
  }
  tops.sort((a, b) => b.y - a.y)
  return JSON.stringify({ box: { minX: +box.minX.toFixed(2), minY: +box.minY.toFixed(2), maxX: +box.maxX.toFixed(2), maxY: +box.maxY.toFixed(2) }, cy: +car.body.getPosition().y.toFixed(2), topCandidates: tops.slice(0, 8) })
})()