window.__probe = (async () => {
  const S = window.__game
  const results = []
  const flat = 'Arenas1_1'
  S.data.arenas = [S.data.arenas.find(a => a.name === flat)]
  const sleep = ms => new Promise(r => setTimeout(r, ms))
  const press = (code, key, down) =>
    window.dispatchEvent(new Event(down ? 'keydown' : 'keyup', {})) // placeholder, replaced below
  const kd = (code, key) => window.dispatchEvent(new KeyboardEvent('keydown', { code, key }))
  const ku = (code, key) => window.dispatchEvent(new KeyboardEvent('keyup', { code, key }))
  const names = Object.keys(S.data.cars).filter(n => S.data.cars[n].color === 'blue')
  for (const name of names) {
    S.forceCars = { blue: name, red: 'RedWeevil' }
    S.roundOver = false
    S.buildRound()
    await sleep(350)
    const car = S.blue
    const body = car.body
    const inertia = body.getInertia()
    const mass = body.getMass()
    const x0 = body.getPosition().x
    let maxAngVel = 0
    kd('KeyD', 'd')
    const t0 = performance.now()
    while (performance.now() - t0 < 650) {
      const w = body.getAngularVelocity()
      if (Math.abs(w) > Math.abs(maxAngVel)) maxAngVel = w
      await sleep(40)
    }
    ku('KeyD', 'd')
    const x1 = body.getPosition().x
    const angle = body.getAngle()
    results.push({
      name,
      mass: +mass.toFixed(2),
      inertia: +inertia.toFixed(3),
      inertiaOK: inertia > 0,
      dx: +(x1 - x0).toFixed(2),
      maxAngVel: +maxAngVel.toFixed(3),
      angleDeg: +((angle * 180) / Math.PI).toFixed(1),
    })
  }
  // --- контакт корпус-корпус ---
  S.forceCars = { blue: 'BlueWeevil', red: 'RedWeevil' }
  S.buildRound()
  await sleep(300)
  let bbContacts = 0
  const bodies = [S.blue.body, S.red.body]
  S.world.on('begin-contact', c => {
    const a = c.getFixtureA().getBody()
    const b = c.getFixtureB().getBody()
    if (bodies.includes(a) && bodies.includes(b)) bbContacts++
  })
  S.blue.body.setPosition({ x: S.red.body.getPosition().x - 2.0, y: S.red.body.getPosition().y + 0.4 })
  S.blue.body.setLinearVelocity({ x: 5, y: 0 })
  await sleep(700)
  const dxAfter = +(S.red.body.getPosition().x - S.blue.body.getPosition().x).toFixed(2)
  window.__probeResult = { cars: results, bbContacts, dxAfter }
})()
