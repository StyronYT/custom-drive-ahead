#!/usr/bin/env python3
"""Cart: голова чуть ниже + прибавить ходу (speed/maxSpeed)."""
import json

P = '/home/z/my-project/public/game_data.json'
d = json.load(open(P))

HEAD_Y = 0.23          # было 0.278; зазор над кузовом станет ~0.032 (как у Weevil)
SPEED = 200            # было 90   → ускорение = speed*0.05 = 10 units/s^2
MAXSPEED = 360         # было 180  → потолок = maxSpeed/60 = 6 units/s (у Dragster ~5.6)

for name, car in d['cars'].items():
    if car.get('carType') != 'Cart':
        continue
    car['carData']['speed'] = SPEED
    car['carData']['maxSpeed'] = MAXSPEED
    t = car['tree']
    for ch in t.get('children', []):
        if 'hinge' in ch:  # голова
            ch['pos'][1] = HEAD_Y
            ch['hinge']['connectedAnchor'] = [ch['hinge']['connectedAnchor'][0], round(HEAD_Y - 0.07, 4)]
    print(name, 'head y ->', HEAD_Y, 'speed ->', SPEED, 'maxSpeed ->', MAXSPEED)

json.dump(d, open(P, 'w'), indent=1)
print('saved')
