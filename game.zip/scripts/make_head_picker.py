# -*- coding: utf-8 -*-
"""Генератор download/head_picker.html — автономный инструмент (file:// ok) для
выбора позиции головы И колёс Banana: цели «Голова / Заднее колесо / Переднее
колесо», клик по спрайту -> пиксели / pos юниты / x1000, превью обоих вариантов
с колесами и шлемом, экспорт JSON для scripts/apply_picker_json.py."""
import base64

SP = 'public/sprites/'
FILES = {
    '__IMG_BANANA_BLUE__': SP + 'Banana__Banana_blue.png',
    '__IMG_BANANA_RED__': SP + 'Banana__Banana_red.png',
    '__IMG_HELMET_BLUE__': SP + 'CarParts__CarParts_304.png',
    '__IMG_HELMET_RED__': SP + 'CarParts__CarParts_302.png',
    '__IMG_WHEEL__': SP + 'CarParts__CarParts_329.png',
}

HTML = r'''<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Banana — позиция головы и колёс</title>
<style>
  :root { --bg:#14141c; --card:#1e1e2a; --line:#33334a; --txt:#e8e8f0; --dim:#9a9ab0; --acc:#7ee787; --warn:#ffb86b; }
  * { box-sizing: border-box; }
  body { margin:0; background:var(--bg); color:var(--txt); font:14px/1.5 system-ui, "Segoe UI", sans-serif; padding:18px; }
  h1 { font-size:18px; margin:0 0 4px; }
  .sub { color:var(--dim); font-size:13px; margin-bottom:14px; }
  .wrap { display:flex; gap:16px; flex-wrap:wrap; align-items:flex-start; }
  .card { background:var(--card); border:1px solid var(--line); border-radius:10px; padding:12px; }
  .left { flex: 0 0 auto; }
  .right { flex: 1 1 300px; min-width:300px; max-width:460px; }
  canvas { image-rendering: pixelated; display:block; border:1px solid var(--line); border-radius:6px; cursor:crosshair; background:#0d0d13; }
  .row { display:flex; gap:8px; align-items:center; margin-top:10px; flex-wrap:wrap; }
  button { background:#2c2c3e; color:var(--txt); border:1px solid var(--line); border-radius:8px; padding:7px 12px; font-size:13px; cursor:pointer; }
  button:hover { background:#383850; }
  button.primary { background:#1d4a2a; border-color:#2f7c42; font-weight:600; }
  button.primary:hover { background:#256338; }
  input[type=range] { accent-color: var(--acc); }
  .lbl { color:var(--dim); font-size:12px; }
  .val { font:13px/1.4 ui-monospace, Consolas, monospace; color:#fff; }
  .big { font-size:16px; }
  .copy { padding:4px 9px; font-size:12px; }
  .copied { color: var(--acc) !important; border-color: var(--acc) !important; }
  .copyfail { color: var(--warn) !important; border-color: var(--warn) !important; }
  .banner { display:none; background:#3a2a15; border:1px solid #6b4a20; color:var(--warn); border-radius:8px; padding:8px 10px; font-size:12.5px; margin-top:10px; }
  .hint { color:var(--dim); font-size:12px; margin-top:8px; }
  kbd { background:#2c2c3e; border:1px solid var(--line); border-radius:4px; padding:0 5px; font-size:11px; }
  .prevs { display:flex; gap:14px; flex-wrap:wrap; margin-top:14px; }
  .prev { text-align:center; }
  .prev .cap { font-size:12px; color:var(--dim); margin-top:5px; }
  .marker-legend { font-size:12px; color:var(--dim); margin-top:8px; }
  .dot { display:inline-block; width:10px; height:10px; border-radius:50%; margin:0 4px 0 2px; vertical-align:-1px; }
</style>
</head>
<body>
<h1>Banana — позиция головы и колёс</h1>
<div class="sub">Выбери цель сверху (клавиши <b>1/2/3</b>), кликни в её центр на спрайте, стрелки — подстройка. Внизу — превью в игре. Результат: «копировать всё» или «скачать JSON» — пришли файл или значения, и они будут применены к игре.</div>

<div class="wrap">
  <div class="card left">
    <div class="row" style="margin-top:0">
      <button id="tab_head">Голова</button>
      <button id="tab_BackWheel">Заднее колесо</button>
      <button id="tab_FrontWheel">Переднее колесо</button>
    </div>
    <canvas id="cv"></canvas>
    <div class="row">
      <span class="lbl">зум</span>
      <input id="zoom" type="range" min="8" max="32" step="4" value="16">
      <span class="lbl" id="zoomVal">16×</span>
      <button id="resetBtn" title="вернуть все цели к значениям из игры">сброс к текущим</button>
    </div>
    <div class="row">
      <button id="upBtn">загрузить свой PNG</button>
      <input id="file" type="file" accept="image/*" style="display:none">
      <span class="lbl" id="sizeInfo">спрайт 35×24, ppu 48</span>
    </div>
    <div class="banner" id="banner"></div>
    <div class="marker-legend">
      <span class="dot" style="background:transparent;border:2px solid #7ee787"></span> текущая pos головы
      &nbsp;<span class="dot" style="background:transparent;border:2px solid #ffb86b"></span> заднего колеса
      &nbsp;<span class="dot" style="background:transparent;border:2px solid #58c4ff"></span> переднего
      &nbsp;&nbsp;<span class="dot" style="background:#ff5f6d"></span> твой выбор (большой крест — активная цель)
    </div>
    <div class="hint">Клавиши <kbd>1</kbd>/<kbd>2</kbd>/<kbd>3</kbd> — выбор цели, <kbd>←↑↓→</kbd> — подстройка по 0.1 px (с <kbd>Shift</kbd> — по 1 px). Точка отсчёта pos — центр спрайта (серый крест).</div>
  </div>

  <div class="card right">
    <div class="lbl" id="actName">—</div>
    <div class="lbl" style="margin-top:8px">Пиксель спрайта (y вниз от левого-верхнего угла)</div>
    <div class="val big" id="vpx">—</div>
    <div class="lbl" style="margin-top:10px">pos для game_data.json (юниты, y вверх)</div>
    <div class="row" style="margin-top:4px">
      <span class="val big" id="vpos">—</span>
      <button class="copy" id="cpos">копировать</button>
    </div>
    <div class="lbl" style="margin-top:10px">×1000 (как ты обычно пишешь)</div>
    <div class="row" style="margin-top:4px">
      <span class="val" id="vmil">—</span>
      <button class="copy" id="cmil">копировать</button>
    </div>
    <div class="lbl" style="margin-top:14px">Все цели (pos, юниты):</div>
    <div class="row" style="margin-top:2px">
      <span class="dot" style="background:#7ee787"></span><span class="lbl" style="width:118px">Голова</span>
      <span class="val" id="sum_val_head" style="flex:1">—</span>
      <button class="copy" id="sum_copy_head">копи</button>
    </div>
    <div class="row" style="margin-top:2px">
      <span class="dot" style="background:#ffb86b"></span><span class="lbl" style="width:118px">Заднее колесо</span>
      <span class="val" id="sum_val_BackWheel" style="flex:1">—</span>
      <button class="copy" id="sum_copy_BackWheel">копи</button>
    </div>
    <div class="row" style="margin-top:2px">
      <span class="dot" style="background:#58c4ff"></span><span class="lbl" style="width:118px">Переднее колесо</span>
      <span class="val" id="sum_val_FrontWheel" style="flex:1">—</span>
      <button class="copy" id="sum_copy_FrontWheel">копи</button>
    </div>
    <div class="row" style="margin-top:12px">
      <button id="allBtn" class="primary">копировать всё (JSON)</button>
      <button id="dlBtn">скачать JSON</button>
    </div>
    <div class="hint">В JSON — голова и оба колеса. Колёса применяются вместе с якорями wheelJoints (игра ищет колесо по якорю, без синхронизации колесо теряется) — это делает скрипт применения, считать ничего не нужно.</div>
  </div>
</div>

<div class="prevs">
  <div class="card prev"><canvas id="pvB"></canvas><div class="cap">BlueBanana — так будет в игре</div></div>
  <div class="card prev"><canvas id="pvR"></canvas><div class="cap">RedBanana — так будет в игре</div></div>
</div>

<script>
"use strict";
const PPU = 48, HELM_W = 11, HELM_H = 9, WHEEL_W = 10, WHEEL_H = 10;
const BUILTIN_W = 35, BUILTIN_H = 24;

// значения pos из дефа на момент генерации инструмента (юниты, y вверх)
const CURRENT = {
  head:       [-0.0167, 0.0646],
  BackWheel:  [-0.2, -0.223958],
  FrontWheel: [0.245833, -0.223958]
};
const TARGETS = [
  { id: 'head',       name: 'Голова',          color: '#7ee787', what: 'центр шлема' },
  { id: 'BackWheel',  name: 'Заднее колесо',   color: '#ffb86b', what: 'центр заднего колеса' },
  { id: 'FrontWheel', name: 'Переднее колесо', color: '#58c4ff', what: 'центр переднего колеса' }
];

const IMG = {
  bananaB: "__IMG_BANANA_BLUE__",
  bananaR: "__IMG_BANANA_RED__",
  helmB:   "__IMG_HELMET_BLUE__",
  helmR:   "__IMG_HELMET_RED__",
  wheel:   "__IMG_WHEEL__"
};

const cv = document.getElementById('cv'), ctx = cv.getContext('2d');
const pvB = document.getElementById('pvB'), pvR = document.getElementById('pvR');
const vpx = document.getElementById('vpx'), vpos = document.getElementById('vpos'), vmil = document.getElementById('vmil');
const banner = document.getElementById('banner'), sizeInfo = document.getElementById('sizeInfo');
const zoomEl = document.getElementById('zoom'), zoomVal = document.getElementById('zoomVal');
const actName = document.getElementById('actName');

let img = new Image(), imgW = BUILTIN_W, imgH = BUILTIN_H, zoom = 16;
let active = 'head';
let usingUpload = false; // превью обеих раскрасок строим на дефолтных спрайтах, на своей картинке — на ней
const picks = {}; // id -> {x, y} в пикселях спрайта (дробные, y вниз)
img.src = IMG.bananaB; // встроенный спрайт по умолчанию

const pxToPos = (p) => [ (p.x - imgW/2)/PPU, (imgH/2 - p.y)/PPU ];
const posToPx = (u) => ({ x: u[0]*PPU + imgW/2, y: imgH/2 - u[1]*PPU });
const r01 = (v) => Math.round(v*10)/10;
const targetById = (id) => TARGETS.find(t => t.id === id);

function fmt(v, d){ let s = v.toFixed(d); if (s.includes('.')) s = s.replace(/\.?0+$/,''); return s; }

// pos выбранной точки; если не тронуто — точное значение из дефа
function posArr(id){
  const u = pxToPos(picks[id]);
  let x = +u[0].toFixed(4), y = +u[1].toFixed(4);
  const c = CURRENT[id];
  if (Math.abs(x - c[0]) <= 5e-4) x = c[0];
  if (Math.abs(y - c[1]) <= 5e-4) y = c[1];
  return [x, y];
}
function posStr(id){ const a = posArr(id); return '[' + a[0] + ', ' + a[1] + ']'; }
function payload(){
  return {
    car: 'Banana',
    head: posArr('head'),
    wheels: { BackWheel: posArr('BackWheel'), FrontWheel: posArr('FrontWheel') }
  };
}

function updateValues(){
  const p = picks[active], u = pxToPos(p);
  const t = targetById(active);
  actName.textContent = t.name + ' — кликни в ' + t.what;
  actName.style.color = t.color;
  vpx.textContent = 'x ' + p.x.toFixed(1) + ',  y ' + p.y.toFixed(1);
  vpos.textContent = posStr(active);
  vmil.textContent = '[' + fmt(u[0]*1000,1) + ', ' + fmt(u[1]*1000,1) + ']';
  document.getElementById('cpos').dataset.val = posStr(active);
  document.getElementById('cmil').dataset.val = vmil.textContent;
  for (const q of TARGETS){
    document.getElementById('sum_val_' + q.id).textContent = posStr(q.id);
    document.getElementById('sum_copy_' + q.id).dataset.val = posStr(q.id);
  }
}

function setActive(id){
  active = id;
  TARGETS.forEach(x => {
    const b = document.getElementById('tab_' + x.id);
    const on = x.id === active;
    b.style.borderColor = on ? x.color : '';
    b.style.color = on ? x.color : '';
    b.style.fontWeight = on ? '600' : '';
  });
  updateValues(); draw();
}

function setPick(p){
  picks[active] = { x: r01(p.x), y: r01(p.y) };
  updateValues(); draw(); drawPreviews();
}

function draw(){
  const w = imgW*zoom, h = imgH*zoom;
  cv.width = w; cv.height = h; cv.style.width = w+'px'; cv.style.height = h+'px';
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0,0,w,h);
  ctx.drawImage(img, 0, 0, w, h);
  // сетка пикселей
  ctx.lineWidth = 1;
  for (let x=0; x<=imgW; x++){
    ctx.strokeStyle = 'rgba(255,255,255,' + (x%5 ? 0.07 : 0.16) + ')';
    ctx.beginPath(); ctx.moveTo(x*zoom+.5, 0); ctx.lineTo(x*zoom+.5, h); ctx.stroke();
  }
  for (let y=0; y<=imgH; y++){
    ctx.strokeStyle = 'rgba(255,255,255,' + (y%5 ? 0.07 : 0.16) + ')';
    ctx.beginPath(); ctx.moveTo(0, y*zoom+.5); ctx.lineTo(w, y*zoom+.5); ctx.stroke();
  }
  // центр спрайта (pos = 0,0)
  const cx = imgW/2*zoom, cy = imgH/2*zoom;
  ctx.strokeStyle = 'rgba(200,200,220,.55)';
  ctx.beginPath(); ctx.moveTo(cx-8,cy); ctx.lineTo(cx+8,cy); ctx.moveTo(cx,cy-8); ctx.lineTo(cx,cy+8); ctx.stroke();
  // текущие позиции из дефа (кружки цветов целей)
  for (const t of TARGETS){
    const c = posToPx(CURRENT[t.id]);
    ctx.strokeStyle = t.color; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(c.x*zoom, c.y*zoom, 9, 0, 7); ctx.stroke();
  }
  // выборы: активная цель — большой красный крест, остальные — малые
  for (const t of TARGETS){
    const p = picks[t.id]; if (!p) continue;
    const big = t.id === active;
    const px = p.x*zoom, py = p.y*zoom, arm = big ? 14 : 9, gap = big ? 5 : 3;
    ctx.strokeStyle = '#ff5f6d'; ctx.lineWidth = big ? 2 : 1.4; ctx.globalAlpha = big ? 1 : 0.55;
    ctx.beginPath();
    ctx.moveTo(px-arm, py); ctx.lineTo(px-gap, py);
    ctx.moveTo(px+gap, py); ctx.lineTo(px+arm, py);
    ctx.moveTo(px, py-arm); ctx.lineTo(px, py-gap);
    ctx.moveTo(px, py+gap); ctx.lineTo(px, py+arm);
    ctx.stroke();
    if (big){ ctx.fillStyle = '#ff5f6d'; ctx.beginPath(); ctx.arc(px, py, 3, 0, 7); ctx.fill(); }
    ctx.globalAlpha = 1;
  }
}

const cache = {};
function cached(src){
  if (!cache[src]){ const i = new Image(); i.onload = () => drawPreviews(); i.src = src; cache[src] = i; }
  return cache[src];
}

function drawPreviews(){
  const z = 8, ox = 4, oy = 6; // запас под колесо/шлем, торчащие за края
  const w = (imgW+2*ox)*z, h = (imgH+2*oy)*z;
  [[pvB, IMG.bananaB, IMG.helmB], [pvR, IMG.bananaR, IMG.helmR]].forEach(([pc, bi, hi]) => {
    pc.width = w; pc.height = h; pc.style.width = w+'px'; pc.style.height = h+'px';
    const c = pc.getContext('2d');
    c.imageSmoothingEnabled = false;
    c.clearRect(0,0,w,h);
    // колёса рисуем ПОД корпусом, шлем — над ним
    const wi = cached(IMG.wheel);
    for (const id of ['BackWheel','FrontWheel']){
      const p = picks[id];
      if (p && wi.complete && wi.naturalWidth)
        c.drawImage(wi, (p.x+ox)*z - WHEEL_W*z/2, (p.y+oy)*z - WHEEL_H*z/2, WHEEL_W*z, WHEEL_H*z);
    }
    const body = usingUpload ? img : cached(bi);
    if (body.complete && body.naturalWidth) c.drawImage(body, ox*z, oy*z, imgW*z, imgH*z);
    const hm = cached(hi), p = picks.head;
    if (p && hm.complete && hm.naturalWidth)
      c.drawImage(hm, (p.x+ox)*z - HELM_W*z/2, (p.y+oy)*z - HELM_H*z/2, HELM_W*z, HELM_H*z);
  });
}

cv.addEventListener('click', (e) => {
  const r = cv.getBoundingClientRect();
  const sx = (e.clientX - r.left) * (cv.width / r.width);
  const sy = (e.clientY - r.top)  * (cv.height / r.height);
  setPick({ x: sx/zoom, y: sy/zoom });
});

window.addEventListener('keydown', (e) => {
  if ((e.key === '1' || e.key === '2' || e.key === '3') && !e.ctrlKey && !e.metaKey && !e.altKey){
    setActive(TARGETS[+e.key - 1].id);
    e.preventDefault();
    return;
  }
  const p = picks[active];
  const st = e.shiftKey ? 1 : 0.1;
  let dx = 0, dy = 0;
  if (e.key === 'ArrowLeft') dx = -st; else if (e.key === 'ArrowRight') dx = st;
  else if (e.key === 'ArrowUp') dy = -st; else if (e.key === 'ArrowDown') dy = st;
  else return;
  e.preventDefault();
  setPick({ x: p.x + dx, y: p.y + dy });
});

zoomEl.addEventListener('input', () => { zoom = +zoomEl.value; zoomVal.textContent = zoom+'×'; draw(); });

TARGETS.forEach(t => document.getElementById('tab_' + t.id).addEventListener('click', () => setActive(t.id)));

document.getElementById('resetBtn').addEventListener('click', () => {
  TARGETS.forEach(t => { picks[t.id] = posToPx(CURRENT[t.id]); });
  setActive(active);
});

// копирование: 1) execCommand синхронно внутри клика (работает на file://) ->
// 2) Clipboard API -> 3) prompt с текстом для ручного Ctrl+C. Честный итог на кнопке.
function copyText(t, ok, fail){
  if (t == null) t = '';
  try {
    const ta = document.createElement('textarea');
    ta.value = t;
    ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none;';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    ta.setSelectionRange(0, t.length);
    let copied = false;
    try { copied = document.execCommand && document.execCommand('copy'); } catch(e){ copied = false; }
    document.body.removeChild(ta);
    if (copied) return ok();
  } catch(e){}
  if (navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(t).then(ok, () => manualCopy(t, fail));
    return;
  }
  manualCopy(t, fail);
}
function manualCopy(t, fail){
  try { window.prompt('Буфер обмена закрыт браузером — скопируй вручную (Ctrl+C):', t); } catch(e){}
  fail();
}
function flash(btn, ok){
  const o = btn.textContent;
  btn.textContent = ok ? '✓ ок' : '✗ вручную';
  btn.classList.remove('copied', 'copyfail');
  btn.classList.add(ok ? 'copied' : 'copyfail');
  setTimeout(() => { btn.textContent = o; btn.classList.remove(ok ? 'copied' : 'copyfail'); }, 1500);
}
function copyBtn(id){
  document.getElementById(id).addEventListener('click', function(){
    const t = this.dataset.val || '';
    if (!t) return;
    const btn = this;
    copyText(t, () => flash(btn, true), () => flash(btn, false));
  });
}
copyBtn('cpos'); copyBtn('cmil');
copyBtn('sum_copy_head'); copyBtn('sum_copy_BackWheel'); copyBtn('sum_copy_FrontWheel');

document.getElementById('allBtn').addEventListener('click', function(){
  const btn = this;
  copyText(JSON.stringify(payload(), null, 2), () => flash(btn, true), () => flash(btn, false));
});

document.getElementById('dlBtn').addEventListener('click', () => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(payload(), null, 2)], { type: 'application/json' }));
  a.download = 'banana_positions.json';
  a.click();
  URL.revokeObjectURL(a.href);
});

// загрузка своего PNG (кнопка / drag&drop / paste)
function useFile(file){
  const rd = new FileReader();
  rd.onload = () => { const i = new Image();
    i.onload = () => {
      img = i; imgW = i.naturalWidth; imgH = i.naturalHeight;
      usingUpload = true;
      sizeInfo.textContent = 'спрайт ' + imgW + '×' + imgH + ', ppu 48';
      if (imgW !== BUILTIN_W || imgH !== BUILTIN_H){
        banner.style.display = 'block';
        banner.textContent = 'Размер ' + imgW + '×' + imgH + ' (для Banana в игре 35×24). pos считается от ЦЕНТРА этой картинки — если вокруг машины есть поля, результат будет неверным. Надёжнее кликать на встроенном спрайте.';
      } else banner.style.display = 'none';
      draw(); drawPreviews();
    };
    i.src = rd.result;
  };
  rd.readAsDataURL(file);
}
document.getElementById('upBtn').addEventListener('click', () => document.getElementById('file').click());
document.getElementById('file').addEventListener('change', (e) => { if (e.target.files[0]) useFile(e.target.files[0]); });
document.addEventListener('dragover', (e) => e.preventDefault());
document.addEventListener('drop', (e) => { e.preventDefault(); if (e.dataTransfer.files[0]) useFile(e.dataTransfer.files[0]); });
document.addEventListener('paste', (e) => { const it = [...(e.clipboardData||{items:[]}).items].find(i => i.type.startsWith('image')); if (it) useFile(it.getAsFile()); });

img.decode ? img.decode().then(init).catch(init) : (img.complete ? init() : img.onload = init);
function init(){
  TARGETS.forEach(t => { picks[t.id] = posToPx(CURRENT[t.id]); });
  setActive('head');
  drawPreviews();
}
</script>
</body>
</html>
'''

html = HTML
for token, path in FILES.items():
    with open(path, 'rb') as f:
        html = html.replace(token, 'data:image/png;base64,' + base64.b64encode(f.read()).decode())

out = 'download/head_picker.html'
with open(out, 'w', encoding='utf-8') as f:
    f.write(html)

import os
print('OK:', out, os.path.getsize(out), 'bytes')
for token in FILES:
    assert token not in html, 'UNREPLACED TOKEN: ' + token
print('all tokens replaced')
