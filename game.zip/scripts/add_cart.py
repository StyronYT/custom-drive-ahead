"""Добавляет машину Cart (без колёс) в игру.

- копирует upload/cart.png -> public/sprites/Cart__Cart_0.png
- обводит контур корпуса по альфа-каналу (масштаб PPU=48, y-флип)
- дописывает BlueCart и RedCart в public/game_data.json
- голова ставится по координатам юзера: Rectangle Top Left (12.5, 7.9) px
"""
import json
import math

from PIL import Image

PPU = 48.0
HEAD_PX = (12.5, 7.9)  # top-left origin, как задал пользователь
DATA = 'public/game_data.json'

img = Image.open('upload/cart.png').convert('RGBA')
w, h = img.size
px = img.load()
mask = [[1 if px[x, y][3] > 16 else 0 for x in range(w)] for y in range(h)]

# --- собираем граничные рёбра (внутри слева/снаружи справа — ориентация не важна) ---
segs = {}  # вершина -> список соседей
def add_edge(a, b):
    segs.setdefault(a, []).append(b)
    segs.setdefault(b, []).append(a)

for y in range(h):
    for x in range(w):
        if not mask[y][x]:
            continue
        # правый сосед
        if x + 1 >= w or not mask[y][x + 1]:
            add_edge((x + 1, y), (x + 1, y + 1))
        # левый сосед
        if x - 1 < 0 or not mask[y][x - 1]:
            add_edge((x, y), (x, y + 1))
        # нижний сосед
        if y + 1 >= h or not mask[y + 1][x]:
            add_edge((x, y + 1), (x + 1, y + 1))
        # верхний сосед
        if y - 1 < 0 or not mask[y - 1][x]:
            add_edge((x, y), (x + 1, y))

# --- цепляем рёбра в замкнутые контуры ---
visited = set()
loops = []
for v0 in list(segs.keys()):
    if v0 in visited:
        continue
    loop = [v0]
    visited.add(v0)
    cur = v0
    prev = None
    while True:
        nxts = [n for n in segs[cur] if n != prev and n not in visited]
        if not nxts:
            # замыкание на старт?
            if v0 in segs[cur]:
                break
            break
        nxt = nxts[0]
        visited.add(nxt)
        loop.append(nxt)
        prev, cur = cur, nxt
    if len(loop) >= 4:
        loops.append(loop)

# берём самый длинный контур (внешний)
loops.sort(key=len, reverse=True)
loop = loops[0]

# --- упрощение Рамера–Дугласа–Пекера ---
def rdp(points, eps):
    if len(points) < 3:
        return points
    (x0, y0), (x1, y1) = points[0], points[-1]
    dx, dy = x1 - x0, y1 - y0
    norm = math.hypot(dx, dy)
    dmax, idx = 0.0, 0
    for i in range(1, len(points) - 1):
        x, y = points[i]
        if norm < 1e-9:
            d = math.hypot(x - x0, y - y0)  # замкнутый контур: базовая линия вырождена
        else:
            d = abs(dy * (x - x0) - dx * (y - y0)) / norm
        if d > dmax:
            dmax, idx = d, i
    if dmax > eps:
        left = rdp(points[: idx + 1], eps)
        right = rdp(points[idx:], eps)
        return left[:-1] + right
    return [points[0], points[-1]]

pts = []
for eps in (0.65, 0.45, 0.3, 0.2):
    pts = rdp(loop + [loop[0]], eps)[:-1]
    if len(pts) >= 3:
        break
if len(pts) < 3:
    raise SystemExit('контур слишком простой: %d точек' % len(pts))

# --- в игровые единицы: центр спрайта = (0,0), y вверх ---
cx, cy = w / 2.0, h / 2.0
outline = [[round((x - cx) / PPU, 4), round((cy - y) / PPU, 4)] for x, y in pts]

# площадь контура против площади пикселей — контроль корректности трассировки
def shoelace(p):
    s = 0.0
    for i in range(len(p)):
        a, b = p[i], p[(i + 1) % len(p)]
        s += a[0] * b[1] - b[0] * a[1]
    return s / 2

pix_area = sum(sum(row) for row in mask) / PPU / PPU
outline_area = abs(shoelace(outline))
print('точек контура:', len(outline), '| площадь пикселей:', round(pix_area, 4), '| площадь контура:', round(outline_area, 4))
assert abs(pix_area - outline_area) / pix_area < 0.25, 'контур не совпадает с маской'

# --- голова: (12.5, 7.9) px от верхнего левого угла ---
head_x = round((HEAD_PX[0] - cx) / PPU, 4)
head_y = round((cy - HEAD_PX[1]) / PPU, 4)
print('голова в локальных координатах:', head_x, head_y)

def car_entry(color, flip):
    hx = round(-head_x, 4) if flip else head_x
    body = {
        'name': 'Body',
        'layer': 0,
        'pos': [0.0, 0.0],
        'scale': [1.0, 1.0],
        'poly': {'paths': [outline]},
        'sprite': 'Cart/Cart_0',
        'flipX': flip,
        'order': 2,
    }
    head = {
        'name': 'Head',
        'layer': 7,
        'pos': [hx, head_y],
        'scale': [1.0, 1.0],
        'rb': {'mass': 0.5, 'gravityScale': -0.1, 'linearDamping': 0, 'angularDamping': 0.05, 'friction': 0.4},
        'circle': {'r': 0.075, 'off': [0.0, 0.0], 'friction': 0.4},
        'sprite': 'CarParts/CarParts_304' if color == 'blue' else 'CarParts/CarParts_302',
        'flipX': False,
        'order': 3,
        'hinge': {'anchor': [0.0, -0.07], 'connectedAnchor': [round(hx, 4), round(head_y - 0.07, 4)], 'limits': [-20, 20]},
    }
    return {
        'carType': 'Cart',
        'color': color,
        'carData': {'speed': 90, 'maxSpeed': 180, 'rotationSpeed': 120},
        'tree': {
            'name': ('BlueCart' if color == 'blue' else 'RedCart'),
            'layer': 0,
            'pos': [0.0, 0.0],
            'scale': [1.0, 1.0],
            'rb': {'mass': 3, 'gravityScale': 1, 'linearDamping': 0.2, 'angularDamping': 0.05, 'friction': 0.1},
            'children': [body, head],
        },
    }

import shutil
shutil.copy('upload/cart.png', 'public/sprites/Cart__Cart_0.png')

data = json.load(open(DATA))
data['cars']['BlueCart'] = car_entry('blue', False)
data['cars']['RedCart'] = car_entry('red', True)
json.dump(data, open(DATA, 'w'), indent=1, ensure_ascii=False)
print('OK: Cart__Cart_0.png скопирован, BlueCart и RedCart добавлены (машин теперь', len(data['cars']), ')')
