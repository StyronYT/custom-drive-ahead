#!/usr/bin/env python3
"""Build final game_data.json: cars (physics+sprites) and arenas (scene)."""
import json, sys
sys.path.insert(0, "/home/z/my-project/scripts")
from parse_unity import load_docs

PARSED = "/home/z/my-project/repo-src/parsed"
cars_raw = json.load(open(f"{PARSED}/cars.json"))
scene = json.load(open(f"{PARSED}/scene.json"))
atlas = json.load(open(f"{PARSED}/atlas.json"))

GUID2ATLAS = {}
for name, a in atlas.items():
    GUID2ATLAS[a["guid"]] = name

CARTYPE_DATA = {
    "85d024002fcb24e838c9de5135e7e0df": (35, 70, 70),     # AntiqueFormula
    "50a32eeb1749ec09a80798d7bbbf3f08": (300, 600, 200),  # Dragster
    "3da70d70530a27aad9a3f935dc5bb744": (45, 90, 120),    # Limouse
    "66e398bef49741890b624fbd7c2deab8": (200, 400, 150),  # Monster
    "a919623c306221e8e86f47dfe79f62d5": (50, 100, 120),   # Off-RoadTruck
    "981fa303817e92b4292c608dd4e9ff4e": (25, 50, 100),    # PlanetaryExplorer
    "5e764e7ffe4be64b9a1806204f68dce5": (60, 120, 130),   # Weevil
}
CARTYPE_NAME = {
    "85d024002fcb24e838c9de5135e7e0df": "AntiqueFormula",
    "50a32eeb1749ec09a80798d7bbbf3f08": "Dragster",
    "3da70d70530a27aad9a3f935dc5bb744": "Limouse",
    "66e398bef49741890b624fbd7c2deab8": "Monster",
    "a919623c306221e8e86f47dfe79f62d5": "Off-RoadTruck",
    "981fa303817e92b4292c608dd4e9ff4e": "PlanetaryExplorer",
    "5e764e7ffe4be64b9a1806204f68dce5": "Weevil",
}
CARTYPE_GUID_BY_CAR = {  # from prefab carData guid
    "BlueAntiqueFormula": "85d024002fcb24e838c9de5135e7e0df",
    "BlueDragster": "50a32eeb1749ec09a80798d7bbbf3f08",
    "BlueLimouse": "3da70d70530a27aad9a3f935dc5bb744",
    "BlueMonster": "66e398bef49741890b624fbd7c2deab8",
    "BlueOff-RoadTruck": "a919623c306221e8e86f47dfe79f62d5",
    "BluePlanetaryExplorer": "981fa303817e92b4292c608dd4e9ff4e",
    "BlueWeevil": "5e764e7ffe4be64b9a1806204f68dce5",
}

def resolve_sprite(guid, fid):
    if not guid or not fid: return None
    aname = GUID2ATLAS.get(guid)
    if not aname: return None
    return f"{aname}/{atlas[aname]['fid2sprite'].get(str(fid))}"

MAT_TIRE = "162bdfab568e60ccc9dfab58e9df6cb3"   # friction 3
MAT_NOFR = "cf2f649d5f2fca002b3364170ab15ca1"   # friction 0.1

def conv_node(n):
    out = {"name": n["name"], "layer": n["layer"], "pos": n["pos"], "scale": n["scale"]}
    if n.get("rigidbody"):
        rb = n["rigidbody"]
        out["rb"] = {"mass": rb["mass"], "gravityScale": rb["gravityScale"],
                     "linearDamping": rb["linearDamping"], "angularDamping": rb["angularDamping"],
                     "friction": 0.1 if rb["mat_guid"] == MAT_NOFR else (3 if rb["mat_guid"] == MAT_TIRE else 0.4)}
    if n.get("circle"):
        c = n["circle"]
        out["circle"] = {"r": c["radius"], "off": c["offset"],
                         "friction": 0.1 if c["mat_guid"] == MAT_NOFR else (3 if c["mat_guid"] == MAT_TIRE else 0.4)}
    if n.get("poly"):
        out["poly"] = {"paths": n["poly"]["paths"]}
    s = n.get("sprite")
    if s:
        out["sprite"] = resolve_sprite(s["guid"], s["fileID"])
        out["flipX"] = bool(s.get("flipX"))
        out["order"] = s.get("order")
    if n.get("hinge"):
        h = n["hinge"]
        out["hinge"] = {"anchor": h["anchor"], "connectedAnchor": h["connectedAnchor"],
                        "limits": h["limits"]}
    if n.get("wheelJoints"):
        out["wheelJoints"] = [{"connected": None, "anchor": w["anchor"],
                               "susp": [w["suspension"]["dampingRatio"], w["suspension"]["frequency"]]}
                              for w in n["wheelJoints"]]
    kids = [conv_node(k) for k in n.get("children", [])]
    if kids: out["children"] = kids
    return out

cars_out = {}
for cname, c in cars_raw.items():
    t = c["tree"]
    guid = CARTYPE_GUID_BY_CAR.get(cname) or CARTYPE_GUID_BY_CAR.get(cname.replace("Red", "Blue"))
    data_guid = guid
    speed, maxSpeed, rotSpeed = CARTYPE_DATA[data_guid]
    base = cname.replace("Blue", "").replace("Red", "")
    cars_out[cname] = {
        "carType": base, "color": c["color"],
        "carData": {"speed": speed, "maxSpeed": maxSpeed, "rotationSpeed": rotSpeed},
        "tree": conv_node(t),
    }

# ---- ARENAS from scene ----
ARENA_SCRIPT = "40151d1587914ddfbdb70b701ee4d02d"
arenas_out = []
def walk(n, parent_pos=(0,0), parent_rot=0):
    # arena can be anywhere under BattleSetup
    if n.get("scripts") and ARENA_SCRIPT in n["scripts"]:
        import math
        # угол из кватерниона (z, w): θ = 2·atan2(z, w)
        theta = 2 * math.atan2(n["rotZ"], n.get("rotW", 1) if n.get("rotW") is not None else 1)
        ar = {"name": n["name"], "pos": n["pos"], "rotZ": n["rotZ"], "rotW": n.get("rotW", 1), "theta": theta, "scale": n["scale"],
              "sprite": resolve_sprite((n["sprite"] or {}).get("guid"), (n["sprite"] or {}).get("fileID")),
              "flipX": bool((n["sprite"] or {}).get("flipX")),
              "order": (n["sprite"] or {}).get("order"),
              "collider": n["collider"],
              "spawns": {}, "children": []}
        for ch in n["children"]:
            if ch["name"] in ("BlueSpawn", "RedSpawn"):
                # мировая позиция спавна = pos арены + R(θ)·локальная позиция
                ca, sa = math.cos(theta), math.sin(theta)
                lx, ly = ch["pos"]
                wx = n["pos"][0] + lx * ca - ly * sa
                wy = n["pos"][1] + lx * sa + ly * ca
                ar["spawns"][ch["name"]] = [round(wx, 4), round(wy, 4)]
            else:
                chn = {"name": ch["name"], "pos": ch["pos"], "rotZ": ch["rotZ"], "scale": ch["scale"],
                       "sprite": resolve_sprite((ch["sprite"] or {}).get("guid"), (ch["sprite"] or {}).get("fileID")),
                       "flipX": bool((ch["sprite"] or {}).get("flipX")),
                       "order": (ch["sprite"] or {}).get("order"),
                       "collider": ch["collider"], "layer": ch["layer"]}
                chn["children"] = [dict(name=k["name"], pos=k["pos"], sprite=resolve_sprite((k["sprite"] or {}).get("guid"), (k["sprite"] or {}).get("fileID")),
                                        order=(k["sprite"] or {}).get("order"), scale=k["scale"], rotZ=k["rotZ"]) for k in ch.get("children", [])]
                ar["children"].append(chn)
        arenas_out.append(ar)
    for ch in n.get("children", []):
        walk(ch)

for root in scene:
    walk(root)

data = {"cars": cars_out, "arenas": arenas_out}
json.dump(data, open("/home/z/my-project/game-assets/game_data.json", "w"), indent=1)
print("cars:", len(cars_out), "arenas:", len(arenas_out))
for a in arenas_out:
    print(f"  {a['name']}: spr={a['sprite']} spawns={a['spawns']} col={bool(a['collider'])} kids={len(a['children'])}")
