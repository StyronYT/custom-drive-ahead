"""Поднимает голову Cart: круг коллайдера ложится на верх кузова.

Кузов: 19 px / 48 ppu → верхняя грань y = +0.198.
Голова: центр = 0.198 + r(0.075) + зазор 0.005 = 0.278. X остаётся от пользователя.
"""
import json

DATA = 'public/game_data.json'
NEW_Y = 0.278

data = json.load(open(DATA))
for name, car in data['cars'].items():
    if car['carType'] != 'Cart':
        continue
    head = next(ch for ch in car['tree']['children'] if ch.get('hinge'))
    x = head['pos'][0]
    head['pos'] = [x, NEW_Y]
    head['hinge']['connectedAnchor'] = [x, round(NEW_Y - 0.07, 4)]
    print(f"{name}: голова -> ({x}, {NEW_Y})")

json.dump(data, open(DATA, 'w'), indent=1, ensure_ascii=False)
print('OK')
