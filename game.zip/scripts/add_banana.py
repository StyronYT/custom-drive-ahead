#!/usr/bin/env python3
"""Добавляет машину Banana (blue/red) в игру: спрайты, манифест, дефы в game_data.json.

Координаты от пользователя (в пикселях спрайта 35x24, y-вниз):
  голова:    Top Left (16.8, 9.1)  — верх нарисованного капитана
  колёса:    линия TL (7.4, 22.7) -> BR (28.8, 22.8) — ось между центрами колёс
Полигон корпуса трассируется из альфа-канала (точная обводка банана, как у
остальных машин — их поли тоже пиксельные контуры спрайтов).
"""
import json, math, shutil, sys
from collections import deque
from PIL import Image

P = 48.0  # ppu всех машинных спрайтов
BLUE = 'upload/banana_blue.png'
RED = 'upload/banana_red.png'
OUTB = 'public/sprites/Banana__Banana_blue.png'
OUTR = 'public/sprites/Banana__Banana_red.png'
GDATA = 'public/game_data.json'
MANIFEST = 'public/sprite_manifest.json'

def load_mask(path):
    im = Image.open(path).convert('RGBA')
    px = im.load()
    w, h = im.size
    mask = [[px[x, y][3] > 40 for x in range(w)] for y in range(h)]
    return im, px, w, h, mask

def holes_count(mask, w, h):
    """Прозрачные пиксели, недостижимые с границы = замкнутые дырки."""
    seen = [[False] * w for _ in range(h)]
    q = deque()
    for x in range(w):
        for y in (0, h - 1):
            if not mask[y][x] and not seen[y][x]:
                seen[y][x] = True; q.append((x, y))
    for y in range(h):
        for x in (0, w - 1):
            if not mask[y][x] and not seen[y][x]:
                seen[y][x] = True; q.append((x, y))
    while q:
        x, y = q.popleft()
        for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < w and 0 <= ny < h and not mask[ny][nx] and not seen[ny][nx]:
                seen[ny][nx] = True; q.append((nx, ny))
    return sum(1 for y in range(h) for x in range(w) if not mask[y][x] and not seen[y][x])

def moore_trace(mask, w, h):
    """Обход внешней границы (Moore-neighbor), старт с самого верхнего левого пикселя."""
    start = None
    for y in range(h):
        for x in range(w):
            if mask[y][x]:
                start = (x, y); break
        if start: break
    assert start, 'нет непрозрачных пикселей'
    nb = [(-1,0),(-1,-1),(0,-1),(1,-1),(1,0),(1,1),(0,1),(-1,1)]  # против часовой в экранных коорд.
    def opq(x, y):
        return 0 <= x < w and 0 <= y < h and mask[y][x]
    contour = [start]
    prev_dir = 6  # пришли слева
    cur = start
    for _ in range(20000):
        found = False
        for k in range(8):
            d = (prev_dir + 6 + k) % 8  # backtrack+1 по часовой
            nx, ny = cur[0] + nb[d][0], cur[1] + nb[d][1]
            if opq(nx, ny):
                contour.append((nx, ny))
                prev_dir = d
                cur = (nx, ny)
                found = True
                break
        if not found:
            break
        if cur == start and len(contour) > 3:
            break
    return contour[:-1] if contour[-1] == start else contour

def dp(points, eps):
    """Дуглас-Пюкер для замкнутого контура (якорь — точка 0)."""
    def seg_dist(p, a, b):
        ax, ay = a; bx, by = b; px_, py_ = p
        dx, dy = bx - ax, by - ay
        L2 = dx*dx + dy*dy
        if L2 == 0: return math.hypot(px_-ax, py_-ay)
        t = max(0.0, min(1.0, ((px_-ax)*dx + (py_-ay)*dy) / L2))
        return math.hypot(px_-ax-t*dx, py_-ay-t*dy)
    def rec(pts):
        if len(pts) < 3: return pts
        a, b = pts[0], pts[-1]
        idx, dmax = 0, -1.0
        for i in range(1, len(pts)-1):
            d = seg_dist(pts[i], a, b)
            if d > dmax: idx, dmax = i, d
        if dmax > eps:
            left = rec(pts[:idx+1]); right = rec(pts[idx:])
            return left[:-1] + right
        return [a, b]
    # открытая цепочка: контур + замыкающий первый пиксель
    closed = points + [points[0]]
    out = rec(closed)
    return out[:-1]

def trace_poly(path):
    im, px, w, h, mask = load_mask(path)
    assert (w, h) == (35, 24), (w, h)
    nh = holes_count(mask, w, h)
    assert nh == 0, f'замкнутые прозрачные дырки: {nh}'
    contour = moore_trace(mask, w, h)
    simp = dp(contour, 0.42)
    # пиксели (y-вниз) -> юниты относительно центра спрайта (17.5, 12), y-вверх
    units = [((x + 0.5 - 17.5) / P, (12.0 - (y + 0.5)) / P) for (x, y) in simp]
    # площадь по шулю (y-up): CCW положителен
    A = sum(units[i][0] * units[(i+1) % len(units)][1] - units[(i+1) % len(units)][0] * units[i][1] for i in range(len(units))) / 2
    if A < 0:
        units.reverse(); A = -A
    # дедуп близких точек
    clean = [units[0]]
    for p in units[1:]:
        if math.hypot(p[0]-clean[-1][0], p[1]-clean[-1][1]) > 1e-4: clean.append(p)
    if math.hypot(clean[0][0]-clean[-1][0], clean[0][1]-clean[-1][1]) <= 1e-4: clean.pop()
    mask_area = sum(1 for y in range(h) for x in range(w) if mask[y][x]) / (P*P)
    return clean, A, mask_area

poly_b, area_b, marea_b = trace_poly(BLUE)
poly_r, area_r, marea_r = trace_poly(RED)
# Голова: значение pos берётся из head_picker (клик по спрайту -> юниты дефа).
# История: [0.246, 0.1] -> [-0.0167, 0.0646] (выбор пользователя в пикере).
# Ставим pos головы РОВНО как задано — без пересчётов. Хитбокс r=0.075 и шлем
# (304/302) в том же центре (pivot 0.5,0.5).
HEAD_POS_UNITS = (-0.0167, 0.0646)
HEAD_R = 0.075
HEAD_SPRITE = {'blue': 'CarParts/CarParts_304', 'red': 'CarParts/CarParts_302'}  # цветной шлем, как у всех машин
hc_u = HEAD_POS_UNITS
print('head pos units=(%.6f, %.6f) (px от центра: (%.2f, %.2f))' % (hc_u[0], hc_u[1], hc_u[0] * P, -hc_u[1] * P))
hc_b = hc_u
hc_r = hc_u
print('blue poly: points=%d area=%.4f mask_area=%.4f' % (len(poly_b), area_b, marea_b))
print('red  poly: points=%d area=%.4f mask_area=%.4f' % (len(poly_r), area_r, marea_r))
xs = [p[0] for p in poly_b]; ys = [p[1] for p in poly_b]
print('poly bbox units: x [%.4f..%.4f] y [%.4f..%.4f]' % (min(xs), max(xs), min(ys), max(ys)))

# колёса: линия пользователя TL(7.4,22.7)-BR(28.8,22.8) -> центры на концах
wl = ((7.4 + 0.5 - 17.5) / P, (12.0 - 22.75) / P)
wr = ((28.8 + 0.5 - 17.5) / P, (12.0 - 22.75) / P)
print('wheel centers units: left=(%.6f, %.6f) right=(%.6f, %.6f)' % (wl[0], wl[1], wr[0], wr[1]))

def car_def(color, poly, hc, sprite):
    hx, hy = round(hc[0], 4), round(hc[1], 4)
    fx, fy = round(wr[0], 6), round(wr[1], 6)
    bx, by = round(wl[0], 6), round(wl[1], 6)
    return {
        'carType': 'Banana',
        'color': color,
        'carData': {'speed': 60, 'maxSpeed': 120, 'rotationSpeed': 130},
        'tree': {
            'name': ('Blue' if color == 'blue' else 'Red') + 'Banana',
            'layer': 0,
            'pos': [0.0, 0.0],
            'scale': [1.0, 1.0],
            'rb': {'mass': 2, 'gravityScale': 1, 'linearDamping': 0, 'angularDamping': 0, 'friction': 0.1},
            'wheelJoints': [
                {'connected': None, 'anchor': [fx, fy], 'susp': [0.7, 8]},
                {'connected': None, 'anchor': [bx, by], 'susp': [0.7, 8]},
            ],
            'children': [
                {'name': 'GroundCheckPoint', 'layer': 0, 'pos': [0.0, -0.235], 'scale': [1.0, 1.0]},
                {'name': 'BackWheel', 'layer': 0, 'pos': [bx, by], 'scale': [1.0, 1.0],
                 'rb': {'mass': 1, 'gravityScale': 1, 'linearDamping': 0, 'angularDamping': 0.05, 'friction': 3},
                 'circle': {'r': 0.09, 'off': [0.0, 0.0], 'friction': 3},
                 'sprite': 'CarParts/CarParts_329', 'flipX': False, 'order': None},
                {'name': 'Head', 'layer': 7, 'pos': [hx, hy], 'scale': [1.0, 1.0],
                 'rb': {'mass': 0.5, 'gravityScale': -0.1, 'linearDamping': 0, 'angularDamping': 0.05, 'friction': 0.4},
                 'circle': {'r': 0.075, 'off': [0.0, 0.0], 'friction': 0.4},
                 'sprite': HEAD_SPRITE[color], 'flipX': False, 'order': 3,
                 'hinge': {'anchor': [0.0, -0.075], 'connectedAnchor': [hx, round(hy - 0.075, 4)], 'limits': [-20, 20]}},
                {'name': 'FrontWheel', 'layer': 0, 'pos': [fx, fy], 'scale': [1.0, 1.0],
                 'rb': {'mass': 1, 'gravityScale': 1, 'linearDamping': 0, 'angularDamping': 0.05, 'friction': 3},
                 'circle': {'r': 0.09, 'off': [0.0, 0.0], 'friction': 3},
                 'sprite': 'CarParts/CarParts_329', 'flipX': False, 'order': None},
                {'name': 'Body', 'layer': 0, 'pos': [0.0, 0.0], 'scale': [1.0, 1.0],
                 'poly': {'paths': [[[round(x, 4), round(y, 4)] for (x, y) in poly]]},
                 'sprite': sprite, 'flipX': False, 'order': 2},
            ],
        },
    }

# 1) спрайты
shutil.copyfile(BLUE, OUTB)
shutil.copyfile(RED, OUTR)

# 2) манифест
man = json.load(open(MANIFEST))
for k, f in (('Banana/Banana_blue', BLUE), ('Banana/Banana_red', RED)):
    im = Image.open(f)
    man[k] = {'px': [im.width, im.height], 'ppu': 48, 'pivot': [0.5, 0.5]}
json.dump(man, open(MANIFEST, 'w'), indent=1)

# 3) дефы машин (идемпотентно: перезаписываем, если уже добавлены)
data = json.load(open(GDATA))
data['cars'].pop('BlueBanana', None)
data['cars'].pop('RedBanana', None)
data['cars']['BlueBanana'] = car_def('blue', poly_b, hc_b, 'Banana/Banana_blue')
data['cars']['RedBanana'] = car_def('red', poly_r, hc_r, 'Banana/Banana_red')
json.dump(data, open(GDATA, 'w'), indent=2)
print('OK: sprites copied, manifest +2, game_data cars +2 (BlueBanana, RedBanana)')
