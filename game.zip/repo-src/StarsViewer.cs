using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StarsViewer : MonoBehaviour
{
    [SerializeField] private List<Image> stars;
    [SerializeField] private Sprite star;
    [SerializeField] private Sprite emptyStar;
    [SerializeField] private RectTransform spinEffect;
    [SerializeField] private GameObject winText;

    private Coroutine _spinCoroutine;
    private int _score;

    public void DrawStars(int currentStars, bool animate = false)
    {
        if (!animate)
            _score = currentStars;
        else
            if (_score == currentStars)
                return;
        
        ResetStars();

        for (int i = 0; i < currentStars && i < stars.Count; i++)
            stars[i].sprite = star;

        if (animate && currentStars > 0)
        {
            winText.SetActive(true);
            if (_spinCoroutine != null) StopCoroutine(_spinCoroutine);
            _spinCoroutine = StartCoroutine(SpinCoroutine(currentStars - 1));
        }
    }

    private void ResetStars()
    {
        if (_spinCoroutine != null)
        {
            StopCoroutine(_spinCoroutine);
            _spinCoroutine = null;
        }

        spinEffect.gameObject.SetActive(false);
        spinEffect.rotation = Quaternion.identity;

        foreach (var s in stars)
            s.sprite = emptyStar;
    }

    private IEnumerator SpinCoroutine(int index)
    {
        spinEffect.gameObject.SetActive(true);
        spinEffect.position = stars[index].transform.position;
        float rotation = 0f;

        while (true)
        {
            rotation += 360f * Time.deltaTime;
            spinEffect.rotation = Quaternion.Euler(0, 0, rotation);
            yield return null;
        }
    }
}