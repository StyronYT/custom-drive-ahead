using UnityEngine;

public class UIManager : MonoBehaviour
{
    [SerializeField] private StarsViewer blueStars, redStars;
    [SerializeField] private GameObject blueWinPanel, redWinPanel;

    private void Start()
    {
        blueStars.DrawStars(GameManager.Instance.Score.blue);
        redStars.DrawStars(GameManager.Instance.Score.red);
        GameManager.Instance.OnScoreChanged += RefreshUI;
    }

    private void OnDestroy()
    {
        GameManager.Instance.OnScoreChanged -= RefreshUI;
    }

    private void RefreshUI()
    {
        if (GameManager.Instance.IsGameOver())
        {
            switch (GameManager.Instance.WhoWin())
            {
                case CarType.Blue: 
                    blueStars.DrawStars(5);
                    blueWinPanel.SetActive(true);
                    return;
                case CarType.Red: 
                    redStars.DrawStars(5);
                    redWinPanel.SetActive(true);
                    return;
            }
        }
        blueStars.DrawStars(GameManager.Instance.Score.blue, true);
        redStars.DrawStars(GameManager.Instance.Score.red, true);
    }
}