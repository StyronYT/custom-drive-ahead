using UnityEngine;

public abstract class Singleton<T> : MonoBehaviour where T : Component
{
    private static T _instance;
        
    public static T Instance
    {
        get 
        {
            if (_instance) 
                    return _instance;
            _instance = FindFirstObjectByType<T>();
            if (_instance) 
                return _instance;
            var obj = new GameObject(typeof(T).Name);
            _instance = obj.AddComponent<T>();
            return _instance;
        }
    }
    protected virtual void Awake()
    {
        if (!_instance) 
            _instance = this as T;
        else if (_instance != this) 
            Destroy(gameObject);
        DontDestroyOnLoad(this);
    }
}