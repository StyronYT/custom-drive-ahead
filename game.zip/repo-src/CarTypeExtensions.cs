public static class CarTypeExtensions
{
    public static CarType GetOpponent(this CarType type)
    {
        return type == CarType.Blue ? CarType.Red : CarType.Blue;
    }
}