using UnityEngine;
using UnityEngine.AddressableAssets;

public class BattleSetupManager : MonoBehaviour
{
    private Transform _blueCarSpawn, _redCarSpawn;
    private Arena[] _arenas;

    private void Start()
    {
        // Найти арены (в том числе выключенные)
        _arenas = GetComponentsInChildren<Arena>(true);
        if (_arenas.Length == 0)
        {
            Debug.LogError("Арены не найдены!");
            return;
        }

        Arena selectedArena = _arenas[Random.Range(0, _arenas.Length)];
        selectedArena.gameObject.SetActive(true);

        _blueCarSpawn = selectedArena.BlueSpawn;
        _redCarSpawn = selectedArena.RedSpawn;

        LoadRandomCarWithLabel("blueCar", _blueCarSpawn);
        LoadRandomCarWithLabel("redCar", _redCarSpawn);
    }

    private void LoadRandomCarWithLabel(string label, Transform spawnPoint)
    {
        Addressables.LoadResourceLocationsAsync(label).Completed += handle =>
        {
            if (!handle.IsValid() || handle.Result.Count == 0)
            {
                Debug.LogError($"Машинки с label '{label}' не найдены.");
                return;
            }

            var locations = handle.Result;
            var randomLocation = locations[Random.Range(0, locations.Count)];

            Addressables.InstantiateAsync(randomLocation, spawnPoint.position, spawnPoint.rotation);
        };
    }
}