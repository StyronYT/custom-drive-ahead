using UnityEngine;

[CreateAssetMenu(fileName = "CarData", menuName = "Car Data", order = 0)] 
public class CarData : ScriptableObject 
{ 
    public float speed = 150f; 
    public float maxSpeed = 250f;
    public float rotationSpeed = 150f;
}
