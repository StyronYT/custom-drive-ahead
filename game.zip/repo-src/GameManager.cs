using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : Singleton<GameManager>
{
    [SerializeField] private GameObject hitEffect;
    private (CarController blue, CarController red) _car;
    public (int blue, int red) Score { get; private set; }

    public event Action OnScoreChanged;
    private Coroutine _roundCoroutine;
    private bool _roundOver;
    private InputSystemActions _inputSystem;

    protected override void Awake()
    {
        base.Awake();
        _inputSystem = new InputSystemActions();
        _inputSystem.Enable();
        _inputSystem.Player.Restart.performed += context => 
        {
            if (IsGameOver() && _roundOver)
                RestartGame();
        };
    }

    public void RegisterCar(CarController car)
    {
        switch (car.carType)
        {
            case CarType.Blue: _car.blue = car; break;
            case CarType.Red: _car.red = car; break;
        }
    }

    private CarController GetCar(CarType type)
    {
        return type switch
        {
            CarType.Blue => _car.blue,
            CarType.Red => _car.red,
            _ => null
        };
    }
    
    public void ReportHeadHit(CarController loser)
    {
        if (_roundOver)
            return;
        _roundOver = true;
        
        
        CarType winner = loser.carType.GetOpponent();
        var newScore = Score;
        if (winner == CarType.Blue)
            newScore.blue++;
        else
            newScore.red++;
        Score = newScore;
        Debug.Log(Score);
        OnScoreChanged?.Invoke();
        Instantiate(hitEffect, GetCar(loser.carType).transform.position, Quaternion.identity);

        if (_roundCoroutine != null)
            StopCoroutine(_roundCoroutine);
        _roundCoroutine = StartCoroutine(HandleRoundEnd());
    }

    public bool IsGameOver() => Score.blue >= 5 || Score.red >= 5;
    public CarType WhoWin() => Score.blue >= 5 ? CarType.Blue : CarType.Red;

    private void RestartGame()
    {
        Time.timeScale = 1f;
        Score = (0,0);
        OnScoreChanged?.Invoke();
        _roundOver = false;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    // ReSharper disable Unity.PerformanceAnalysis
    private IEnumerator HandleRoundEnd()
    {
        _car.blue.LockMovement();
        _car.red.LockMovement();
        
        Time.timeScale = 0.5f;
        yield return new WaitForSecondsRealtime(3f);
        Time.timeScale = 1f;

        if (!IsGameOver() && Score != (0, 0))
        {
            _roundOver = false;
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}