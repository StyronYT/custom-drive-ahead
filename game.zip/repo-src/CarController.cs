using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;

public class CarController : MonoBehaviour
{
    #region --- Variables ---

    public CarType carType;

    private List<Rigidbody2D> _wheelRigidbodies = new(); // любое количество колёс
    [SerializeField] private Rigidbody2D carRigidbody;
    [field: SerializeField] public HeadCollision HeadCollision { get; private set; }
    [SerializeField] private CarData carData;
    [SerializeField] private GameObject hitEffect;

    private InputSystemActions _inputSystem;
    private bool _isHit;
    private float _moveInput;
    private Vector3 _startPosition;

    #endregion

    #region --- Logic ---

    private void Awake()
    {
        GameManager.Instance.RegisterCar(this);
        _inputSystem = new InputSystemActions();
        _startPosition = transform.position;
        
        WheelJoint2D[] wheelJoints = GetComponents<WheelJoint2D>();
        foreach (var joint in wheelJoints)
        {
            if (joint && joint.connectedBody)
                _wheelRigidbodies.Add(joint.connectedBody);
        }

        if (_wheelRigidbodies.Count == 0)
            Debug.LogWarning("Колёса не найдены на машине " + gameObject.name);
    }

    private void OnEnable()
    {
        _inputSystem.Enable();

        switch (carType)
        {
            case CarType.Blue:
                _inputSystem.Player.BlueMove.performed += OnMovePerformed;
                _inputSystem.Player.BlueMove.canceled += OnMoveCanceled;
                _inputSystem.Player.BlueReset.performed += OnReset;
                break;
            case CarType.Red:
                _inputSystem.Player.RedMove.performed += OnMovePerformed;
                _inputSystem.Player.RedMove.canceled += OnMoveCanceled;
                _inputSystem.Player.RedReset.performed += OnReset;
                break;
        }
    }

    private void OnDisable()
    {
        switch (carType)
        {
            case CarType.Blue:
                _inputSystem.Player.BlueMove.performed -= OnMovePerformed;
                _inputSystem.Player.BlueMove.canceled -= OnMoveCanceled;
                _inputSystem.Player.BlueReset.performed -= OnReset;
                break;
            case CarType.Red:
                _inputSystem.Player.RedMove.performed -= OnMovePerformed;
                _inputSystem.Player.RedMove.canceled -= OnMoveCanceled;
                _inputSystem.Player.RedReset.performed -= OnReset;
                break;
        }

        LockMovement();
    }

    private void FixedUpdate()
    {
        float wheelTorque = -_moveInput * carData.speed * Time.fixedDeltaTime;

        foreach (var wheel in _wheelRigidbodies)
        {
            // if (wheel.angularVelocity > carData.speed && wheelTorque < 0)
            //     continue; 
            // if (wheel.angularVelocity < -carData.speed && wheelTorque > 0)
            //     continue; 
            wheel.AddTorque(wheelTorque);
        }

        carRigidbody.AddTorque(_moveInput * carData.rotationSpeed * Time.fixedDeltaTime);
    }

    private void OnHeadHit()
    {
        if (_isHit)
            return;

        _isHit = true;

        Instantiate(hitEffect, HeadCollision.transform.position, Quaternion.identity);
        LockMovement();
    }

    private void OnMovePerformed(InputAction.CallbackContext context)
    {
        _moveInput = context.ReadValue<float>();
    }

    private void OnMoveCanceled(InputAction.CallbackContext context)
    {
        _moveInput = 0f;
    }

    private void OnReset(InputAction.CallbackContext context)
    {
        _moveInput = 0f;
        carRigidbody.linearVelocity = Vector2.zero;
        carRigidbody.angularVelocity = 0f;
        carRigidbody.rotation = 0f;

        foreach (var wheel in _wheelRigidbodies) 
            wheel.angularVelocity = 0f;

        transform.SetPositionAndRotation(_startPosition, Quaternion.identity);
    }

    public void LockMovement()
    {
        _inputSystem.Disable();
    }

    #endregion
}
