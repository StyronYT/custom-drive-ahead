using UnityEngine;

public class Arena : MonoBehaviour 
{
    [field: SerializeField] public Transform BlueSpawn { get; private set; }
    [field: SerializeField] public Transform RedSpawn { get; private set; } 
}
