using UnityEngine;

public class HeadCollision : MonoBehaviour
{
    private CarController _carController;
    private void Start() => _carController = GetComponentInParent<CarController>();
    private void OnCollisionEnter2D(Collision2D other) => GameManager.Instance.ReportHeadHit(_carController);
}